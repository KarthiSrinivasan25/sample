// All Category
document.querySelectorAll('.toggle-btn').forEach(item => {
  item.addEventListener('click', () => {
    const submenu = item.nextElementSibling;
    const icon = item.querySelector('.icon-toggle i');

    document.querySelectorAll('.submenu').forEach(sub => {
      if (sub !== submenu) {
        sub.classList.remove('show');
        const otherIcon = sub.previousElementSibling.querySelector('.icon-toggle i');
        if (otherIcon) {
          otherIcon.classList.remove('bi-dash');
          otherIcon.classList.add('bi-plus');
        }
      }
    });

    submenu.classList.toggle('show');

    if (submenu.classList.contains('show')) {
      icon.classList.remove('bi-plus');
      icon.classList.add('bi-dash');
    } else {
      icon.classList.remove('bi-dash');
      icon.classList.add('bi-plus');
    }
  });
});

document.querySelectorAll(".submenu li").forEach(function (item) {
  item.addEventListener("click", function () {
    document.querySelectorAll(".submenu li").forEach(el => el.classList.remove("active"));
    this.classList.add("active");
  });
});


// Featured Category
const row = document.getElementById('categoryRow');
const nextBtn = document.getElementById('nextBtn');
const prevBtn = document.getElementById('prevBtn');

let isAnimating = false;

function getCardWidth() {
  return row.querySelector(".card-wrapper").offsetWidth + 16; 
}

function slideNext() {
  if (isAnimating) return;
  isAnimating = true;

  const cardWidth = getCardWidth();
  row.style.transition = 'transform 0.5s ease';
  row.style.transform = `translateX(-${cardWidth}px)`;

  setTimeout(() => {
    row.appendChild(row.firstElementChild);
    row.style.transition = 'none';
    row.style.transform = 'translateX(0)';
    setTimeout(() => isAnimating = false, 50);
  }, 500);
}

function slidePrev() {
  if (isAnimating) return;
  isAnimating = true;

  const cardWidth = getCardWidth();
  row.style.transition = 'none';
  row.insertBefore(row.lastElementChild, row.firstElementChild);
  row.style.transform = `translateX(-${cardWidth}px)`;

  setTimeout(() => {
    row.style.transition = 'transform 0.5s ease';
    row.style.transform = 'translateX(0)';
    setTimeout(() => isAnimating = false, 500);
  }, 50);
}

nextBtn.addEventListener('click', slideNext);
prevBtn.addEventListener('click', slidePrev);
// Product Item Qty Button
let qty = 1;
function changeQty(val) {
    qty = Math.max(1, qty + val);
    document.getElementById('qtyValue').value = qty;
}


// Mobile Menu Submenu 
document.querySelectorAll('.toggle-submenu').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.stopPropagation(); 

        let li = this.closest('li');
        let submenu = li.nextElementSibling;
        let icon = this.querySelector('i');

        if (!submenu) return; 

        let parentUl = li.parentElement;
        parentUl.querySelectorAll('.submenu-responsive').forEach(function(otherSub) {
            if (otherSub !== submenu) {
                otherSub.classList.remove('show');
                let otherIcon = otherSub.previousElementSibling?.querySelector('.toggle-submenu i');
                if (otherIcon) {
                    otherIcon.classList.replace('bi-chevron-up', 'bi-chevron-down');
                }
            }
        });

        if (submenu.classList.contains('show')) {
            submenu.classList.remove('show');
            icon.classList.replace('bi-chevron-up', 'bi-chevron-down');
        } else {
            submenu.classList.add('show');
            icon.classList.replace('bi-chevron-down', 'bi-chevron-up');
        }
    });
});


// Mobile Menu Category
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.toggle-btn').forEach(function (btn) {
        var icon = btn.querySelector('i');
        var targetId = btn.getAttribute('data-bs-target');
        var target = document.querySelector(targetId);

        if (!target) return;

        var bsCollapse = new bootstrap.Collapse(target, { toggle: false });

        btn.addEventListener('click', function () {
            document.querySelectorAll('.collapse').forEach(function(other) {
                if (other !== target) {
                    bootstrap.Collapse.getInstance(other)?.hide();
                }
            });

            bsCollapse.toggle();
        });

        target.addEventListener('show.bs.collapse', function () {
            icon.classList.remove('bi-plus');
            icon.classList.add('bi-dash');
        });

        target.addEventListener('hide.bs.collapse', function () {
            icon.classList.remove('bi-dash');
            icon.classList.add('bi-plus');
        });
    });
});
