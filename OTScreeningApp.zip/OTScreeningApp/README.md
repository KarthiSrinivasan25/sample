# OT Pediatric Baseline Screening — Android (Kotlin / Jetpack Compose)

Native Android rewrite of the web screening tool. 9 domains, 97 items, identical
scoring logic, ranges, and interpretation labels as the HTML version.

## How to build

1. Install **Android Studio** (Ladybug or newer recommended).
2. Open this folder (`OTScreeningApp/`) as a project — File → Open.
3. Let Gradle sync (it will auto-generate `gradlew`/`gradlew.bat` and download
   the wrapper jar on first sync if missing).
4. Run on an emulator or device with **Run ▶**, or build a release artifact:
   - `Build → Generate Signed Bundle / APK…` → choose APK or Android App
     Bundle (AAB) → create/select a keystore → release build.
5. For the **Play Store**, upload the signed **.aab** through the Play
   Console (new apps require AAB, not APK).

## Project structure

- `model/` — `Domain`, `ScreeningItem`, `SubSection`, `ChildInfo`, `DomainResult`
- `data/ScreeningData.kt` — the full 9-domain, 97-item dataset (source of truth,
  mirrors the HTML tool's `DOMAINS` array exactly)
- `viewmodel/ScreeningViewModel.kt` — scoring state, raw score + interpretation logic
- `ui/screens/` — `IntakeScreen`, `AssessmentScreen`, `ResultsScreen` (Compose UI)
- `ui/AppNavigation.kt` — simple 3-screen state-based navigation
- `util/PdfExporter.kt` — generates a PDF report via Android's native
  `PdfDocument` API and opens it with a `FileProvider` share intent

## Notes

- `minSdk 24` (Android 7.0+), `targetSdk 34`.
- Uses Material 3 + Compose BOM 2024.06.00.
- Room dependencies are included in `app/build.gradle.kts` for optional local
  persistence of multiple children's assessments — not yet wired into the UI;
  add a `Dao`/`Entity` for `ChildInfo` + scores if you want saved history.
- PDF export currently produces a clean text-based report (header, per-domain
  scores/interpretation, per-item scores, signature lines). It does not yet
  visually mirror the HTML report's colored cards — extend `PdfExporter.kt`
  with `Paint` fills per score color if you want closer visual parity.
- App icon is a placeholder vector; replace
  `res/drawable/ic_launcher_foreground.xml` with your own art before
  publishing.
- Package name / applicationId: `com.otscreening.app` — change this in
  `app/build.gradle.kts` and the manifest before publishing if you want a
  different package.

## What I could not verify here

This project was generated in an environment without network access or an
Android SDK/Gradle toolchain installed, so I was not able to run an actual
Gradle build or instrument tests. Open it in Android Studio first and resolve
any sync errors — the code follows standard Compose/Material3 APIs but a real
compile pass is the only way to be fully sure there are no typos or API
mismatches.
