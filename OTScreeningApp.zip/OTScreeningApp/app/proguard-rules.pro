# Add project specific ProGuard rules here.
-keep class com.otscreening.app.model.** { *; }
