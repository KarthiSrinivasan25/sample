package com.otscreening.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.otscreening.app.ui.OTScreeningApp
import com.otscreening.app.ui.theme.OTScreeningTheme
import com.otscreening.app.viewmodel.ScreeningViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ScreeningViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OTScreeningTheme {
                OTScreeningApp(vm = viewModel)
            }
        }
    }
}
