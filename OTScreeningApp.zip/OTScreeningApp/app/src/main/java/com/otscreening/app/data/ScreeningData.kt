package com.otscreening.app.data

import com.otscreening.app.model.Domain
import com.otscreening.app.model.ScreeningItem
import com.otscreening.app.model.SubSection

object ScreeningData {

    val domains: List<Domain> = listOf(
        Domain(
            id = "cognitive",
            label = "Cognitive Function",
            emoji = "🧠",
            colorHex = "#4A90D9",
            scale = listOf(
                "Age appropriate cognitive skills",
                "Functional cognitive skills with support",
                "Developing cognitive skills",
                "Emerging cognitive skills",
                "Not yet demonstrated"
            ),
            ranges = listOf(1..3, 4..6, 7..9, 10..12, 13..15),
            items = listOf(
                ScreeningItem(1, "Attention"),
                ScreeningItem(2, "Memory"),
                ScreeningItem(3, "Concentration")
            )
        ),
        Domain(
            id = "behaviour",
            label = "Behaviour",
            emoji = "🔄",
            colorHex = "#9B59B6",
            scale = listOf(
                "Within normal limits",
                "Mild affective dysregulation",
                "Moderate affective dysregulation",
                "Marked affective dysregulation",
                "Severe affective dysregulation"
            ),
            ranges = listOf(1..25, 26..50, 51..75, 76..100, 101..125),
            items = listOf(
                ScreeningItem(4, "Arranging in array"),
                ScreeningItem(5, "Running b/w 2 points"),
                ScreeningItem(6, "Sitting tolerance"),
                ScreeningItem(7, "Hand flapping"),
                ScreeningItem(8, "Watching fingers"),
                ScreeningItem(9, "Irrelevant scream"),
                ScreeningItem(10, "Irrelevant laugh"),
                ScreeningItem(11, "Blank stares"),
                ScreeningItem(12, "Continuously humming"),
                ScreeningItem(13, "Repeating words"),
                ScreeningItem(14, "Banging or throwing objects"),
                ScreeningItem(15, "Lining up toys"),
                ScreeningItem(16, "Rearranging objects"),
                ScreeningItem(17, "Spinning in circles (People/self)"),
                ScreeningItem(18, "Flicking, Snapping, Tapping fingers"),
                ScreeningItem(19, "Clapping"),
                ScreeningItem(20, "Spinning objects"),
                ScreeningItem(21, "Fingers in mouth"),
                ScreeningItem(22, "Twirling"),
                ScreeningItem(23, "Biting fingernails"),
                ScreeningItem(24, "Rubbing/scratching"),
                ScreeningItem(25, "Walking tip toe"),
                ScreeningItem(26, "Tapping a pencil"),
                ScreeningItem(27, "Teeth grinding"),
                ScreeningItem(28, "Fidgeting movements")
            )
        ),
        Domain(
            id = "language",
            label = "Language & Communication",
            emoji = "🗣️",
            colorHex = "#27AE60",
            scale = listOf("Complex sentences", "Simple sentences", "Phrases", "Words", "Sounds"),
            ranges = listOf(1..2, 3..4, 5..6, 7..8, 9..10),
            items = listOf(
                ScreeningItem(29, "Expressive Language — child says \"water\" to request a drink (expressing a need using words)"),
                ScreeningItem(30, "Receptive Language — child follows command \"give me the ball\" (understands spoken language and responds)")
            )
        ),
        Domain(
            id = "social",
            label = "Social Communication (Non-verbal)",
            emoji = "👋",
            colorHex = "#E67E22",
            scale = listOf(
                "Age appropriate non-verbal communication",
                "Mild non-verbal communication difficulty",
                "Moderate non-verbal communication impairment",
                "Severe non-verbal communication impairment",
                "Absent"
            ),
            ranges = listOf(1..5, 6..10, 11..15, 16..20, 21..25),
            items = listOf(
                ScreeningItem(31, "Social greets/Gestures (Pointing, waving, nodding)"),
                ScreeningItem(32, "Eye contact"),
                ScreeningItem(33, "Body orientation and social referencing"),
                ScreeningItem(34, "Facial expression"),
                ScreeningItem(35, "Joint attention")
            )
        ),
        Domain(
            id = "physical",
            label = "Physical",
            emoji = "💪",
            colorHex = "#E05C4B",
            scale = listOf(
                "Independent",
                "Requires minimum assistance",
                "Requires moderate assistance",
                "Requires maximal assistance",
                "Dependent"
            ),
            ranges = listOf(1..3, 4..6, 7..9, 10..12, 13..15),
            items = listOf(
                ScreeningItem(36, "Muscle tone"),
                ScreeningItem(37, "Posture & balance"),
                ScreeningItem(38, "Tightness / contracture / deformity")
            )
        ),
        Domain(
            id = "gross",
            label = "Gross Motor",
            emoji = "🏃",
            colorHex = "#3DAFA0",
            scale = listOf("Age appropriate", "Established", "Developing", "Emerging", "Unable"),
            ranges = listOf(1..12, 13..24, 25..36, 37..48, 49..60),
            items = listOf(
                ScreeningItem(39, "Sitting to crawling"),
                ScreeningItem(40, "Kneeling to standing"),
                ScreeningItem(41, "Walking to squatting"),
                ScreeningItem(42, "Walk backwards"),
                ScreeningItem(43, "Ball-Kick"),
                ScreeningItem(44, "Climb into chair"),
                ScreeningItem(45, "Confident Run"),
                ScreeningItem(46, "Upstairs 1 foot together; Ball throw overhand and underhand up to 3 feet"),
                ScreeningItem(47, "Scooter board"),
                ScreeningItem(48, "Stands with both feet on balance beam"),
                ScreeningItem(49, "Walks with 1 foot on balance beam")
            )
        ),
        Domain(
            id = "fine",
            label = "Fine Motor",
            emoji = "✏️",
            colorHex = "#8E44AD",
            scale = listOf("Age appropriate", "Functional", "Developing", "Emerging", "Unable"),
            ranges = listOf(1..10, 11..20, 21..30, 31..40, 41..50),
            items = listOf(
                ScreeningItem(50, "Reach-Palmer pretension"),
                ScreeningItem(51, "Spherical grasp"),
                ScreeningItem(52, "Cylindrical grasp"),
                ScreeningItem(53, "Hook / Grip / Lateral pinch"),
                ScreeningItem(54, "Closes box with lid"),
                ScreeningItem(55, "Imitates vertical line / circle / horizontal line"),
                ScreeningItem(56, "Strings large beads awkwardly"),
                ScreeningItem(57, "Turns paper pages (often several at once)"),
                ScreeningItem(58, "Makes 9- to 10-cube tower"),
                ScreeningItem(59, "Puts six square pegs in pegboard")
            )
        ),
        Domain(
            id = "adl",
            label = "Activity of Daily Living",
            emoji = "🦷",
            colorHex = "#F0A500",
            scale = listOf(
                "Independent",
                "Minimal assistance",
                "Moderate assistance",
                "Maximal assistance",
                "Dependent"
            ),
            ranges = listOf(1..12, 13..24, 25..36, 37..48, 49..60),
            items = listOf(
                ScreeningItem(60, "Drinks from bottle/cup"),
                ScreeningItem(61, "Brushing teeth"),
                ScreeningItem(62, "Combing hair imitation"),
                ScreeningItem(63, "Toileting / gestures using"),
                ScreeningItem(64, "Tolerates bathing"),
                ScreeningItem(65, "Eating"),
                ScreeningItem(66, "Assists dressing"),
                ScreeningItem(67, "Zips and unzips"),
                ScreeningItem(68, "Pulls pants up and down"),
                ScreeningItem(69, "Uses spoon and fork"),
                ScreeningItem(70, "Packs toys/item into bag"),
                ScreeningItem(71, "Remove socks and shoes")
            )
        ),
        Domain(
            id = "sensory",
            label = "Sensory Processing",
            emoji = "🌀",
            colorHex = "#2980B9",
            scale = listOf(
                "Almost never (10%)",
                "Occasionally (25%)",
                "Half the time (50%)",
                "Frequently (75%)",
                "Almost always (90%)"
            ),
            ranges = listOf(1..26, 27..52, 53..78, 79..104, 105..130),
            subSections = listOf(
                SubSection("Vestibular Avoider", listOf(72, 73, 74)),
                SubSection("Vestibular Seeker", listOf(75, 76)),
                SubSection("Proprioceptive", listOf(77, 78)),
                SubSection("Tactile Avoider", listOf(79, 80)),
                SubSection("Tactile Seeker", listOf(81, 82, 83)),
                SubSection("Visual Avoider", listOf(84, 85)),
                SubSection("Visual Seeker", listOf(86, 87)),
                SubSection("Auditory Avoider", listOf(88, 89)),
                SubSection("Auditory Seeker", listOf(90, 91, 92)),
                SubSection("Smell/Taste Avoider", listOf(93, 94)),
                SubSection("Smell/Taste Seeker", listOf(95, 96, 97))
            ),
            items = listOf(
                ScreeningItem(72, "Appears fearful of heights / stair climbing"),
                ScreeningItem(73, "Avoids balancing activities"),
                ScreeningItem(74, "Avoids movement"),
                ScreeningItem(75, "Craves movement"),
                ScreeningItem(76, "Engages in frequent spinning, jumping, bouncing and running"),
                ScreeningItem(77, "Performs excessive clapping, crashing and other pressure-seeking behaviours"),
                ScreeningItem(78, "Seeks more than typical rough-and-tumble play"),
                ScreeningItem(79, "Dislikes and avoids messy play"),
                ScreeningItem(80, "Reacts aggressively to touch"),
                ScreeningItem(81, "Has decreased awareness of pain and temperature"),
                ScreeningItem(82, "Feels excessive need to touch objects and people"),
                ScreeningItem(83, "Constantly mouths objects"),
                ScreeningItem(84, "Is uncomfortable in bright light"),
                ScreeningItem(85, "Avoids eye contact"),
                ScreeningItem(86, "Enjoys looking at moving or spinning objects"),
                ScreeningItem(87, "Enjoys looking at shiny objects"),
                ScreeningItem(88, "Is defensive about sound; covers ears"),
                ScreeningItem(89, "Has difficulty participating in social play"),
                ScreeningItem(90, "Makes repetitive sounds"),
                ScreeningItem(91, "Enjoys loud sounds and repeats them often (e.g. flushing toilet)"),
                ScreeningItem(92, "Appears not to hear sounds, even his/her own name"),
                ScreeningItem(93, "Gags easily when confronted with certain smells/tastes"),
                ScreeningItem(94, "Dislikes new toys that have a strong smell"),
                ScreeningItem(95, "Smears his/her faeces/faces"),
                ScreeningItem(96, "Sniffs or licks objects or persons to discover more"),
                ScreeningItem(97, "Eats non-edible foods (Pica)")
            )
        )
    )

    val totalItemCount: Int = domains.sumOf { it.items.size }
}
