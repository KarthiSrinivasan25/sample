package com.otscreening.app.model

data class ChildInfo(
    val name: String = "",
    val preferredName: String = "",
    val gender: String = "",
    val dob: String = "",
    val assessmentDate: String = "",
    val therapist: String = "",
    val diagnosis: String = "",
    val notes: String = ""
)

data class DomainResult(
    val domain: Domain,
    val rawScore: Int?,
    val interpretationLabel: String,
    val colorIndex: Int // -1 if not assessed
)
