package com.otscreening.app.model

/** A single screenable item within a domain (e.g. "Attention", "Hand flapping"). */
data class ScreeningItem(
    val number: Int,
    val text: String
)

/** A labeled sub-section grouping items by number, used in the Sensory domain. */
data class SubSection(
    val label: String,
    val itemNumbers: List<Int>
)

/** One of the 9 top-level assessment domains. */
data class Domain(
    val id: String,
    val label: String,
    val emoji: String,
    val colorHex: String,
    /** 5 scale descriptors, index 0 = score 1 ... index 4 = score 5 */
    val scale: List<String>,
    /** 5 inclusive (min,max) raw-score ranges corresponding to interpretation levels */
    val ranges: List<IntRange>,
    val items: List<ScreeningItem>,
    val subSections: List<SubSection>? = null
)

/** Interpretation levels shared across all domains, score 1..5 → label */
val INTERPRETATION_LABELS = listOf(
    "Independent performance",
    "Performs with minimal assistance",
    "Performs with moderate assistance",
    "Performs with maximal assistance",
    "Unable to perform"
)

/** Score colors, index 0 = score 1 (best) ... index 4 = score 5 (unable) */
val SCORE_COLORS = listOf(
    0xFF27AE60, // 1 - green
    0xFF3498DB, // 2 - blue
    0xFFF0A500, // 3 - amber
    0xFFE05C4B, // 4 - coral
    0xFF888888  // 5 - grey
)
