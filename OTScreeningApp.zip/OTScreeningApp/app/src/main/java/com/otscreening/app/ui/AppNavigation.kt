package com.otscreening.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import com.otscreening.app.ui.screens.AssessmentScreen
import com.otscreening.app.ui.screens.IntakeScreen
import com.otscreening.app.ui.screens.ResultsScreen
import com.otscreening.app.util.PdfExporter
import com.otscreening.app.viewmodel.ScreeningViewModel

private enum class AppScreen { INTAKE, ASSESS, RESULTS }

@Composable
fun OTScreeningApp(vm: ScreeningViewModel) {
    var screen by remember { mutableStateOf(AppScreen.INTAKE) }
    val context = LocalContext.current

    when (screen) {
        AppScreen.INTAKE -> IntakeScreen(
            onBegin = { info ->
                vm.setChildInfo(info)
                screen = AppScreen.ASSESS
            }
        )
        AppScreen.ASSESS -> AssessmentScreen(
            vm = vm,
            onShowResults = { screen = AppScreen.RESULTS }
        )
        AppScreen.RESULTS -> ResultsScreen(
            vm = vm,
            onBack = { screen = AppScreen.ASSESS },
            onRestart = {
                vm.resetAll()
                screen = AppScreen.INTAKE
            },
            onExportPdf = {
                val uri = PdfExporter.export(context, vm)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        )
    }
}
