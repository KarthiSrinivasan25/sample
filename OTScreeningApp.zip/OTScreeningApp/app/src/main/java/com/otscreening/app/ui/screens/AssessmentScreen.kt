package com.otscreening.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.otscreening.app.model.ScreeningItem
import com.otscreening.app.ui.theme.*
import com.otscreening.app.viewmodel.ScreeningViewModel

private fun hexColor(hex: String): Color {
    val clean = hex.removePrefix("#")
    val value = clean.toLong(16)
    return Color(0xFF000000 or value)
}

@Composable
fun AssessmentScreen(
    vm: ScreeningViewModel,
    onShowResults: () -> Unit
) {
    val domains = vm.domains
    val activeIndex = vm.activeDomainIndex
    // touch scoreVersion so Compose recomposes on score changes
    @Suppress("UNUSED_EXPRESSION") vm.scoreVersion

    Column(modifier = Modifier.fillMaxSize().background(Cream)) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Navy)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "🧒 ${vm.childInfo.name}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    "${vm.scoredCount()} / ${vm.totalItems} items scored",
                    color = Sky,
                    fontSize = 11.sp
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LinearProgressIndicator(
                    progress = { vm.scoredCount().toFloat() / vm.totalItems },
                    modifier = Modifier.width(70.dp).height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = Mint,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
                Button(
                    onClick = onShowResults,
                    colors = ButtonDefaults.buttonColors(containerColor = Coral),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("Results →", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Domain tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(White)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp),
        ) {
            domains.forEachIndexed { i, d ->
                val isActive = i == activeIndex
                val color = hexColor(d.colorHex)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .background(White)
                        .clickable { vm.activeDomainIndex = i }
                        .padding(vertical = 10.dp, horizontal = 10.dp)
                ) {
                    Text(d.emoji, fontSize = 16.sp)
                    Text(
                        d.label.split("(")[0].trim().split(" ").take(2).joinToString(" "),
                        fontSize = 10.sp,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                        color = if (isActive) Navy else G2
                    )
                    val rs = vm.rawScore(d)
                    Text(
                        rs?.toString() ?: "",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                    Box(
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .height(3.dp)
                            .width(28.dp)
                            .background(if (isActive) color else Color.Transparent, RoundedCornerShape(2.dp))
                    )
                }
            }
        }

        val domain = domains[activeIndex]
        val rawScore = vm.rawScore(domain)
        val domainColor = hexColor(domain.colorHex)

        // Domain header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(White)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "${domain.emoji} ${domain.label}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Navy
                )
                Text(
                    "1 = ${domain.scale[0]}  ↔  5 = ${domain.scale[4]}",
                    fontSize = 10.sp,
                    color = G3,
                    lineHeight = 14.sp
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    rawScore?.toString() ?: "—",
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = domainColor
                )
                Text("pts scored", fontSize = 10.sp, color = G3)
            }
        }

        // Items list
        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp)
        ) {
            if (domain.subSections != null) {
                domain.subSections.forEach { sub ->
                    item {
                        Text(
                            "◆ ${sub.label}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = G3,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                    items(sub.itemNumbers) { num ->
                        val it = domain.items.find { i -> i.number == num }
                        if (it != null) {
                            ItemCard(it, vm.getScore(it.number)) { score -> vm.setScore(it.number, score) }
                        }
                    }
                }
            } else {
                items(domain.items) { it ->
                    ItemCard(it, vm.getScore(it.number)) { score -> vm.setScore(it.number, score) }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (activeIndex > 0) {
                        OutlinedButton(
                            onClick = { vm.activeDomainIndex = activeIndex - 1 },
                            modifier = Modifier.weight(1f).height(46.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("← ${domains[activeIndex - 1].emoji} Prev", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                    if (activeIndex < domains.size - 1) {
                        Button(
                            onClick = { vm.activeDomainIndex = activeIndex + 1 },
                            modifier = Modifier.weight(1f).height(46.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Sky)
                        ) {
                            Text("Next ${domains[activeIndex + 1].emoji} →", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    } else {
                        Button(
                            onClick = onShowResults,
                            modifier = Modifier.weight(1f).height(46.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Coral)
                        ) {
                            Text("View Results →", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ItemCard(item: ScreeningItem, selected: Int?, onSelect: (Int) -> Unit) {
    val borderColor = if (selected != null) ScoreColors[selected - 1] else G1
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 7.dp)
            .background(White, RoundedCornerShape(10.dp))
            .border(1.5.dp, borderColor, RoundedCornerShape(10.dp))
            .padding(11.dp)
    ) {
        Row(modifier = Modifier.padding(bottom = 8.dp)) {
            Text(
                "${item.number}.",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = G2,
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(item.text, fontSize = 13.sp, color = Navy, lineHeight = 18.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (s in 1..5) {
                val isSel = selected == s
                val color = ScoreColors[s - 1]
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSel) color.copy(alpha = 0.15f) else Cream,
                            RoundedCornerShape(7.dp)
                        )
                        .border(
                            if (isSel) 2.dp else 1.5.dp,
                            if (isSel) color else G1,
                            RoundedCornerShape(7.dp)
                        )
                        .clickable { onSelect(s) }
                        .padding(vertical = 6.dp, horizontal = 2.dp)
                ) {
                    Text(
                        s.toString(),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isSel) color else G3
                    )
                }
            }
        }
    }
}
