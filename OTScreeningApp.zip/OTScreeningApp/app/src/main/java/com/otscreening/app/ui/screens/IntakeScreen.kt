package com.otscreening.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.otscreening.app.model.ChildInfo
import com.otscreening.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntakeScreen(onBegin: (ChildInfo) -> Unit) {
    var name by remember { mutableStateOf("") }
    var pref by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    val todayStr = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }
    var assessDate by remember { mutableStateOf(todayStr) }
    var therapist by remember { mutableStateOf("") }
    var diagnosis by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var genderExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Cream),
        contentAlignment = Alignment.TopCenter
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(Navy, NavyDark)))
                        .padding(28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🧒", fontSize = 40.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "OT Pediatric Baseline Screening",
                            color = White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Therapist Questionnaire",
                            color = White.copy(alpha = 0.75f),
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = White.copy(alpha = 0.15f)
                        ) {
                            Text(
                                "Age Group: 7 Months to 3 Years",
                                color = White,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        "Complete the child's details before starting. For use by qualified Occupational Therapy practitioners only.",
                        fontSize = 12.sp,
                        color = G2,
                        lineHeight = 18.sp
                    )
                    Spacer(Modifier.height(18.dp))

                    LabeledField("CHILD'S FULL NAME *", name) { name = it }
                    Spacer(Modifier.height(14.dp))
                    LabeledField("CHILD'S PREFERRED NAME", pref) { pref = it }
                    Spacer(Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            FieldLabel("GENDER")
                            ExposedDropdownMenuBox(
                                expanded = genderExpanded,
                                onExpandedChange = { genderExpanded = it }
                            ) {
                                OutlinedTextField(
                                    value = gender,
                                    onValueChange = {},
                                    readOnly = true,
                                    placeholder = { Text("Select") },
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    textStyle = TextStyle(fontSize = 14.sp)
                                )
                                ExposedDropdownMenu(
                                    expanded = genderExpanded,
                                    onDismissRequest = { genderExpanded = false }
                                ) {
                                    listOf("Male", "Female", "Other").forEach { opt ->
                                        DropdownMenuItem(
                                            text = { Text(opt) },
                                            onClick = { gender = opt; genderExpanded = false }
                                        )
                                    }
                                }
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            LabeledField("DATE OF BIRTH", dob, placeholder = "YYYY-MM-DD") { dob = it }
                        }
                    }
                    Spacer(Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            LabeledField("ASSESSMENT DATE", assessDate) { assessDate = it }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            LabeledField("THERAPIST NAME", therapist) { therapist = it }
                        }
                    }
                    Spacer(Modifier.height(14.dp))

                    LabeledField(
                        "DIAGNOSIS / PROVISIONAL DIAGNOSIS",
                        diagnosis,
                        placeholder = "e.g. ASD, GDD, SPD"
                    ) { diagnosis = it }
                    Spacer(Modifier.height(14.dp))

                    FieldLabel("CLINICAL NOTES")
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        placeholder = { Text("Referral reason, observations…") },
                        modifier = Modifier.fillMaxWidth().height(72.dp),
                        textStyle = TextStyle(fontSize = 14.sp)
                    )
                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = {
                            onBegin(
                                ChildInfo(
                                    name = name.trim(),
                                    preferredName = pref.trim(),
                                    gender = gender,
                                    dob = dob,
                                    assessmentDate = assessDate,
                                    therapist = therapist.trim(),
                                    diagnosis = diagnosis.trim(),
                                    notes = notes.trim()
                                )
                            )
                        },
                        enabled = name.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Sky)
                    ) {
                        Text("Begin Assessment →", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = Navy,
        modifier = Modifier.padding(bottom = 4.dp)
    )
}

@Composable
private fun LabeledField(
    label: String,
    value: String,
    placeholder: String = "",
    onChange: (String) -> Unit
) {
    Column {
        FieldLabel(label)
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            placeholder = { if (placeholder.isNotEmpty()) Text(placeholder, fontSize = 13.sp) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = TextStyle(fontSize = 14.sp)
        )
    }
}
