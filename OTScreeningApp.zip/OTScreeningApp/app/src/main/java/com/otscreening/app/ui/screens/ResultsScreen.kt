package com.otscreening.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.otscreening.app.model.Domain
import com.otscreening.app.ui.theme.*
import com.otscreening.app.viewmodel.ScreeningViewModel

private fun hexColor(hex: String): Color {
    val clean = hex.removePrefix("#")
    return Color(0xFF000000 or clean.toLong(16))
}

@Composable
fun ResultsScreen(
    vm: ScreeningViewModel,
    onBack: () -> Unit,
    onRestart: () -> Unit,
    onExportPdf: () -> Unit
) {
    val domains = vm.domains
    @Suppress("UNUSED_EXPRESSION") vm.scoreVersion
    val expanded = remember { mutableStateMapOf<String, Boolean>() }

    val total = vm.totalItems
    val done = vm.scoredCount()
    val domainsAssessed = vm.domainsAssessedCount()

    LazyColumn(modifier = Modifier.fillMaxSize().background(Cream)) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Navy)
                    .padding(18.dp)
            ) {
                TextButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = null, tint = Color.White)
                    Spacer(Modifier.width(4.dp))
                    Text("Back", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text("Assessment Results", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    "${vm.childInfo.name}${if (vm.childInfo.preferredName.isNotBlank()) " (${vm.childInfo.preferredName})" else ""} · ${vm.childInfo.assessmentDate} · ${vm.childInfo.therapist.ifBlank { "—" }}",
                    color = Sky,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(12.dp))
                Surface(
                    color = Color.White.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("$done/$total", color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp)
                        Text(
                            if (done == total) "Assessment Complete" else "Assessment In Progress",
                            color = if (done == total) Score1Green else Amber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            "Items scored · $domainsAssessed of ${domains.size} domains assessed",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        item { LegendRow() }

        item { SummaryBarsCard(vm, domains) }

        items(domains) { d ->
            DomainResultCard(
                domain = d,
                vm = vm,
                isExpanded = expanded[d.id] == true,
                onToggle = { expanded[d.id] = !(expanded[d.id] ?: false) }
            )
        }

        item { ScoreReferenceTable(vm, domains) }

        item { FooterCard(vm) }

        item {
            Column(modifier = Modifier.padding(14.dp)) {
                Button(
                    onClick = onExportPdf,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Sky)
                ) {
                    Icon(Icons.Default.Print, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Export / Save PDF Report", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onRestart,
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("New Assessment", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun LegendRow() {
    val labels = listOf("Score 1 = Best / Independent", "Score 2", "Score 3", "Score 4", "Score 5 = Unable")
    androidx.compose.foundation.layout.FlowRow(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        labels.forEachIndexed { i, label ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(9.dp).background(ScoreColors[i], CircleShape))
                Spacer(Modifier.width(4.dp))
                Text(label, fontSize = 11.sp, color = G3)
            }
        }
    }
}

@Composable
private fun SummaryBarsCard(vm: ScreeningViewModel, domains: List<Domain>) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("Domain Summary", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy)
            Spacer(Modifier.height(10.dp))
            domains.forEach { d ->
                val result = vm.interpret(d)
                val max = d.items.size * 5
                val pct = if (result.rawScore != null) (result.rawScore.toFloat() / max) else 0f
                val color = if (result.colorIndex >= 0) ScoreColors[result.colorIndex] else G2
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 7.dp)) {
                    Text(d.emoji, fontSize = 13.sp, modifier = Modifier.width(20.dp))
                    Column(modifier = Modifier.weight(1f).padding(end = 7.dp)) {
                        Text(d.label, fontSize = 10.sp, color = G3)
                        LinearProgressIndicator(
                            progress = { pct },
                            modifier = Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(5.dp)),
                            color = color,
                            trackColor = G1
                        )
                    }
                    Text(
                        result.rawScore?.let { "$it pts" } ?: "—",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = color,
                        modifier = Modifier.width(50.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DomainResultCard(
    domain: Domain,
    vm: ScreeningViewModel,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    val result = vm.interpret(domain)
    val color = if (result.colorIndex >= 0) ScoreColors[result.colorIndex] else G2
    val domainColor = hexColor(domain.colorHex)

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggle)
                    .padding(13.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(domainColor.copy(alpha = 0.13f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(domain.emoji, fontSize = 18.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(domain.label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy)
                        Text(result.interpretationLabel, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = color)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = color.copy(alpha = 0.13f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            result.rawScore?.let { "$it pts" } ?: "N/A",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = color,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Icon(
                        if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = G2
                    )
                }
            }
            if (isExpanded) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                    domain.items.forEach { it ->
                        val sv = vm.getScore(it.number)
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text("${it.number}.", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = G2, modifier = Modifier.width(24.dp))
                            Text(it.text, fontSize = 12.sp, color = Navy, modifier = Modifier.weight(1f), lineHeight = 16.sp)
                            Text(
                                sv?.toString() ?: "—",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = if (sv != null) ScoreColors[sv - 1] else G2
                            )
                        }
                    }
                    Surface(
                        color = Cream,
                        shape = RoundedCornerShape(7.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) {
                        Text(
                            "Scale: 1=${domain.scale[0]}  →  5=${domain.scale[4]}",
                            fontSize = 10.sp,
                            color = G3,
                            modifier = Modifier.padding(7.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ScoreReferenceTable(vm: ScreeningViewModel, domains: List<Domain>) {
    val levelLabels = listOf("Independent", "Min Assist", "Mod Assist", "Max Assist", "Unable")
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("Score Interpretation Reference", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy)
            Spacer(Modifier.height(10.dp))
            domains.forEach { d ->
                val result = vm.interpret(d)
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    Text("${d.emoji} ${d.label}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy)
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        d.ranges.forEachIndexed { i, range ->
                            val isHit = result.colorIndex == i
                            Surface(
                                color = if (isHit) ScoreColors[i].copy(alpha = 0.18f) else G1,
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        "${range.first}–${range.last}",
                                        fontSize = 9.sp,
                                        color = if (isHit) ScoreColors[i] else G3,
                                        fontWeight = if (isHit) FontWeight.Bold else FontWeight.Normal
                                    )
                                    Text(levelLabels[i], fontSize = 7.sp, color = G3)
                                }
                            }
                        }
                    }
                    Text(
                        "Your score: ${result.rawScore ?: "—"}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (result.colorIndex >= 0) ScoreColors[result.colorIndex] else G2,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FooterCard(vm: ScreeningViewModel) {
    val info = vm.childInfo
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Navy)
    ) {
        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "${info.name}${if (info.preferredName.isNotBlank()) " (${info.preferredName})" else ""}",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            if (info.diagnosis.isNotBlank()) {
                Text("Diagnosis: ${info.diagnosis}", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
            }
            Text(
                "${if (info.dob.isNotBlank()) "DOB: ${info.dob} | " else ""}Assessment Date: ${info.assessmentDate}",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp
            )
            Text("Therapist: ${info.therapist.ifBlank { "—" }}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "OT Pediatric Baseline Screening · Age Group 7 months–3 years · Qualified OT practitioners only",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
            if (info.notes.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("Notes: ${info.notes}", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Parent Signature: ____________________     Therapist Signature: ____________________",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
