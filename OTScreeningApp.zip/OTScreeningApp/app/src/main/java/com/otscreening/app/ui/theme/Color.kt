package com.otscreening.app.ui.theme

import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF1B2C4E)
val NavyDark = Color(0xFF2E5090)
val Sky = Color(0xFF4A90D9)
val Mint = Color(0xFF3DAFA0)
val Coral = Color(0xFFE05C4B)
val Amber = Color(0xFFF0A500)
val Cream = Color(0xFFF4F7FB)
val White = Color(0xFFFFFFFF)
val G1 = Color(0xFFE4EAF2)
val G2 = Color(0xFF9AAABB)
val G3 = Color(0xFF5A6A7E)

val Score1Green = Color(0xFF27AE60)
val Score2Blue = Color(0xFF3498DB)
val Score3Amber = Color(0xFFF0A500)
val Score4Coral = Color(0xFFE05C4B)
val Score5Grey = Color(0xFF888888)

val ScoreColors = listOf(Score1Green, Score2Blue, Score3Amber, Score4Coral, Score5Grey)
