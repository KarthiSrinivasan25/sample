package com.otscreening.app.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import androidx.core.content.FileProvider
import com.otscreening.app.viewmodel.ScreeningViewModel
import java.io.File
import java.io.FileOutputStream

/**
 * Generates a simple multi-page PDF report of the assessment results
 * and returns a content:// Uri suitable for sharing/opening.
 */
object PdfExporter {

    private const val PAGE_WIDTH = 595  // A4 at ~72dpi
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 36f

    fun export(context: Context, vm: ScreeningViewModel): android.net.Uri {
        val document = PdfDocument()
        val titlePaint = Paint().apply { color = Color.BLACK; textSize = 18f; isFakeBoldText = true }
        val headerPaint = Paint().apply { color = Color.DKGRAY; textSize = 11f }
        val sectionPaint = Paint().apply { color = Color.BLACK; textSize = 13f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { color = Color.BLACK; textSize = 10f }
        val scorePaint = Paint().apply { textSize = 10f; isFakeBoldText = true }

        var pageNumber = 1
        var page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
        var canvas = page.canvas
        var y = MARGIN

        fun newPageIfNeeded(extra: Float = 20f) {
            if (y + extra > PAGE_HEIGHT - MARGIN) {
                document.finishPage(page)
                pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
                canvas = page.canvas
                y = MARGIN
            }
        }

        val info = vm.childInfo
        canvas.drawText("OT Pediatric Baseline Screening Report", MARGIN, y, titlePaint)
        y += 22f
        canvas.drawText(
            "${info.name}${if (info.preferredName.isNotBlank()) " (${info.preferredName})" else ""}  ·  Assessment Date: ${info.assessmentDate}",
            MARGIN, y, headerPaint
        )
        y += 14f
        canvas.drawText("Therapist: ${info.therapist.ifBlank { "—" }}   Diagnosis: ${info.diagnosis.ifBlank { "—" }}", MARGIN, y, headerPaint)
        y += 20f

        canvas.drawText(
            "Items scored: ${vm.scoredCount()} / ${vm.totalItems}  ·  Domains assessed: ${vm.domainsAssessedCount()} / ${vm.domains.size}",
            MARGIN, y, headerPaint
        )
        y += 24f

        vm.domains.forEach { domain ->
            newPageIfNeeded(40f)
            val result = vm.interpret(domain)
            canvas.drawText("${domain.emoji}  ${domain.label}", MARGIN, y, sectionPaint)
            y += 14f
            scorePaint.color = if (result.colorIndex >= 0) scoreColorArgb(result.colorIndex) else Color.GRAY
            canvas.drawText(
                "Score: ${result.rawScore ?: "—"}   Interpretation: ${result.interpretationLabel}",
                MARGIN, y, scorePaint
            )
            y += 14f

            domain.items.forEach { item ->
                newPageIfNeeded(14f)
                val sv = vm.getScore(item.number)
                val line = "${item.number}. ${item.text}  —  ${sv ?: "not scored"}"
                canvas.drawText(truncateToWidth(line, bodyPaint, PAGE_WIDTH - 2 * MARGIN), MARGIN + 8f, y, bodyPaint)
                y += 12f
            }
            y += 10f
        }

        newPageIfNeeded(40f)
        y += 10f
        canvas.drawText("Parent Signature: ____________________", MARGIN, y, bodyPaint)
        y += 20f
        canvas.drawText("Therapist Signature: ____________________", MARGIN, y, bodyPaint)

        document.finishPage(page)

        val outDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val safeName = info.name.ifBlank { "child" }.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(outDir, "OT_Screening_${safeName}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    private fun scoreColorArgb(index: Int): Int {
        val hexColors = listOf(0xFF27AE60, 0xFF3498DB, 0xFFF0A500, 0xFFE05C4B, 0xFF888888)
        return (0xFF000000.toInt() or hexColors[index].toInt())
    }

    private fun truncateToWidth(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var end = text.length
        while (end > 0 && paint.measureText(text.substring(0, end) + "…") > maxWidth) end--
        return text.substring(0, end) + "…"
    }
}
