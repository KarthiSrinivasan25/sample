package com.otscreening.app.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.otscreening.app.data.ScreeningData
import com.otscreening.app.model.ChildInfo
import com.otscreening.app.model.Domain
import com.otscreening.app.model.DomainResult
import com.otscreening.app.model.INTERPRETATION_LABELS

class ScreeningViewModel : ViewModel() {

    val domains: List<Domain> = ScreeningData.domains
    val totalItems: Int = ScreeningData.totalItemCount

    var childInfo by mutableStateOf(ChildInfo())
        private set

    // item number -> score (1..5)
    private val _scores = mutableMapOf<Int, Int>()
    val scores: Map<Int, Int> get() = _scores

    var activeDomainIndex by mutableStateOf(0)

    // bump to force Compose recomposition when the score map mutates
    var scoreVersion by mutableStateOf(0)
        private set

    fun setChildInfo(info: ChildInfo) {
        childInfo = info
    }

    fun setScore(itemNumber: Int, value: Int) {
        _scores[itemNumber] = value
        scoreVersion++
    }

    fun getScore(itemNumber: Int): Int? = _scores[itemNumber]

    fun scoredCount(): Int = _scores.size

    fun rawScore(domain: Domain): Int? {
        val relevant = domain.items.mapNotNull { _scores[it.number] }
        return if (relevant.isEmpty()) null else relevant.sum()
    }

    fun interpret(domain: Domain): DomainResult {
        val raw = rawScore(domain)
        if (raw == null) {
            return DomainResult(domain, null, "Not assessed", -1)
        }
        domain.ranges.forEachIndexed { idx, range ->
            if (raw in range) {
                return DomainResult(domain, raw, INTERPRETATION_LABELS[idx], idx)
            }
        }
        // fallback: above max range -> worst level
        return DomainResult(domain, raw, INTERPRETATION_LABELS[4], 4)
    }

    fun allDomainResults(): List<DomainResult> = domains.map { interpret(it) }

    fun domainsAssessedCount(): Int = domains.count { rawScore(it) != null }

    fun resetAll() {
        _scores.clear()
        scoreVersion = 0
        activeDomainIndex = 0
        childInfo = ChildInfo()
    }

    fun isReadyToStart(): Boolean = childInfo.name.isNotBlank()
}
