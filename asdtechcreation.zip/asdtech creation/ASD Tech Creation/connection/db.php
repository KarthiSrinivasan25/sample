<?php
session_start();
$hostname_objConn = "localhost";
$database_objConn = "asd_tech_creation";
$username_objConn = "root";
$password_objConn = "";

$con=mysqli_connect($hostname_objConn, $username_objConn, $password_objConn);
mysqli_select_db($con,$database_objConn);
?>