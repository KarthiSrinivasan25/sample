<?php
include '../connection/db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $res = mysqli_query($con, "SELECT image, icon FROM service WHERE id = $id");
    $row = mysqli_fetch_assoc($res);

    if ($row) {
        if (file_exists("../uploads/service/" . $row['image'])) {
            unlink("../uploads/service/" . $row['image']);
        }
        if (file_exists("../uploads/service/" . $row['icon'])) {
            unlink("../uploads/service/" . $row['icon']);
        }
    }

    // Delete from database
    $delete = mysqli_query($con, "DELETE FROM service WHERE id = $id");

    if ($delete) {
        echo "<script>alert('Service deleted successfully'); window.location.href='service.php';</script>";
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>
