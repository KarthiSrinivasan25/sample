<?php
// Include DB connection
include 'ASD Tech Creation/connection/db.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.css">
    <title>index page</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="assets/image/logo2.png" alt="img" width="80" height="50" class="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
                aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar"
                aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <ul class="navbar-nav ms-auto gap-3">
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="#">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="about.html">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="service.html">Service</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="blog.html">Blog</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="career.html">Career</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="contact.html">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="login.html">Login</a>
                        </li>
                        <li class="nav-item">
                            <p class="mb-2"></p><i class="ri-search-line"></i>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid p-0 mt-5">
        <img src="assets/image/image.jpg" class="img-fluid w-100" alt="Banner Image">
    </div>

    <section id="about" class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <h1 class="text-primary py-4 text-center">ABOUT US</h1>
                <!-- Image Column -->
                <div class="col-12 col-md-6 mb-4 mb-md-0 text-center">
                    <img src="assets/image/nameimg.jpg" alt="companyName" class="img-fluid" style="max-width: 100%;">
                </div>

                <!-- Content Column -->
                <div class="col-12 col-md-6">

                    <h2 class="mb-3">Welcome to <b class="text-danger">ASD Tech Creation</b> –
                        <i class="fs-5">Shaping the Digital Tomorrow</i>
                    </h2>
                    <p>Launching in 2025, ASD Tech Creation is a forward-thinking digital agency
                        dedicated to helping startups, small businesses, and enterprises succeed online. Our mission is
                        to blend
                        creativity with technology, delivering powerful and user-focused digital solutions that drive
                        real results.
                    </p>

                    <p class="fs-5 mb-2">We specialize in:</p>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <i class="bi bi-code-slash text-primary"></i>
                            <b> Custom Web Development</b> –
                            <i>Building fast, secure, and scalable websites tailored to your business.</i>
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-phone text-primary"></i>
                            <b> Mobile App Development</b> –
                            <i>Android apps designed to engage, perform, and grow with your users.</i>
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-graph-up-arrow text-primary"></i>
                            <b> Search Engine Optimization (SEO)</b> –
                            <i>Proven strategies to improve visibility, rank higher and attract organic traffic.</i>
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-cart4 text-primary"></i>
                            <b> E-Commerce Development</b> –
                            <i>Smart, user-friendly online stores built for conversion and growth.</i>
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-easel2 text-primary"></i>
                            <b> UI/UX Design</b> –
                            <i>Clean, modern interfaces focused on seamless user experiences.</i>
                        </li>
                    </ul>

                    <p>With a passion for technology and a commitment to excellence, ASD Tech Creation is your trusted
                        digital partner for turning ideas into reality. We don’t just build projects — we build
                        long-term value.
                    </p>

                    <div class="mt-4">
                        <a href="about.html" class="btn btn-primary">View More</a>
                        <button type="button" class="btn btn-danger">Enquiry</button>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section id="service">
        <div class="container pt-4 bg-white">
            <h1 class="pt-5 text-center text-primary">OUR EXCELLENT SERVICE</h1>
            <div class="row pt-5 justify-content-center">
                <?php
                // Fetch service data
                $query = "SELECT * FROM service Limit 3";
                $result = mysqli_query($con, $query);

                // Loop through each service record
                while ($row = mysqli_fetch_assoc($result)) {
                    $image = 'ASD Tech Creation/uploads/service/' . $row['image'];  // main image
                    $icon = 'ASD Tech Creation/uploads/service/' . $row['icon'];    // icon image
                    $title = strtoupper($row['title']);           // title in uppercase
                    $description = $row['description'];
                    ?>
                    <div class="col-12 col-md-6 col-lg-4 g-4">
                        <div class="card service-card border rounded-4 overflow-hidden">
                            <div class="position-relative overflow-hidden zoom-container">
                                <img src="<?php echo $image; ?>" style="width:100%; height: 200px; object-fit: cover; ">
                                
                            </div>
                            <div class="card-body">

                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h5 class="fw-bold text-success m-0"><?php echo htmlspecialchars($title); ?></h5>
                                    <img src="<?php echo $icon; ?>" width="50" alt="Icon">
                                </div>

                                <div class="divider mb-3">
                                    <div class="dashed-line"></div>
                                    <div class="end-line"></div>
                                </div>

                                <p class="text-muted small mb-4"><?php echo htmlspecialchars($description); ?></p>

                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>


            </div>
        </div>
    </section>

    <section class="text-white mt-5">
        <div class="container custom ">
            <h3 class="text-center py-3">Miles To Go Away</h3>
            <div class="row text-center g-4">
                <div class="col-6 col-md icon">
                    <img src="assets/image/app-development.png" class="bg-white p-2 rounded-4 mb-2" width="60">
                    <div><i class="ri-arrow-down-line fs-2 arrow-icon"></i></div>
                    <p>Projects Completed</p>
                </div>
                <div class="col-6 col-md icon">
                    <img src="assets/image/quality.png" class="bg-white p-2 rounded-4 mb-2" width="60">
                    <div><i class="ri-arrow-down-line fs-2 arrow-icon"></i></div>
                    <p>Years Of Experience</p>
                </div>
                <div class="col-6 col-md icon">
                    <img src="assets/image/communities.png" class="bg-white p-2 rounded-4 mb-2" width="60">
                    <div><i class="ri-arrow-down-line fs-2 arrow-icon"></i></div>
                    <p>Client</p>
                </div>
                <div class="col-6 col-md icon">
                    <img src="assets/image/feedback.png" class="bg-white p-2 rounded-4 mb-2" width="60">
                    <div><i class="ri-arrow-down-line fs-2 arrow-icon"></i></div>
                    <p>Satisfaction Rate</p>
                </div>
                <div class="col-12 col-md icon">
                    <img src="assets/image/domain.png" class="bg-white p-2 rounded-4 mb-2" width="60">
                    <div><i class="ri-arrow-down-line fs-2 arrow-icon"></i></div>
                    <p>Served</p>
                </div>
            </div>
        </div>
    </section>


    <section>
        <div class="container pt-5">
            <h1 class="text-center text-primary pb-4">OUR EXPERTISE IN</h1>
            <div class="row justify-content-center g-4">
                <!-- Repeat this block for each technology -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card w-100 text-center p-3">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <img src="assets/image/html.png" class="expert img-fluid mb-3" alt="html"
                                style="max-width: 85%;">
                            <div class="corner-frame top-left"></div>
                            <div class="corner-frame bottom-right"></div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card w-100 text-center p-3">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <img src="assets/image/css-3.png" class="expert img-fluid mb-3" alt="css"
                                style="max-width: 85%;">
                            <div class="corner-frame top-left"></div>
                            <div class="corner-frame bottom-right"></div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card w-100 text-center p-3">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <img src="assets/image/java-script.png" class="expert img-fluid mb-3" alt="js"
                                style="max-width: 85%;">
                            <div class="corner-frame top-left"></div>
                            <div class="corner-frame bottom-right"></div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card w-100 text-center p-3">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <img src="assets/image/java.png" class="expert img-fluid mb-3" alt="java"
                                style="max-width: 85%;">
                            <div class="corner-frame top-left"></div>
                            <div class="corner-frame bottom-right"></div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card w-100 text-center p-3">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <img src="assets/image/php.png" class="expert img-fluid mb-3" alt="php" width="85%;">
                            <div class="corner-frame top-left"></div>
                            <div class="corner-frame bottom-right"></div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card w-100 text-center p-3">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <img src="assets/image/bootstrap.png" class="expert img-fluid mb-3" alt="bootstrap"
                                width="85%;">
                            <div class="corner-frame top-left"></div>
                            <div class="corner-frame bottom-right"></div>
                        </div>
                    </div>
                </div>



                <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card w-100 text-center p-3">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <img src="assets/image/mysql.png" class="expert img-fluid" alt="Mysql" width="85%;">
                            <div class="corner-frame top-left"></div>
                            <div class="corner-frame bottom-right"></div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>



    <section>
        <div class="container pt-5">
            <h1 class="text-center text-primary pb-5">OUR WORKING PROCESS</h1>
            <div class="row justify-content-between g-4">

                <div class="col-6 col-md-2 step mb-5 mb-md-0">
                    <div class="step-icon">
                        <img src="assets/image/requirement.png" class="img-fluid" alt="Requirement">
                    </div>
                    <div class="step-title">STEP 1</div>
                    <div class="step-desc">Requirement<br>Gathering</div>
                </div>


                <div class="col-6 col-md-2 step mb-5 mb-md-0">
                    <div class="step-icon">
                        <img src="assets/image/work-plan.png" class="img-fluid" alt="Planning">
                    </div>
                    <div class="step-title">STEP 2</div>
                    <div class="step-desc">Planning</div>
                </div>

                <div class="col-6 col-md-2 step mb-5 mb-md-0">
                    <div class="step-icon">
                        <img src="assets/image/settings.png" class="img-fluid" alt="Design & Dev">
                    </div>
                    <div class="step-title">STEP 3</div>
                    <div class="step-desc">Design &<br>Development</div>
                </div>

                <div class="col-6 col-md-2 step mb-5 mb-md-0">
                    <div class="step-icon">
                        <img src="assets/image/testing.png" class="img-fluid" alt="Testing">
                    </div>
                    <div class="step-title">STEP 4</div>
                    <div class="step-desc">Testing</div>
                </div>


                <div class="col-6 col-md-2 step">
                    <div class="step-icon">
                        <img src="assets/image/van.png" class="img-fluid" alt="Delivery">
                    </div>
                    <div class="step-title">STEP 5</div>
                    <div class="step-desc">Delivery &<br>Maintenance</div>
                </div>
            </div>
            <div class="position-relative">
                <div class="process-line">
                    <div class="moving-line"></div>
                </div>
            </div>

        </div>
    </section>

     <section>
        <div class="container-fluid logo-container">
            <div class="logo-track">
                <img src="assets/image/client_logo/leeangadi.png" alt="Logo 1">
                <img src="assets/image/client_logo/logo.jpg" alt="Logo 2">
                <img src="assets/image/client_logo/image.png" alt="Logo 3">
                <img src="assets/image/client_logo/img.png" alt="Logo 4">
                <img src="assets/image/client_logo/img1.png" alt="Logo 5">
                
                <!-- Repeat logos again -->
                <img src="assets/image/client_logo/leeangadi.png" alt="Logo 1">
                <img src="assets/image/client_logo/logo.jpg" alt="Logo 2">
                <img src="assets/image/client_logo/image.png" alt="Logo 3">
                <img src="assets/image/client_logo/img.png" alt="Logo 4">
                <img src="assets/image/client_logo/img1.png" alt="Logo 5">
                
            </div>
        </div>
    </section>

    <section>
        <footer class="text-white bg-dark mt-5">
            <div class="container">
                <div class="row gy-4">
                    <!-- Company Info -->
                    <div class="col-md-3">
                        <h5 class="text-uppercase mb-3">ASD Tech Creation</h5>
                        <p>We provide powerful digital solutions to help your business grow smartly.</p>
                    </div>

                    <!-- Quick Links -->
                    <div class="col-md-2">
                        <h6 class="text-uppercase mb-3">Quick Links</h6>
                        <ul class="list-unstyled">
                            <li><a href="#" class="text-white text-decoration-none">Home</a></li>
                            <li><a href="#" class="text-white text-decoration-none">About</a></li>
                            <li><a href="#" class="text-white text-decoration-none">Services</a></li>
                            <li><a href="#" class="text-white text-decoration-none">Contact</a></li>
                        </ul>
                    </div>

                    <!-- Services -->
                    <div class="col-md-2">
                        <h6 class="text-uppercase mb-3">Our Services</h6>
                        <ul class="list-unstyled">
                            <li><a href="#" class="text-white text-decoration-none">Web Design</a></li>
                            <li><a href="#" class="text-white text-decoration-none">App Development</a></li>
                            <li><a href="#" class="text-white text-decoration-none">SEO & Marketing</a></li>
                            <li><a href="#" class="text-white text-decoration-none">Branding</a></li>
                        </ul>
                    </div>

                    <!-- Social Media -->
                    <div class="col-md-2">
                        <h6 class="text-uppercase mb-3">Follow Us</h6>
                        <ul class="list-unstyled">
                            <li><a href="#" class="text-white text-decoration-none"><i
                                        class="bi bi-facebook me-2"></i>Facebook</a></li>
                            <li><a href="#" class="text-white text-decoration-none"><i
                                        class="bi bi-twitter-x me-2"></i>Twitter</a></li>
                            <li><a href="#" class="text-white text-decoration-none"><i
                                        class="bi bi-instagram me-2"></i>Instagram</a></li>
                            <li><a href="#" class="text-white text-decoration-none"><i
                                        class="bi bi-linkedin me-2"></i>LinkedIn</a></li>
                        </ul>
                    </div>

                    <!-- Newsletter -->
                    <div class="col-md-3">
                        <h6 class="text-uppercase mb-3">Subscribe</h6>
                        <p>Stay updated with our latest news.</p>
                        <form class="input-group shadow rounded-pill overflow-hidden">
                            <input type="email" class="form-control border-0 ps-4" placeholder="Your email">
                            <button class="btn btn-primary px-4" type="submit">Subscribe</button>
                        </form>
                    </div>
                </div>

                <hr class="my-4 border-light">
                <div class="text-center pb-3">
                    <p class="mb-0">&copy; 2025 ASD Tech Creation. All rights reserved.</p>
                </div>
            </div>
        </footer>
    </section>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>