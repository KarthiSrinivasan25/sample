const hamburger = document.querySelector('.header .nav-bar .nav-list .hamburger');
const mobile_menu = document.querySelector('.header .nav-bar .nav-list ul');
const menu_item = document.querySelectorAll('.header .nav-bar .nav-list ul li a');
const header = document.querySelector('.header.container');

hamburger.addEventListener('click', () => {
	hamburger.classList.toggle('active');
	mobile_menu.classList.toggle('active');
});



menu_item.forEach((item) => {
	item.addEventListener('click', () => {
		hamburger.classList.toggle('active');
		mobile_menu.classList.toggle('active');
	});
});


function showModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

function hideModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

document.addEventListener('DOMContentLoaded', (event) => {
    const nightModeToggle = document.getElementById('night-mode-toggle');
    const lightModeToggle = document.getElementById('light-mode-toggle');

    nightModeToggle.addEventListener('click', () => {
        document.body.classList.add('night-mode');
        nightModeToggle.style.display = 'none';
        lightModeToggle.style.display = 'inline';
    });

    lightModeToggle.addEventListener('click', () => {
        document.body.classList.remove('night-mode');
        nightModeToggle.style.display = 'inline';
        lightModeToggle.style.display = 'none';
    });

    // Initial state: hide light mode toggle
    lightModeToggle.style.display = 'none';
});


