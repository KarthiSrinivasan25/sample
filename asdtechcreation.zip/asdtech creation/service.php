<?php
include 'ASD Tech Creation/connection/db.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Service Cards</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.5.0/remixicon.css">
    <style>
        body {
            background-color: #f0f2ff;
        }

         .nav-link:hover {
            color: #007bff !important;
        }

        .service-card {
            background-color: #f8f9ff;
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .service-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 15px;
        }

        .icon-circle {
            width: 60px;
            height: 60px;
            background: #3d4eff;
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            margin: -30px auto 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .service-title {
            font-weight: 600;
            font-size: 1.2rem;
        }

        .read-more-btn {
            background: #3d4eff;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 8px;
            margin-top: 20px;
            font-weight: 600;
            transition: background 0.3s;
        }


        .service-card:hover .read-more-btn {
            background: #28e0dd;
        }

        /* Rotate animation */
        .rotate-icon {
            transition: transform 0.5s ease-in-out;
        }

        .icon-wrapper:hover .rotate-icon {
            transform: rotate(360deg);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="assets/image/logo.jpg" alt="img" width="80" height="50" class="">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
                aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar"
                aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <ul class="navbar-nav ms-auto gap-3">
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="index.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="index.html">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="service.html">Service</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="blog.html">Blog</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="career.html">Career</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="contact.html">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-dark" href="login.html">Login</a>
                        </li>
                        <li class="nav-item">
                            <p class="mb-2"></p><i class="ri-search-line"></i>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <h1 class="mt-5 text-center">SERVICE</h1>
        <div class="row g-4 justify-content-center">
       
            <?php
            $query = "SELECT * FROM service";
            $result = mysqli_query($con, $query);

            while ($row = mysqli_fetch_assoc($result)) {
                $image = 'ASD Tech Creation/uploads/service/' . $row['image']; 
                $icon = 'ASD Tech Creation/uploads/service/' . $row['icon'];                      
                $title = $row['title'];
                $description = $row['description'];
                ?>
                <div class="col-md-4 col-sm-6 icon-wrapper">
                    <div class="service-card">
                        <img src="<?php echo $image; ?>" alt="<?php echo htmlspecialchars($title); ?>"
                            class="service-image">

                        <div class="icon-wrapper position-relative" style="margin-top: -40px;">
                            <div class="bg-white rounded-circle p-2 d-inline-flex justify-content-center align-items-center rotate-icon"
                                style="width: 80px; height: 80px;">
                                <div class="bg-primary rounded-circle d-flex justify-content-center align-items-center"
                                    style="width: 60px; height: 60px;">
                                    <img src="<?php echo $icon; ?>" alt="<?php echo htmlspecialchars($title); ?>"
                            class="service-icon" style="width: 40px; height: 40px;">
                                </div>
                            </div>
                        </div>

                        <h5 class="service-title mt-3"><?php echo htmlspecialchars($title); ?></h5>
                        <p><?php echo htmlspecialchars($description); ?></p>
                        <button class="read-more-btn">Read More</button>
                    </div>
                </div>
                <?php
            }
            ?>


        </div>
    </div>

    <section>
        <footer class="text-white bg-dark mt-5">
            <div class="container">
                <div class="row gy-4">
                    <!-- Company Info -->
                    <div class="col-md-3">
                        <h5 class="text-uppercase mb-3">ASD Tech Creation</h5>
                        <p>We provide powerful digital solutions to help your business grow smartly.</p>
                    </div>

                    <!-- Quick Links -->
                    <div class="col-md-2">
                        <h6 class="text-uppercase mb-3">Quick Links</h6>
                        <ul class="list-unstyled">
                            <li><a href="#" class="text-white text-decoration-none">Home</a></li>
                            <li><a href="#" class="text-white text-decoration-none">About</a></li>
                            <li><a href="#" class="text-white text-decoration-none">Services</a></li>
                            <li><a href="#" class="text-white text-decoration-none">Contact</a></li>
                        </ul>
                    </div>

                    <!-- Services -->
                    <div class="col-md-2">
                        <h6 class="text-uppercase mb-3">Our Services</h6>
                        <ul class="list-unstyled">
                            <li><a href="#" class="text-white text-decoration-none">Web Design</a></li>
                            <li><a href="#" class="text-white text-decoration-none">App Development</a></li>
                            <li><a href="#" class="text-white text-decoration-none">SEO & Marketing</a></li>
                            <li><a href="#" class="text-white text-decoration-none">Branding</a></li>
                        </ul>
                    </div>

                    <!-- Social Media -->
                    <div class="col-md-2">
                        <h6 class="text-uppercase mb-3">Follow Us</h6>
                        <ul class="list-unstyled">
                            <li><a href="#" class="text-white text-decoration-none"><i
                                        class="bi bi-facebook me-2"></i>Facebook</a></li>
                            <li><a href="#" class="text-white text-decoration-none"><i
                                        class="bi bi-twitter-x me-2"></i>Twitter</a></li>
                            <li><a href="#" class="text-white text-decoration-none"><i
                                        class="bi bi-instagram me-2"></i>Instagram</a></li>
                            <li><a href="#" class="text-white text-decoration-none"><i
                                        class="bi bi-linkedin me-2"></i>LinkedIn</a></li>
                        </ul>
                    </div>

                    <!-- Newsletter -->
                    <div class="col-md-3">
                        <h6 class="text-uppercase mb-3">Subscribe</h6>
                        <p>Stay updated with our latest news.</p>
                        <form class="input-group shadow rounded-pill overflow-hidden">
                            <input type="email" class="form-control border-0 ps-4" placeholder="Your email">
                            <button class="btn btn-primary px-4" type="submit">Subscribe</button>
                        </form>
                    </div>
                </div>

                <hr class="my-4 border-light">
                <div class="text-center pb-3">
                    <p class="mb-0">&copy; 2025 ASD Tech Creation. All rights reserved.</p>
                </div>
            </div>
        </footer>
    </section>

</body>

</html>