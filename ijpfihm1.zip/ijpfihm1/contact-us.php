<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

</head>

<body>




<?php
  
  $contact = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="cont-out">
<div class="container">
<h1>Contact Us</h1>

<div class="row">



<div class="col-lg-5" data-aos="fade-right"  data-aos-duration="1000">
<div class="two-out">



<div class="cont-1">
<div class="cont-in">
<img src="images/contact/1.png" />
</div>



<div class="cont-2">
<p class="loop-1">Imm. Heart of Mary Provincialate,<br /> Rajakambeeram, Thirumohoor B.O, Y.<br /> Othakadai Post, Madurai -625 107.</p>

<p class="loop-2">Imm. Heart of Mary<br /> Provincialate, Rajakambeeram,<br /> Thirumohoor B.O, Y. Othakadai<br />  Post, Madurai -625 107.</p>

</div>
</div><!--cont-1-->




<div class="cont-1">

<div class="cont-in">
<img src="images/contact/2.png" />
</div>
<div class="cont-2">
<p>   <a  href="tel: 0452 - 2422663"> 0452 - 2422663, </a>   <a  href="tel: 2422856"> 2422856</a></p>
</div>
</div><!--cont-1-->



<div class="cont-1">

<div class="cont-in">
<img src="images/contact/3.png" />
</div>
<div class="cont-2">

<p> <a  href="mailto:immaculateinfant@gmail.com ">immaculateinfant@gmail.com </a> </p>
</div>
</div><!--cont-1-->




<div class="cont-1">

<div class="cont-in">
<img src="images/contact/4.png" />
</div>

<div class="cont-2">


<div class="so-22">
         
      <div class="social1">
        <a href="#" target="_blank"> <i class="fa fa-facebook"></i></a>
           </div>
           
             <div class="social1" >
             <a href="#"  target="_blank">  <i class="fa fa-instagram"></i></a>
        </div>
           
             <div class="social1" >
           
      <a href="#"  target="_blank">      <i> <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
  <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z"/>
</svg></i></a>
         
          </div>
           
           <div class="social1" style="margin-right:0px;">
             <a href="#"  target="_blank">  <i class="fa fa-youtube-play"></i></a>
        </div>
       
</div>


</div><!--cont-2-->
</div><!--cont-1-->

</div><!--two-out-->
</div><!--col-lg-4-->











<div class="col-lg-7" data-aos="fade-left"  data-aos-duration="1000">
<div class="map-out1">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d125766.19577313715!2d78.04042174433806!3d9.917826796761636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b00c582b1189633%3A0xdc955b7264f63933!2sMadurai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1745648842684!5m2!1sen!2sin"  style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
</div><!--col-lg-8-->


</div><!--row-->
</div>
</div>





<div class="clearfix"></div>













 <?php include("footer.php") ?>

</body>
</html>
