<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>


 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.css" integrity="sha512-Woz+DqWYJ51bpVk5Fv0yES/edIMXjj3Ynda+KWTIkGoynAMHrqTcDUQltbipuiaD5ymEo9520lyoVOo9jCQOCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
 

</head>

<body>




<?php
  
  $whatwedo = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>

</div>




<div class="mini-out">
<div class="container">
<h1>Education Commission </h1>
<div class="row">






<div class="col-lg-6">

<div class="mini-2">
<a href="images/ministry/education-ministry.jpg" data-lightbox="models" class="image">
<img src="images/ministry/education-ministry.jpg" />
</a>
</div>
</div><!--col-lg-6-->



<div class="col-lg-6">




<table>
 
  <tr>
    <td>
   
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Adaikala Mary Innasi</p>
</div>
</div></td>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Theophila Mary</p>
</div>
</div>
</td>
  
  </tr>
  
  <tr>
    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr.  Mary Rita</p>
</div>
</div></td>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Sabin Mary</p>
</div>
</div></td>
    
  </tr>
  
  <tr>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Bella Jacintha Mary</p>
</div>
</div>
</td>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Libo Mary Rayappan</p>
</div>
</div></td>
 
  </tr>
  
  <tr>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Jenitta Mary Arockiasamy</p>
</div>
</div></td>
    <td><div class="mini-3" style="margin-bottom:0px;">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Meldintha Mary Maria Doss</p>
</div>
</div>
</td>
  
  </tr>
  

  
</table>



</div><!--col-lg-6-->


</div><!--row-->


<div class="gal-out">
<div class="row">




<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1">
<div class="gaa-2">
 <a href="images/Convent/9.jpg" data-lightbox="models" class="image">
<img src="images/Convent/9.jpg" />

<h4>St. Antony's Primary School<br /> Mullanganavilai</h4>
</a>
</div>
</div>
</div>



<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1">
<div class="gaa-2">
 <a href="images/Convent/11.jpg" data-lightbox="models" class="image">
<img src="images/Convent/11.jpg" />

<h4>St. Antony's High School<br /> Mullanganavilai</h4>
</a>
</div>
</div>
</div>



<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1">
<div class="gaa-2">
 <a href="images/Convent/12.jpg" data-lightbox="models" class="image">
<img src="images/Convent/12.jpg" />

<h4>St. Thomas Boarding For  Childran<br /> Kovilur Dharmapuri</h4>
</a>
</div>
</div>
</div>


<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1">
<div class="gaa-2">
 <a href="images/Convent/8.jpg" data-lightbox="models" class="image">
<img src="images/Convent/8.jpg" />

<h4>Little Flower Nursery & Primary School</h4>
</a> 
</div>
</div>
</div>

<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1" style="margin-bottom:0px;">
<div class="gaa-2">
 <a href="images/Convent/13.jpg" data-lightbox="models" class="image">
<img src="images/Convent/13.jpg" />

<h4>St.Thomas Primary School</h4>
</a>
</div>
</div>
</div>





</div><!--row-->
</div>





</div>
</div>





<div class="clearfix"></div>











 <?php include("footer.php") ?>
  
 <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox-plus-jquery.js" integrity="sha512-0rYcJjaqTGk43zviBim8AEjb8cjUKxwxCqo28py38JFKKBd35yPfNWmwoBLTYORC9j/COqldDc9/d1B7dhRYmg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>



 
 

</body>
</html>
