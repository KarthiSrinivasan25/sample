<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.css" integrity="sha512-Woz+DqWYJ51bpVk5Fv0yES/edIMXjj3Ynda+KWTIkGoynAMHrqTcDUQltbipuiaD5ymEo9520lyoVOo9jCQOCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>




<?php
  
  $whatwedo = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="mini-out">
<div class="container">
<h1>Finance Commission </h1>
<div class="row">





<div class="col-lg-6">

<div class="mini-2">
<a href="images/ministry/finance-commission.jpg" data-lightbox="models" class="image">
<img src="images/ministry/finance-commission.jpg" />
</a>
</div>


</div><!--col-lg-6-->






<div class="col-lg-6">



<table>
 
  <tr>
    <td>
  
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Arul Jothi Arumairaj</p>
</div>
</div></td>


    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Reeta Mary Francis</p>
</div>
</div></td>
  
  </tr>
  
  
  
  
  
  <tr>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Thelespore Mary Esther</p>
</div>
</div></td>
    <td>

<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Vidhya Sheeba Rani</p>
</div>
</div></td>
   
  </tr>
  
  
  
  
  
  
  
  
  
  
  
  
  <tr>
    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Sabin Mary</p>
</div>
</div></td>
    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Jeane De Chantal Mary</p>
</div>
</div></td>
    
  </tr>
  
  
  <tr>
    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Fedoline Mary Jothi</p>
</div>
</div></td>
    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. D. Chithra Gnana Pragasam</p>
</div>
</div>
</td>
   
  </tr>
  
  
  
   <tr>
    <td style="border:0px;">
    <div class="mini-3" style="margin-bottom:0px;">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Maria Josephine Mary Antonisamy</p>
</div>
</div></td>
  
  
  </tr>
  
  
  
  
  
  
  
  
</table>


</div>
</div><!--col-lg-6-->


</div><!--row-->
</div>
</div>





<div class="clearfix"></div>











 <?php include("footer.php") ?>
 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox-plus-jquery.js" integrity="sha512-0rYcJjaqTGk43zviBim8AEjb8cjUKxwxCqo28py38JFKKBd35yPfNWmwoBLTYORC9j/COqldDc9/d1B7dhRYmg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</body>
</html>
