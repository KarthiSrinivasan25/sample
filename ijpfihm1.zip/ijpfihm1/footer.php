
<div class="footer-outer">
<div class="container">

<div class="f1">
<div class="fot-logo">
<a href="index.php"><img src="images/header/logo.png" /><h1>INFANT JESUS PROVINCE<br /> <b>MADURAI</b></h1></a>
</div>
</div><!--f1-->



<div class="f2">
<div class="row">

<div class="col-lg-4 f3">

<div class="fot-links">
<h4>Our Services</h4>

</div>

<ul>
<li class="fot-bulletet fot-bulletet1 fot-bulletet2"><span><a href="social-commission.php">Social  Commission </a></span></li>
<li class="fot-bulletet fot-bulletet1 fot-bulletet2"><span><a href="finance-commission.php">Finance Commission  </a></span></li>
<li class="fot-bulletet fot-bulletet1 fot-bulletet2"><span><a href="formation-ministry.php">Formation Ministry</a></span></li>
<li class="fot-bulletet fot-bulletet1 fot-bulletet2"><span><a href="education-commission.php"> Education Commission </a></span></li>
<li class="fot-bulletet fot-bulletet1 fot-bulletet2"><span><a href="evangelization-ministry.php">Evangelization Ministry</a></span></li>
<li class="fot-bulletet fot-bulletet1 fot-bulletet2"><span><a href="medical-ministry.php"> Medical Ministry</a></span></li>





</ul>


</div><!--col-lg-4-->



<div class="col-lg-4 f3">

<div class="fot-links">
<h4>Quick Links</h4>

</div>

<ul>
<li class="fot-bulletet fot-bulletet1"><span><a href="index.php">Home</a></span></li>
<li class="fot-bulletet fot-bulletet1"><span><a href="#">   Who we are</a></span></li>

<li class="fot-bulletet fot-bulletet1"><span><a href="#"> Administration</a></span></li>
<li class="fot-bulletet fot-bulletet1"><span><a href="#"> What we do </a></span></li>
<li class="fot-bulletet fot-bulletet1"><span><a href="gallery.php"> Gallery </a></span></li>
<li class="fot-bulletet fot-bulletet1"><span><a href="contact-us.php">Contact Us</a></span></li>


</ul>


</div><!--col-lg-4-->



<div class="col-lg-4 f4">

<div class="fot-links">
<h4>Address</h4>

</div>


	 <p class="footer-mail-link " id="con-1"><img src="images/footer/1.png"><a href="#">Imm. Heart of Mary Provincialate,<br /> Rajakambeeram, Thirumohoor B.O, Y.<br /> Othakadai Post, Madurai -625 107.</a></p>
     <p class="footer-mail-link "><img src="images/footer/3.png">    <a  href="tel: 0452 - 2422663"> 0452 - 2422663, </a>   <a  href="tel: 2422856"> 2422856</a>  </p> 
    <p class="footer-mail-link " style="margin-bottom:0px !important;"><img src="images/footer/2.png">  <a  href="mailto:immaculateinfant@gmail.com ">immaculateinfant@gmail.com </a></p>


</div><!--col-lg-4-->



</div><!--row-->

<div class="footer-bottom">

<div class="copy-1">

<p>Copyright &copy; 2025 IJPFIHM</p>
</div>


<div class="copy-2">
<p>Website Developed by <a href="https://www.bestwebmasterz.com/" target="_blank" style="color:#fff; text-decoration:none; ">Best Webmasterz</a></p>
</div>

</div><!--footer-bottom-->

</div><!--f2-->





</div><!--container-->
</div>





<div class="clearfix"></div>










<!---Slick Slider Links-->
 <link rel="stylesheet" type="text/css" href="slick/slick.css">
       <link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
  


 <script src="slick/slick.js" type="text/javascript" charset="utf-8"></script>
     
       <script type="text/javascript">  
        
       $(document).on('ready', function() {

$(".services").slick({
    
        dots: true,
        infinite: true,
		autoplay:true,
		arrow:false,
        slidesToShow: 4,
		 slidesToScroll: 4,

		
		responsive: [
       {
            breakpoint: 1200,
            settings: {
               slidesToShow: 3,
			    slidesToScroll: 3,
               
            }
        },
		
		{
            breakpoint: 992,
            settings: {
               slidesToShow: 2,
			    slidesToScroll: 2,
              
            }
			},
			{
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
				 slidesToScroll: 2,
             
            }
			},
			
		{
            breakpoint: 581,
            settings: {
                slidesToShow: 1,
				 slidesToScroll: 1,
             
            }
			},
			
			{
            breakpoint: 481,
            settings: {
                slidesToShow: 1,
				 slidesToScroll: 1,
               
            }
        },
		
		
		
        
	 ]
	});
	

});
</script>






     <script type="text/javascript">  

$(document).on('ready', function() {

$(".events").slick({
    
        dots: true,
        infinite: true,
		autoplay:true,
		arrow:false,
        slidesToShow: 4,
		 slidesToScroll: 4,

		
		responsive: [
       {
            breakpoint: 1200,
            settings: {
               slidesToShow: 2,
			    slidesToScroll: 2,
               
            }
        },
		
		{
            breakpoint: 992,
            settings: {
               slidesToShow: 2,
			    slidesToScroll: 2,
              
            }
			},
			{
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
				 slidesToScroll: 1,
             
            }
			},
			
		{
            breakpoint: 581,
            settings: {
                slidesToShow: 1,
				 slidesToScroll: 1,
             
            }
			},
			
			{
            breakpoint: 481,
            settings: {
                slidesToShow: 1,
				 slidesToScroll: 1,
               
            }
        },
		
		
		
        
	 ]
	});
	
	

});
</script>




 
<!---animation-->
<script>
  AOS.init();
</script>

