<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.css" integrity="sha512-Woz+DqWYJ51bpVk5Fv0yES/edIMXjj3Ynda+KWTIkGoynAMHrqTcDUQltbipuiaD5ymEo9520lyoVOo9jCQOCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>




<?php
  
  $whatwedo = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="mini-out">
<div class="container">




<h1>Formation Commission </h1>
<div class="row">





<div class="col-lg-6">

<div class="mini-2">
<a href="images/ministry/formation-ministry.jpg" data-lightbox="models" class="image">
<img src="images/ministry/formation-ministry.jpg" />
</a>
</div>



</div><!--col-lg-6-->






<div class="col-lg-6">



<table>
 
  <tr>
    <td>



<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Lilly Pushpa Mary Susaimuthu</p>
</div>
</div>
</td>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Ireneus Mary Philomine Ratna Bai</p>
</div>
</div></td>
 
  </tr>
  
  
  <tr>
    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Maria Brusy Karloose</p>
</div>
</div></td>
    <td>

<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Barnabas Ubakara Mary</p>
</div>
</div></td>
 
  </tr>
  
  
  
  <tr>
    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Sabin Mary</p>
</div>
</div></td>
    <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Baby Gnanamani</p>
</div>
</div></td>
 
  </tr>
  
  
  <tr>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Arockia Mary Kulandaisamy</p>
</div>
</div></td>
    <td><div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Antony Rincy Irudhaya Micheal</p>
</div>
</div>

</td>
 
  </tr>
  <tr>
  
    <td><div class="mini-3" >
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Clara Sepasthi</p>
</div>
</div>
</td>
    <td><div class="mini-3" style="margin-bottom:0px;">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Kala Jeyaselvi Arulanandam</p>
</div>
</div>
</td>

  </tr>
 
  
</table>



</div><!--col-lg-6-->


</div><!--row-->




<h1 style="margin-top:25px;">Formation Journey in the Infant Jesus Province</h1>


<div class="fm-1" data-aos="fade-up"  data-aos-duration="1000">

<div class="fm-2">
<h4>FIHM Congregation</h4>
</div>

<div class="fm-3">

<div class="fm-4">
<img src="images/ministry/bg.png" />
</div>

<div class="fm-5">
<p>The formation journey in the Infant Jesus Province of the Franciscan Sisters of the Immaculate Heart of Mary (FIHM) is a sacred and transformative process. It begins with the “Come and See” stage, where young women are invited to experience community life, prayer, and ministry, discerning their call to religious life.</p>
</div>

</div><!--fm-3-->


<div class="fm-3">

<div class="fm-4">
<img src="images/ministry/bg.png" />
</div>

<div class="fm-5">
<p>Those who express a genuine interest enter the Aspirancy, a period focused on deepening personal prayer, understanding religious life, and learning about the charism of the FIHM congregation. This is followed by the Postulancy, where candidates are gradually introduced into community living and apostolic involvement while continuing their personal and spiritual formation.</p>
</div>

</div><!--fm-3-->


<div class="fm-3">

<div class="fm-4">
<img src="images/ministry/bg.png" />
</div>

<div class="fm-5">
<p>The Novitiate is the heart of initial formation—a two-year period of intense spiritual training and deeper immersion into the FIHM way of life. Novices learn the Rule of Life, Church teachings, and Franciscan spirituality, culminating in the First Profession of Vows.</p>
</div>

</div><!--fm-3-->




<div class="fm-3">

<div class="fm-4">
<img src="images/ministry/bg.png" />
</div>

<div class="fm-5">
<p>Following this, the sisters enter the Juniorate, a time of integrating vowed life with academic and pastoral formation. Junior sisters deepen their understanding of consecrated life while engaging in ministry and pursuing further education.</p>
</div>

</div><!--fm-3-->




<div class="fm-3">

<div class="fm-4">
<img src="images/ministry/bg.png" />
</div>

<div class="fm-5">
<p>Ongoing Formation is a lifelong commitment for all professed sisters. It includes spiritual renewal, retreats, and theological updates. Sisters are also encouraged to pursue graduate, post-graduate, and doctoral studies in fields aligned with the mission of the congregation. These academic endeavors empower them to serve the Church and society with greater knowledge, competence, and compassion.</p>
</div>

</div><!--fm-3-->


<div class="fm-3">

<div class="fm-4">
<img src="images/ministry/bg.png" />
</div>

<div class="fm-5">
<p>At every stage, the formation process nurtures a Christ-centered life rooted in the Gospel, shaped by Franciscan values, and inspired by the Immaculate Heart of Mary—preparing sisters to live joyfully and serve faithfully in the mission of Christ. </p>
</div>

</div><!--fm-3-->




</div><!--fm-1-->











</div>
</div>





<div class="clearfix"></div>











 <?php include("footer.php") ?>
  
   <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox-plus-jquery.js" integrity="sha512-0rYcJjaqTGk43zviBim8AEjb8cjUKxwxCqo28py38JFKKBd35yPfNWmwoBLTYORC9j/COqldDc9/d1B7dhRYmg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


</body>
</html>
