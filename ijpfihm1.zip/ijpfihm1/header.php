
<!---header-->

<div class="join-1">
     
 <div class="menu-out">
<div class="header" id="myheader">
  <div class="container">
   
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
<!--  <div class="container-fluid" style="padding:0px;">-->
    <a class="navbar-brand" href="index.php"><img src="images/header/logo.png" /><h1>INFANT JESUS PROVINCE<br /> <b>MADURAI</b></h1></a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon fa fa-bars"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      
        <li class="nav-item">
          <a class="nav-link <?php if(isset($index)) echo 'active'; ?>" aria-current="page" href="index.php">Home</a>
        </li>
     
        
        <li class="nav-item dropdown">
          <a class="nav-link <?php if(isset($whoweare)) echo 'active'; ?> dropdown-toggle " href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        Who we are
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="our-founder.php">Our Founder</a></li>
            <li><a class="dropdown-item" href="province-history.php">History of IJP</a></li>
             <li><a class="dropdown-item" href="join-ijp.php" style="border-bottom:0px;">Join IJP</a></li>
             
          </ul>
        </li>
        
        
         <li class="nav-item dropdown">
          <a class="nav-link <?php if(isset($administration)) echo 'active'; ?> dropdown-toggle " href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        Administration
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="provincial-team.php">Provincial Team</a></li>
            <li><a class="dropdown-item" href="#">Commissions</a></li>
             <li><a class="dropdown-item" href="#" style="border-bottom:0px;">Committees</a></li>
             
          </ul>
        </li>
        
        
        
        
         <li class="nav-item dropdown">
          <a class="nav-link <?php if(isset($whatwedo)) echo 'active'; ?>  dropdown-toggle " href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        What we do
          </a>
          <ul class="dropdown-menu" id="drop-1">
           <li><a class="dropdown-item" href="social-commission.php">Social Commission</a></li>
            <li><a class="dropdown-item" href="finance-commission.php">Finance Commission </a></li>
            <li><a class="dropdown-item" href="formation-ministry.php">Formation Ministry</a></li>
            <li><a class="dropdown-item" href="education-commission.php">Education Commission</a></li>
             <li><a class="dropdown-item" href="evangelization-ministry.php" >Evangelization Ministry</a></li>
             <li><a class="dropdown-item" href="medical-ministry.php" style="border-bottom:0px;">Medical Ministry</a></li>
            
             
          </ul>
        </li>
        
        <li class="nav-item">
          <a class="nav-link <?php if(isset($events)) echo 'active'; ?>  " href="#">Events</a>
        </li>
        
           <li class="nav-item">
          <a class="nav-link <?php if(isset($blog)) echo 'active'; ?>  " href="#">Blog</a>
        </li>
      
      
        <li class="nav-item dropdown">
          <a class="nav-link <?php if(isset($gallery)) echo 'active'; ?>  dropdown-toggle " href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
       Resources
          </a>
          <ul class="dropdown-menu" id="drop-1">
           <li><a class="dropdown-item" href="gallery.php">Photos</a></li>
           <li><a class="dropdown-item" href="#" style="border-bottom:0px;">Videos</a></li>
            
             
          </ul>
        </li>
        
        
  
        
        
         <li class="nav-item">
          <a class="nav-link <?php if(isset($contact)) echo 'active'; ?> " href="contact-us.php">Contact Us</a>
        </li>
        
        </ul>
        
     
</div>
</nav>
</div>





</div>
</div> 

 
</div><!--join-1-->
