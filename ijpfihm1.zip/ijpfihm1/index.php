<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>


 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.css" integrity="sha512-Woz+DqWYJ51bpVk5Fv0yES/edIMXjj3Ynda+KWTIkGoynAMHrqTcDUQltbipuiaD5ymEo9520lyoVOo9jCQOCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>




 <?php
  
  $index = true;
  include("header.php");
  ?>




 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">







  <!---Banner-->


<div class="banner-out">
<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" >
<!--  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>-->
  <div class="carousel-inner">
  
  
      <div class="carousel-item active">
      <img class="m1" src="images/banner/1.jpg" class="d-block w-100" alt="...">
       <img class="m2" src="images/banner/01.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">

      </div>
    </div>
    
  
      <div class="carousel-item ">
      <img class="m1" src="images/banner/1.jpg" class="d-block w-100" alt="...">
     <img class="m2" src="images/banner/01.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">

      </div>
    </div>
    
  
  
  </div>
  
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
  
</div>
</div><!--banner-out-->







</div><!--header_outer-->

<div class="clearfix"></div>

<div class="news-out">
<marquee direction="left" class="just conttt" scrollamount="15" onMouseOver="this.stop(true);" onMouseOut="this.start();">




 <div class="mm-in1">
 <div class="mm-in">
<img src="images/news/bg.png" /> 
</div>

 <div class="title part-fff">
Love Your Neighbor as yourself 

 </div>  
                              



 <div class="mm-in">
<img src="images/news/bg.png" /> 
</div>

 <div class="title part-fff">
Love Your Neighbor as yourself 

 </div>  
                             



 <div class="mm-in">
<img src="images/news/bg.png" /> 
</div>

 <div class="title part-fff">
Love Your Neighbor as yourself 

 </div> 
 
  
   </div>                                
</marquee>
</div>
  <div class="clearfix"></div>




<div class="abt-out">
<div class="container">
<div class="row">


<div class="col-lg-6" data-aos="fade-right"  data-aos-duration="1000">
<div class="abt-1">

<div class="abt-ct">

<h4><img src="images/bg.png" / style=" margin-right: 6px;">About Us</h4>
<h1>We Are A Church<br /> That Believes In God</h1>

<p>In the spirit of love, hospitality and social justiceserve the people of the greater Cypress area. We believe that through the faith become family to one another in Jesus.</p>

</div><!--abt-ct-->


<div class="point-out">
<p><img src="images/about/bg1.png" />Place Of Heaven ludus petentium, suas idque</p>
<p><img src="images/about/bg1.png" />Study Bible veniam oblique propriae vim dicant.</p>
<p style="margin-bottom:0px;"><img src="images/about/bg1.png" />Church Pastors everti oblique pertinax con.</p>
</div><!--point-out-->

<div class="abt-btn">
<a href="province-history.php"> About Us 
<div class="abt-btn1"><img src="images/about/bg2.png" />
</a>
</div>
 </div>


</div>
</div><!--col-lg-6-->





<div class="col-lg-6" data-aos="fade-left"  data-aos-duration="1000">
<div class="row">

<div class="col-lg-6 col-md-6 col-sm-6">

<div class="ab-1">
<img src="images/about/bg.png" />
</div>

<div class="ab-2">
<img src="images/about/1.jpg" />
</div>

</div><!--col-lg-6-->



<div class="col-lg-6 col-md-6 col-sm-6">
<div class="ab-2">
<img src="images/about/2.jpg" />
</div>
</div><!--col-lg-6-->





</div><!--row-->
</div><!--col-lg-6-->




</div><!--row-->
</div>
</div>




<div class="clearfix"></div>


<div class="service-out">
<div class="container">
<h4><img src="images/bg.png"  style=" margin-right: 6px;" />	What we do</h4>
<h1>Loving God, helping others
<br />and serving the world</h1>
<div class="row">

 <section class="services slider">

<div class="col-lg-3" data-aos="fade-up"  data-aos-duration="1000">
<div class="ser-1">

<div class="ser-2">
<img src="images/services/1.jpg" />
</div>


<div class="what-1">
<div class="ser-3">
<h4>Formation Ministry</h4>
<p>Formation Ministry supports women in discovering their vocation through prayer, community living, and learning the values of religious life.</p>
</div>

<div class="ser-4">
<a href="formation-ministry.php">Read more <div class="abt-btn3"><img src="images/about/bg2.png" /></a></div>
</div>
</div><!--what-1-->


</div>
</div><!--col-lg-3-->





<div class="col-lg-3" data-aos="fade-up"  data-aos-duration="1000">
<div class="ser-1">

<div class="ser-2">
<img src="images/services/2.jpg" />
</div>

<div class="what-1">
<div class="ser-3">
<h4>Education Commission </h4>
<p>Education Ministry shares knowledge, values, and faith, helping students grow into responsible, loving, and God-centered individuals.</p>
</div>

<div class="ser-4">
<a href="education-commission.php">Read more <div class="abt-btn3"><img src="images/about/bg2.png" /></a></div>
</div>
</div><!--what-1-->


</div>
</div><!--col-lg-3-->




<div class="col-lg-3" data-aos="fade-up"  data-aos-duration="1000">
<div class="ser-1">

<div class="ser-2">
<img src="images/services/3.jpg" />
</div>

<div class="what-1">
<div class="ser-3">
<h4>Medical Ministry</h4>
<p>Medical Ministry serves the sick with love, offering care, healing, and hope to all, especially the poor and needy.</p>
</div>

<div class="ser-4">
<a href="medical-ministry.php">Read more <div class="abt-btn3"><img src="images/about/bg2.png" /></a></div>
</div>

</div><!--what-1-->


</div>
</div><!--col-lg-3-->







<div class="col-lg-3" data-aos="fade-up"  data-aos-duration="1000">
<div class="ser-1">

<div class="ser-2">
<img src="images/services/4.jpg" />
</div>

<div class="what-1">
<div class="ser-3">
<h4>Social  Commission </h4>
<p>Social Ministry helps the poor and needy, sharing love, support, and care to bring hope and dignity to all.</p>
</div>

<div class="ser-4">
<a href="social-commission.php">Read more <div class="abt-btn3"><img src="images/about/bg2.png" /></a></div>
</div>

</div><!--what-1-->


</div>
</div><!--col-lg-3-->



<div class="col-lg-3" data-aos="fade-up"  data-aos-duration="1000">
<div class="ser-1">

<div class="ser-2">
<img src="images/services/5.jpg" />
</div>

<div class="what-1">
<div class="ser-3">
<h4>Evangelization Ministry</h4>
<p>Our mission is to spread Jesus’ message through words, actions, and loving service, touching lives with truth and grace.</p>
</div>

<div class="ser-4">
<a href="evangelization-ministry.php">Read more <div class="abt-btn3"><img src="images/about/bg2.png" /></a></div>
</div>
</div><!--what-1-->


</div>
</div><!--col-lg-3-->

</section>

</div><!--row-->
</div>
</div>




<div class="clearfix"></div>


<div class="blog-out">
<div class="container">
<h1><img src="images/bg.png" / style=" margin-right: 6px;">Latest News</h1>
<div class="row">



 <div class="col-lg-4">
 
<div class="ns-1">

<div class="container1">
  <img src="images/blog/1.jpg" alt="Avatar" class="image">
  <div class="overlay">Discernment on Expectations, Profiles, and Seeking Convergence</div>
</div>

</div>



<div class="ns-1">

<div class="container1">
  <img src="images/blog/2.jpg" alt="Avatar" class="image">
  <div class="overlay">Discernment on Expectations, Profiles, and Seeking Convergence</div>
</div>

</div>

</div><!--col-lg-4-->






 <div class="col-lg-4">
 <div class="ns-2">

<div class="container1">
  <img src="images/blog/3.jpg" alt="Avatar" class="image">
  <div class="overlay">Discernment on Expectations, Profiles, and Seeking Convergence</div>
</div>

</div>
 
</div><!--col-lg-4-->







 <div class="col-lg-4">
 

<div class="ns-1">

<div class="container1">
  <img src="images/blog/4.jpg" alt="Avatar" class="image">
  <div class="overlay">Discernment on Expectations, Profiles, and Seeking Convergence</div>
</div>

</div>


<div class="ns-1" style="margin-bottom:0px;">

<div class="container1">
  <img src="images/blog/5.jpg" alt="Avatar" class="image">
  <div class="overlay">Discernment on Expectations, Profiles, and Seeking Convergence</div>
</div>

</div>


</div><!--col-lg-4-->





</div><!--row-->
</div>
</div>






<div class="clearfix"></div>


<div class="map-out">
<div class="container">
<h1><img src="images/bg.png" / style=" margin-right: 6px;">IJPFIHM in the world</h1>
<div class="row">

<div class="col-lg-4">

<div class="world-2">
<img src="images/map/bg2.png" />
</div><!--world-2-->


<div class="world-1">
<p><b>IJPFIHM are spread throughout the world.</b></p>
<p>The Congregation can be found in 133 countries.</p>
<p style="margin-bottom:0px;">The Congregation comprises 90 Provinces and Vice-Provinces.</p>

<div class="world-btn"><a href="#">Search in the world</a></div>
</div><!--world-1-->

</div><!--col-lg-4-->



<div class="col-lg-8">



<div class="d-flex align-items-start">


  <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
  
  
  
    <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">
  <img src="images/map/bg.png" />  Provinces
  
  <div class="drag-out">
  <img src="images/map/01.png" />
  <p>Click and drag to navigate on the map</p>
  </div>
  
  </button>
  
  
    
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">
   <img src="images/map/bg1.png" /> Communities
   
     <div class="drag-out">
  <img src="images/map/02.png" />
  <p>Click the pen icon to see details</p>
  </div>
    </button>
    
    
    
    
    
  
 </div>
  
  
  
  <div class="tab-content" id="v-pills-tabContent">
  
    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab" tabindex="0">
    <h4>Provinces</h4>
    <img src="images/map/1.gif" style="width:100%;" />
    <div class="page-btn"><a href="#">IJPFIHM World</a></div>
    </div>
    
    <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab" tabindex="0">
     <h4>Communities</h4>
    <img src="images/map/2.gif"  style="width:100%;" />
      <div class="page-btn"><a href="#">IJPFIHM World</a></div>
    </div>
    
   </div>
  
  
  
</div>




</div><!--col-lg-8-->



</div><!--row-->
</div>
</div>







<div class="clearfix"></div>

<div class="event-out">
<div class="container">
<h1><img src="images/bg.png"  style=" margin-right: 6px;" />Upcoming Events</h1>
<div class="row">

<style>
.eve-1
{
  margin-top: 20px;
}
.upca
{
    color:#fff !important;
}
</style>
 <!--<section class="events slider">-->
 
<div class="col-lg-3 col-md-6 col-sm-6" data-aos="fade-up"  data-aos-duration="1000">
     <a href="images/events/01.jpg" data-lightbox="models" class="image upca">
<div class="eve-1">

    <img src="images/events/e1.jpg" />

</div>
<div class="media">

<div class="event-date">
Oct 21
<span class="event-time">11.00 am</span>
</div>


<div class="media-body">
<div class="event-title">
<h5>Goldern Jubilee Celebration, Krishnagiri</h5>
</div>
</div>



</div>
    </a>
</div><!--col-lg-4-->





<div class="col-lg-3 col-md-6 col-sm-6" data-aos="fade-up"  data-aos-duration="1000">
 <a href="images/events/02.jpeg" data-lightbox="models" class="image upca">
<div class="eve-1">

    <img src="images/events/e2.jpg" />
    
</div>
<div class="media">

<div class="event-date">
Oct 22
<span class="event-time">11.00 am</span>
</div>


<div class="media-body">
<div class="event-title">
<h5>Sesquicentennial Jubilee Celebration, Salem</h5>
</div>
</div>



</div>
</a>
</div><!--col-lg-4-->







<div class="col-lg-3 col-md-6 col-sm-6" data-aos="fade-up"  data-aos-duration="1000">
<div class="eve-1">
    <img src="images/events/2.jpg" />
</div>
<div class="media">

<div class="event-date">
Dec 12
<span class="event-time">7.00 am</span>
</div>


<div class="media-body">
<div class="event-title">
<h5><a href="#">Event: Reflect The Community And Serving</a></h5>
</div>
</div>



</div>
</div><!--col-lg-4-->




<div class="col-lg-3 col-md-6 col-sm-6" data-aos="fade-up"  data-aos-duration="1000">
<div class="eve-1">
    <img src="images/events/3.jpg" />
</div>
<div class="media">

<div class="event-date">
Dec 12
<span class="event-time">7.00 am</span>
</div>


<div class="media-body">
<div class="event-title">
<h5><a href="#">Event: Reflect The Community And Serving</a></h5>
</div>
</div>



</div>
</div><!--col-lg-4-->





<!--<div class="col-lg-4" data-aos="fade-up"  data-aos-duration="1000">
<div class="eve-1">
    <img src="images/events/1.jpg" />
</div>
<div class="media">

<div class="event-date">
Feb 12
<span class="event-time">7.00 am</span>
</div>


<div class="media-body">
<div class="event-title">
<h5><a href="#">Event: Reflect The Community And Serving</a></h5>
</div>
</div>



</div>
</div>
-->



<!--</section>-->

</div><!--row-->
</div>
</div>





<div class="clearfix"></div>











  <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox-plus-jquery.js" integrity="sha512-0rYcJjaqTGk43zviBim8AEjb8cjUKxwxCqo28py38JFKKBd35yPfNWmwoBLTYORC9j/COqldDc9/d1B7dhRYmg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>



 <?php include("footer.php") ?>
 


</body>
</html>
