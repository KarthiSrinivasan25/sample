<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

</head>

<body>




<?php
  
  $whoweare = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="found-out">
<div class="container">
<h1>Join IJP</h1>



<?php
  
  if(isset($_GET['tit'])&&($_GET['tit']!=''))
{
    if($_GET['tit']=='join-ijp')
	{
 
?>      

<iframe src = "ViewerJS/#../pdf/Join-IJP.pdf"   class="pdfview_out"  allowfullscreen webkitallowfullscreen></iframe>      


    <?php
}
}

?>   




</div>
</div>





<div class="clearfix"></div>











 <?php include("footer.php") ?>



<style>
.aboutbanner
{
	padding:0px;
}
.pdfview_out
{
	float:left;
	width:100%;
	 height:90vh;
	border:1px solid #ccc;
}
</style>





</body>
</html>
