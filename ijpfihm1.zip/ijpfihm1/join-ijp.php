<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

</head>

<body>




<?php
  
  $whoweare = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="join-in">
<div class="container">
<h1>Join IJP</h1>
<div class="row">



<div class="col-lg-4" data-aos="fade-right"  data-aos-duration="1000">
<div class="ijp-1">
<img src="images/join-ijp/bg1.jpg" />
</div>
</div>




<div class="col-lg-8" data-aos="fade-left"  data-aos-duration="1000">
<div class="ijp-2">


<div class="ijp-3">
<h4>A Call to Serve </h4>
<h2>Join the Congregation of the Franciscan Immaculate Heart of Mary</h2>
<p>Are you a young woman seeking a life filled with purpose, love, and deep union with Christ? The Congregation of the Franciscan Immaculate Heart of Mary invites you to respond to God’s call with courage and joy. Rooted in the spirit of St. Francis of Assisi and inspired by the purity and compassion of the Blessed Virgin Mary, our congregation is committed to a life of prayer, simplicity, and humble service.</p>

<p>We dedicate ourselves to God and His people through education, healthcare, social outreach, and pastoral ministry. Whether it’s teaching the young, caring for the sick, comforting the lonely, or bringing the Gospel to remote villages, we strive to be instruments of God’s peace and love. Our sisters live in communities filled with prayer, joy, and sisterhood, offering their lives in service to the Church and the poor.</p>



<div class="join-pp">
<p>If you feel the stirrings of a deeper calling in your heart—an invitation to live for something greater—come and discover the joy of a life totally given to Christ. The harvest is plentiful, and the Lord is calling laborers into His vineyard. Will you say yes?</p>
<p>Come and see where God is leading you.</p>

<div class="join-btn">

<a href="join-ijp-pdf.php?tit=join-ijp">Join IJP</a>

</div>



</div><!--join-pp-->


<div class="chief-out">
<h4>Vocation Promoter</h4>
<p>Rev. Sr. Barnabas Ubagara Mary FIHM</p>
<p>Mobile: <a href="tel:+91 88388 29063">+91 88388 29063</a></p>
<p style="margin-bottom:0px;">Email: <a href="mailto:ijp.formation@gmail.com">ijp.formation@gmail.com</a></p>
</div>




</div>
</div>



</div><!--col-lg-8-->
</div><!--row-->





</div>
</div>





<div class="clearfix"></div>











 <?php include("footer.php") ?>

</body>
</html>
