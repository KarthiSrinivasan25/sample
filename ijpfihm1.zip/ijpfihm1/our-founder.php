<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

</head>

<body>




<?php
  
  $whoweare = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="found-out">
<div class="container">
<h1>Our Founder</h1>

<div class="row">



<div class="col-lg-3" data-aos="fade-right"  data-aos-duration="1000">
<div class="found-1">
<img src="images/about/01.jpg" />
</div>

<div class="found-11">
<h4>Servant of God Louis Savinien Dupuis, MEP</h4>
</div>

</div><!--col-lg-3-->






<div class="col-lg-9" data-aos="fade-left"  data-aos-duration="1000" >
<div class="found-2">
<p>The founder of our Congregation, Servant of God Louis Savinien Dupuis, MEP, was a French missionary of profound faith and dedication. Born on August 18, 1806, in the city of Sanz, France, he was the son of Etheme Louis Dupuis and Vigthnar Remi. "Dupuis" was the family name. He completed his secondary education at Sebastian High School in Sanz. Ordained as a priest on April 25, 1829, he subsequently joined the Congregation of MEP on May 25, 1831. Known for his fervor and zeal, Father Dupuis exemplified heroic faith and boundless charity.

</p>

<p style="margin-bottom:0px;">Throughout his life, he devoted himself to the service of the Church, working tirelessly to restore moral integrity. He sought to perfect the virtue of charity in service to God’s Kingdom, dedicating his efforts to the glory of God, the edification of the Church, and the salvation of souls. On July 4, 1831, he embarked on a missionary journey to India, arriving on April 9, 1832, to begin his ministry.

</p>


</div><!--found-2-->
</div><!--col-lg-9-->

<div class="found-3" data-aos="fade-up"  data-aos-duration="1000">

<p>In 19th-century India, the erroneous belief that women should not receive an education was deeply entrenched. Educated women often felt shame in revealing their literacy. At the Synod of 1844, it was determined that a Congregation of women was essential to liberate them from this societal oppression. Thus, the Congregation began to take shape, expanding with the establishment of numerous convents and schools. The Synod envisioned a community of Indian sisters entrusted with the moral, religious, and secular education of women.

</p>

<p>At this pivotal moment, Servant of God Louis Savinien Dupuis, MEP, driven by his ardent commitment to fulfilling the Divine will, stepped forward to realize this vision. On October 16, 1884, he founded the Franciscan Sisters of the Immaculate Heart of Mary Congregation. Until his passing on June 4, 1874, he worked indefatigably for the growth and flourishing of the Congregation. His successors, following in his footsteps, continued to nurture its development.
</p>


<p>
Through the sacrifices and perseverance of our forebears, the Congregation now extends its mission throughout India and beyond.
</p>


<p style="margin-bottom:0px;">
For more details: <a href="http://fihm.org/" style="color:#f37936 ; text-decoration:none;"> http://fihm.org/</a> 
</p>

</div><!--found-3-->

<div class="found-4" data-aos="fade-up"  data-aos-duration="1000">
<h4>Prayer for the Beatification of Servant of God Louis Savinien Dupuis, MEP</h4>

<p>O Jesus, Our Redeemer, you have chosen Servant of God Louis Savinien Dupuis, to proclaim the Good News to the world, especially to India. We praise you, we bless you and we thank you.</p>


<p>You have called Servant of God Louis Savinien Dupuis who, by his fervent love and ardent zeal for charity, lived as an example for sacrificial life to be a Missionary and Founder of the Congregation of the Franciscan Sisters of the Immaculate Heart of Mary, Pondicherry. We Implore you to glorify him as 'Blessed', for your greater glory.</p>




<p>Immaculate Heart of Mary, Mother of Jesus, grant your Servant of God Louis Savinien Dupuis, the favour we solicit to your Son.  </p>



<p style="margin-bottom:0px;">Amen.

(Our Father, Hail Mary, Glory be...)
</p>

</div><!--found-4-->








</div><!--row-->
</div>
</div>





<div class="clearfix"></div>













 <?php include("footer.php") ?>

</body>
</html>
