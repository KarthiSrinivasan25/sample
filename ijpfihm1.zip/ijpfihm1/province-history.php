<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

</head>

<body>




<?php
  
  $whoweare = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="found-out">
<div class="container">
<h1>Province History</h1>



<div class="his-1" data-aos="fade-up"  data-aos-duration="1000">
<h1>FIHM INFANT JESUS PROVINCE – MADURAI</h1>
<p>The illustrious Congregation of the Franciscan Sisters of the Immaculate Heart of Mary (FIHM) was divinely established on the 16th of October, 1844, in the sacred soil of Pondicherry, India, by the venerable Rev. Fr. Louis Savinien Dupuis, M.E.P.</p>



<div class="his-2">
<h4>OUR SACRED CHARISM AND INSPIRING MOTTO</h4>
<p>Our exalted charism is the sanctification of the sisters, undertaken for the sublime purpose of sanctifying women. Emboldened by the Rule of Life and inspired by the seraphic spirituality of St. Francis of Assisi, our guiding motto is: “Love and Sacrifice.”</p>
</div><!--his-2-->




<div class="his-2">
<h4>VISION STATEMENT</h4>
<p>To radiate the compassionate love of Christ through a life of simplicity, service, and joy, nurturing a just and peaceful society rooted in the Gospel and Franciscan values.</p>
</div><!--his-2-->



<div class="his-2">
<h4>MISSION STATEMENT</h4>
<p>Empowered by the Spirit and inspired by the example of St. Francis of Assisi and our Foundress, we, the Franciscan Sisters of the Immaculate Heart of Mary, Madurai Province, commit ourselves to:</p>

</div><!--his-2-->

<div class="his-3">

<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Witness to Christ through a life of prayer, humility, and joyful fraternity.</p>
</div>

</div><!--his-3-->


<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Serve the poor, the marginalized, and the voiceless through education, healthcare, and social upliftment.</p>
</div>

</div><!--his-3-->




<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Promote ecological awareness and sustainable living as stewards of God’s creation.</p>
</div>

</div><!--his-3-->




<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Foster human dignity and integral development in all our ministries.</p>
</div>

</div><!--his-3-->


<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Walk in solidarity with the suffering, bringing hope and healing wherever we are sent.</p>
</div>

</div><!--his-3-->





<div class="his-2">
<h4>A GLOBAL FOOTPRINT</h4>
<p>With divine providence and missionary zeal, the FIHM congregation has extended its spiritual and humanitarian mission across five continents—Asia, Africa, Europe, America, and Oceania—embracing eight nations beyond India: Kenya, Tanzania, Uganda, France, Germany, Italy, the United States of America, and Papua New Guinea.</p>

</div><!--his-2-->



<div class="his-2">
<h4>OUR APOSTOLIC MINISTRIES</h4>
<p>Our devoted sisters immerse themselves in a diverse array of ministries, including:</p>

</div><!--his-2-->

<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Evangelization</p>
</div>

</div><!--his-3-->



<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Religious Formation</p>
</div>

</div><!--his-3-->


<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Holistic Education</p>
</div>

</div><!--his-3-->




<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Compassionate Healthcare</p>
</div>

</div><!--his-3-->




<div class="his-3">
<div class="his-4">
<img src="images/list-check.png" />
</div>

<div class="his-5">
<p>	Transformative Social Work</p>
</div>

</div><!--his-3-->


<div class="his-2">

<p>Through these noble endeavors, we proclaim the Gospel, elevate and empower women, uplift the downtrodden, and bring light to the most marginalized corners of society.</p>
</div><!--his-2-->




<div class="his-2">
<h4>FORMATION OF THE PROVINCES – A HISTORIC TURNING POINT (1990)</h4>

<p>Between 1978 and 1990, the congregation operated under the structure of three regions. A pivotal chapter in our history unfolded on the 22nd of May, 1990, when the Special General Chapter was convened at Pakkamudayanpet. In a spirit of unity and divine discernment, it was unanimously resolved to elevate the regional divisions into full-fledged provinces. Thus emerged:</p>
</div><!--his-2-->












<table>
 
  <tr>
    <td class="bot-1">Lourdes Province </td> 
    <td class="bot-2"> Pondicherry & Cuddalore</td>
 </tr>
  
  
  <tr>
    <td class="bot-1">St. Joseph’s Province</td>
     <td class="bot-2">  Tiruchirappalli</td>
  </tr>
  
  
   <tr>
    <td class="bot-1">Infant Jesus Province </td>
     <td class="bot-2"> Madurai</td>
  </tr>
  

</table>


<div class="his-2">
<p>In the nascent stages, existing regional houses served as provisional provincial headquarters, until purpose-built edifices were realized.</p>
</div><!--his-2-->



<div class="his-2">
<h4>IMMACULATE PROVINCIALATE – Y. OTHAKKADAI</h4>
<p>Through tireless effort and unwavering faith, the Provincial House in Madurai was constructed and consecrated on the 23rd of January, 1993, in a ceremony of grand solemnity. The inaugural administrative council of the Infant Jesus Province was composed of:</p>
</div><!--his-2-->



<table>
 
  <tr>
    <td class="bot-1">Sr. Isabella Fatima </td>
    <td class="bot-2">Provincial Superior</td>
 </tr>
  
  
  <tr>
     <td class="bot-1">Sr. Margaret Mary </td>
   <td class="bot-2">Vice Provincial</td>
  </tr>
  
  
   <tr>
   <td class="bot-1">Sr. Hadrianus Mary </td>
  <td class="bot-2"> Province Procurator</td>
  </tr>
  
   

  
   
   <tr>
     <td class="bot-1">Sr. Y. Alphonse Mary </td>
      <td class="bot-2">Province Secretary </td>
  </tr>
  
  
  
     <tr>
    <td class="bot-1">Sr. Frank Mary </td>
    <td class="bot-2"> Councillor</td>
  </tr>
  
  
  

</table>




<div class="his-2">
<h4>PROVINCIAL SUPERIORS – LEADERS OF GRACE AND VISION</h4>
<p>Since its inception, the Infant Jesus Province has flourished under the luminous guidance of the following esteemed Provincial Superiors:</p>
</div><!--his-2-->






<table>
 
  <tr>
    <td class="bot-1">Sr. Isabella Fatima Mary  </td>
    <td class="bot-2">(1990–1993)</td>
 </tr>
  
  
  <tr>
    <td class="bot-1">Sr. Prema Maria Goretti  </td>
    <td class="bot-2"> (1993–1996)</td>
  </tr>
  
  
   <tr>
    <td class="bot-1">Sr. Isabella Fatima Mary </td>
    <td class="bot-2"> (1996–1999)</td>
  </tr>
  
   
  <tr>
    <td class="bot-1">Sr. L. Jeya Mary </td>
    <td class="bot-2">(1999–2003)  </td>
  </tr>
  
  
  
     <tr>
    <td class="bot-1">Sr. Franceline Mary Julia Violet </td>
    <td class="bot-2"> (2003–2005) </td>
  </tr>
  
  
    <tr>
    <td class="bot-1">	Sr. Anselm Mary Kulandai Therese </td>
    <td class="bot-2"> (2005–2008)  </td>
  </tr>
  
  
    
    <tr>
    <td class="bot-1">Sr. Eleanor Mary Urmila Selvi </td>
    <td class="bot-2"> (2008–2012)  </td>
  </tr>
  
      <tr>
    <td class="bot-1">	Sr. Isabella Fatima Mary  </td>
    <td class="bot-2"> (2012–2014) </td>
  </tr>
  
   <tr>
    <td class="bot-1">Sr. Firmina Mary </td>
    <td class="bot-2"> (2014–2022)  </td>
  </tr>
  
   <tr>
    <td class="bot-1">	Sr. Sabin Mary  </td>
    <td class="bot-2"> (2022–Present) </td>
  </tr>
  
  
  

</table>

<div class="his-2">
<p style="margin-bottom:0px;">Under their enlightened leadership and the support of devoted councillors, the Infant Jesus Province has witnessed exponential growth, countless blessings, and a deepened commitment to serve humanity with unwavering love, sacrificial spirit, and boundless compassion.</p>

</div><!--his-2-->





</div><!--his-1-->




















</div>
</div>





<div class="clearfix"></div>













 <?php include("footer.php") ?>

</body>
</html>
