<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

</head>

<body>




<?php
  
  $administration = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="pv-out" data-aos="fade-up"  data-aos-duration="1000">
<div class="container">
<h1>Provincial Team</h1>



<div class="pv-1">

<table>
  <tr>
  <th colspan="5" class="cen-out">INFANT JESUS PROVINCE - MADURAI<br />
  House Ware List 2025-2026<br /> 
  PROVINCIAL AND HER COUNCILLORS</th>
  </tr>

  <tr>
    <th class="moso-1">S.No</th>
    <th class="moso-2">Name of the sisters</th>
    <th class="moso-3">Designation</th>
    <th class="moso-4">Phone Number</th>
    <th class="moso-5">E Mail ID</th>
  </tr>
  
  
  <tr>
    <td>1</td>
    <td>Rev. Sr. Sabin Mary</td>
    <td>Provincial Superior</td>
    <td><a href="tel:9787680362"  style="color: #212529 !important;
    text-decoration: none !important;">9787680362</a></td>
    <td><a href="mailto:immaculateinfant@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;">immaculateinfant@gmail.com</a><br />
    <a href="mailto:ijp.provincial@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;">ijp.provincial@gmail.com</a></td>
  </tr>
  
  
    <tr>
    <td>2</td>
    <td>Rev. Sr. Bella Jesintha </td>
    <td>Vice Provincial<br /> Educational & School</td>
    <td><a href="tel:9443042943" style="color: #212529 !important;
    text-decoration: none !important;">9443042943</a></td>
    <td><a href="mailto:infanteducation2023@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;">infanteducation2023@gmail.com</a><br>
   <a href="mailto:ijp.viceprovincial@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;"> ijp.viceprovincial@gmail.com</a><br />
   <a href="mailto:ijpsocietal@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;"> ijpsocietal@gmail.com</a></td>
  </tr>
  
  
   <tr>
    <td>3</td>
    <td>Rev. Sr. Jeanne De Chantal Arockia Mary</td>
    <td>Procurator</td>
    <td><a href="tel:9080825296" style="color: #212529 !important;
    text-decoration: none !important;">9080825296</a></td>
    <td><a href="mailto:infantfinance14@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;">infantfinance14@gmail.com</a><br />
    <a href="mailto:ijp.procurator@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;">ijp.procurator@gmail.com</a></td>
  </tr>
  
  
    <tr>
    <td>4</td>
    <td>Rev. Sr. Jaya Rani Sebastin</td>
    <td>Secretary</td>
    <td><a href="tel:9080230256" style="color: #212529 !important;
    text-decoration: none !important;">9080230256</a></td>
    <td><a href="mailto:ijp.secretary@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;">ijp.secretary@gmail.com</a></td>
  </tr>
  
  
     <tr>
    <td>5</td>
    <td>Rev. Sr. Barnabas Ubagara Mary</td>
    <td>Councillor - Evangelization & Formation</td>
    <td><a href="tel:8838829063" style="color: #212529 !important;
    text-decoration: none !important;">8838829063</a></td>
    <td><a href="mailto:ijp.evangelize@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;">ijp.evangelize@gmail.com</a><br />
   <a href="mailto:ijp.formation@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;"> ijp.formation@gmail.com</a>  </td>
  </tr>
  
  
  
     <tr>
    <td>6</td>
    <td>Rev. Sr. J. Mary Elizabeth</td>
    <td>Councillor - Medical</td>
    <td><a href="tel:6374766205" style="color: #212529 !important;
    text-decoration: none !important;">6374766205</a></td>
    <td><a href="mailto:ijp.medicals@gmail.com" style="color: #212529 !important;
    text-decoration: none !important;">ijp.medicals@gmail.com</a> </td>
  </tr>
  
  
  
 
</table>




</div><!--pt-1-->



<div class="dop-out">
<iframe src = "ViewerJS/#../pdf/provincial-team.pdf"   class="pdfview_out"  allowfullscreen webkitallowfullscreen></iframe>     
</div>






</div>
</div>





<div class="clearfix"></div>











 <?php include("footer.php") ?>
 
 
 
 
 
 <style>


.pdfview_out
{
	float:left;
	width:100%;
	 height:90vh;
	border:1px solid #ccc;
}


</style>

 

</body>
</html>
