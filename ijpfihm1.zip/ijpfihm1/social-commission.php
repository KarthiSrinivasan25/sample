<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<?php include("website-links.php"); ?>

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.css" integrity="sha512-Woz+DqWYJ51bpVk5Fv0yES/edIMXjj3Ynda+KWTIkGoynAMHrqTcDUQltbipuiaD5ymEo9520lyoVOo9jCQOCA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
 
</head>

<body>




<?php
  
  $whatwedo = true;
  include("header.php");
  ?>





 <!---circle-loader-->
<div class="header_outer" style="overflow:hidden;">


 <div class="ba-out">
   </div>




</div>




<div class="mini-out">
<div class="container">
<h1>Social Commission  </h1>
<div class="row">






<div class="col-lg-6">

<div class="mini-2">
<a href="images/ministry/social-ministry.jpg" data-lightbox="models" class="image">
<img src="images/ministry/social-ministry.jpg" />
</a>
</div>



</div><!--col-lg-6-->






<div class="col-lg-6">








 <table>
 
 <tr>
 <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr.  Amalorpava Mary John Peter</p>
</div>
</div>
</td>


<td>

<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Sahaya Vincy  Mariathasan</p>
</div>
</div>
</td>
</tr>
  
  
  
  <tr>
 <td>
   <div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Bella Jacintha Mary</p>
</div>
</div>
</td>


 <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Amalorpava Mary Raju</p>
</div>
</div>
</td>
</tr>
  
  
<tr>
 <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Sabin Mary</p>
</div>
</div>
</td>


 <td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Thilaga Mary</p>
</div>
</div>
</td>
</tr>
  
  
  
 <tr>
<td>
<div class="mini-3">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Ubanesh Kamban</p>
</div>
</div>
</td>


 <td>
<div class="mini-3" style="margin-bottom:0px;">
<div class="mini-4">
<img src="images/ministry/bg4.png" />
</div>
<div class="mini-5">
<p>Sr. Sahaya Thainese Sangeetha</p>
</div>
</div>
</td>
 </tr>
  
  

  
  
</table>



</div><!--col-lg-6-->


</div><!--row-->

<div class="gal-out">
<div class="row">


<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1">
<div class="gaa-2">
 <a href="images/Convent/6.jpg" data-lightbox="models" class="image">
<img src="images/Convent/6.jpg" />

<h4>St.Rita's Working Women's Hostel<br /> Ramanputhur Nagercoil</h4> 
</a>
</div>
</div>
</div>



<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1">
<div class="gaa-2">
<a href="images/Convent/14.jpg" data-lightbox="models" class="image">
<img src="images/Convent/14.jpg" />

<h4>St. Thomas Working Women's Hostel<br /> Krishnagiri</h4>
</a>
</div>
</div>
</div>


<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1">
<div class="gaa-2">
<a href="images/Convent/15.jpg" data-lightbox="models" class="image">
<img src="images/Convent/15.jpg" />

<h4>St. Thomas Working Women's Hostel<br /> Krishnagiri</h4>
</a>
</div>
</div>
</div>

<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1">
<div class="gaa-2">
<a href="images/Convent/16.jpg" data-lightbox="models" class="image">
<img src="images/Convent/16.jpg" />

<h4>St. Thomas Working Women's Hostel<br /> Krishnagiri</h4>
</a>
</div>
</div>
</div>


<div class="col-lg-4 col-md-6 col-sm-12">
<div class="gaa-1" style="margin-bottom:0px;">
<div class="gaa-2">
<a href="images/Convent/17.jpg" data-lightbox="models" class="image">
<img src="images/Convent/17.jpg" />

<h4>St. Thomas Working Women's Hostel<br /> Krishnagiri</h4>
</a>
</div>
</div>
</div>








</div><!--row-->
</div>










</div>
</div>





<div class="clearfix"></div>











 <?php include("footer.php") ?>
 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox-plus-jquery.js" integrity="sha512-0rYcJjaqTGk43zviBim8AEjb8cjUKxwxCqo28py38JFKKBd35yPfNWmwoBLTYORC9j/COqldDc9/d1B7dhRYmg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
 

</body>
</html>
