
<title>ijpfihm</title>



<!---Bootstrap Links-->
        
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
         <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
 
         
           <!---font-awesome-links-->
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
 



       <!---style Links-->
<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet" href="css/responsive.css">





  <!---Animation-Links--> 
      
     <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">   
     <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  


 <button onclick="topFunction()" id="myBtn" title="Go to top"><img src="images/up-arrow.png"></button>
<!---Scorll Top Query-->

<script>
// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "flex";
  } else {
    mybutton.style.display = "none";
  }


  if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
var element = document.getElementById("myheader");
element.classList.add("sticky-top");
        } else {
var element = document.getElementById("myheader");
element.classList.remove("sticky-top");
        }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}


</script>
<!---Scorll Top Query-->