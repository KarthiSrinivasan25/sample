<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KidsZone - About Us | Magical Toy Store</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- AOS Animation Library -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <link href="assets/css/styles.css" rel="stylesheet">
  <style>
    
    @keyframes floatEmoji {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-20px) rotate(5deg); }
    }
    .floating-emoji {
      position: absolute;
      animation: floatEmoji 4s ease-in-out infinite;
      font-size: 2.5rem;
      opacity: 0.3;
    }
    .floating-emoji:nth-child(1) { top: 15%; left: 5%; animation-delay: 0s; }
    .floating-emoji:nth-child(2) { top: 60%; right: 8%; animation-delay: 1s; font-size: 3rem; }
    .floating-emoji:nth-child(3) { bottom: 10%; left: 15%; animation-delay: 2s; }
    .floating-emoji:nth-child(4) { top: 30%; right: 20%; animation-delay: 0.5s; }
    

  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><i class="bi bi-balloon-heart-fill"></i> KidsZone</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">
          <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-house-door"></i> Home</a></li>
          <li class="nav-item"><a class="nav-link active" href="about.php"><i class="bi bi-heart"></i> About</a></li>
          <li class="nav-item"><a class="nav-link" href="products.php"><i class="bi bi-grid-3x3-gap-fill"></i> Shop</a></li>
          <li class="nav-item"><a class="nav-link position-relative" href="cart.php"><i class="bi bi-cart3"></i> Cart <span id="cartCountNav" class="cart-badge">0</span></a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php"><i class="bi bi-telephone"></i> Contact Us</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i>

              <?php if (isset($_SESSION['user_name'])): ?>
                <?= $_SESSION['user_name']; ?>
              <?php else: ?>
                Account
              <?php endif; ?>

            </a>

            <ul class="dropdown-menu dropdown-menu-end">

              <?php if (!isset($_SESSION['user_name'])): ?>

                <li>
                  <a class="dropdown-item" href="login.php">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                  </a>
                </li>

                <li>
                  <a class="dropdown-item" href="signup.php">
                    <i class="bi bi-person-plus"></i> Signup
                  </a>
                </li>

              <?php else: ?>

                <li>
                  <span class="dropdown-item-text">
                    👋 Hello,
                    <?= $_SESSION['user_name']; ?>
                  </span>
                </li>

                <li>
                  <hr class="dropdown-divider">
                </li>

                <li>
                  <a class="dropdown-item text-danger" href="logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                  </a>
                </li>

              <?php endif; ?>

            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <main>
    <!-- ENHANCED HERO SECTION -->
    <div class="about-hero">
      <div class="floating-emoji">🧸</div>
      <div class="floating-emoji">🦄</div>
      <div class="floating-emoji">🎨</div>
      <div class="floating-emoji">🚂</div>
      
      <div class="container text-center" data-aos="fade-up">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <span class="badge bg-white text-dark px-4 py-2 rounded-pill mb-3 shadow-sm">
              <i class="bi bi-balloon-heart-fill text-warning"></i> Since 2020
            </span>
            <h1 class="hero-title display-3 fw-bold mb-3">
              Where Imagination <br>Comes to Play! 🎈
            </h1>
            <p class="lead text-dark-emphasis mb-4">
              We're on a mission to fill the world with safe, joyful, and magical toys 
              that spark creativity in every child.
            </p>
            <div class="d-flex justify-content-center gap-3">
              <a href="#story" class="btn btn-kid btn-lg px-4">
                <i class="bi bi-play-circle"></i> Our Story
              </a>
              <a href="products.php" class="btn btn-outline-kid btn-lg px-4">
                <i class="bi bi-bag-check"></i> Shop Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Mission & Vision Section -->
    <div class="container my-5" id="mission" data-aos="fade-up">
      <div class="row g-4">
        <div class="col-md-6">
          <div class="bg-white rounded-4 p-4 h-100 shadow-sm">
            <i class="bi bi-flag fs-1 text-warning"></i>
            <h3 class="fw-bold mt-2">Our Mission</h3>
            <p>To spark joy and imagination in every child through safe, innovative, and educational toys that inspire creativity, learning, and unforgettable playtime experiences.</p>
          </div>
        </div>
        <div class="col-md-6">
          <div class="bg-white rounded-4 p-4 h-100 shadow-sm">
            <i class="bi bi-eye fs-1 text-warning"></i>
            <h3 class="fw-bold mt-2">Our Vision</h3>
            <p>A world where every child has access to toys that nurture their potential, celebrate diversity, and create magical moments of discovery and delight.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Stats Counter Section -->
    <div class="container my-5" data-aos="fade-up">
      <div class="row g-4">
        <div class="col-md-3 col-6">
          <div class="stat-card">
            <i class="bi bi-emoji-smile fs-1 text-warning"></i>
            <div class="stat-number">10k+</div>
            <p class="mb-0">Happy Kids</p>
          </div>
        </div>
        <div class="col-md-3 col-6">
          <div class="stat-card">
            <i class="bi bi-trophy fs-1 text-warning"></i>
            <div class="stat-number">25+</div>
            <p class="mb-0">Awards Won</p>
          </div>
        </div>
        <div class="col-md-3 col-6">
          <div class="stat-card">
            <i class="bi bi-globe fs-1 text-warning"></i>
            <div class="stat-number">15+</div>
            <p class="mb-0">Countries</p>
          </div>
        </div>
        <div class="col-md-3 col-6">
          <div class="stat-card">
            <i class="bi bi-heart fs-1 text-warning"></i>
            <div class="stat-number">50k+</div>
            <p class="mb-0">Toys Sold</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Our Story Timeline -->
    <div class="container my-5" id="story" data-aos="fade-up">
      <h2 class="text-center fw-bold mb-5">📖 Our Magical Journey</h2>
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="bg-white rounded-4 p-4 shadow-sm">
            <div class="timeline-item">
              <h5 class="fw-bold">🌈 2020 - The Beginning</h5>
              <p>KidsZone was founded by two passionate parents who wanted to create safe, high-quality toys that spark imagination.</p>
            </div>
            <div class="timeline-item">
              <h5 class="fw-bold">🚀 2021 - First Milestone</h5>
              <p>We sold our 10,000th toy and expanded our product line to include eco-friendly wooden toys and art supplies.</p>
            </div>
            <div class="timeline-item">
              <h5 class="fw-bold">🏆 2022 - Award Winner</h5>
              <p>KidsZone received the "Best Educational Toy Store" award and launched our charity program for children's hospitals.</p>
            </div>
            <div class="timeline-item">
              <h5 class="fw-bold">🌍 2023 - Global Reach</h5>
              <p>We started shipping internationally, bringing joy to kids in over 15 countries worldwide.</p>
            </div>
            <div class="timeline-item">
              <h5 class="fw-bold">✨ 2024 - Today</h5>
              <p>Continuing our mission with 500+ happy 5-star reviews and growing our magical toy family every day!</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Core Values -->
    <div class="container my-5" data-aos="fade-up">
      <h2 class="text-center fw-bold mb-5">🌟 Our Core Values</h2>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="text-center p-4">
            <i class="bi bi-shield-check fs-1 text-success"></i>
            <h5 class="fw-bold mt-3">Safety First</h5>
            <p>All products are rigorously tested and certified non-toxic, safe for children of all ages.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="text-center p-4">
            <i class="bi bi-tree fs-1 text-success"></i>
            <h5 class="fw-bold mt-3">Eco-Friendly</h5>
            <p>We use sustainable materials and eco-friendly packaging to protect our planet.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="text-center p-4">
            <i class="bi bi-people fs-1 text-success"></i>
            <h5 class="fw-bold mt-3">Inclusive Play</h5>
            <p>Toys that celebrate diversity and represent all children, fostering belonging and empathy.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Meet the Team -->
    <div class="container my-5" data-aos="fade-up">
  <h2 class="text-center fw-bold mb-5">👨‍👩‍👧 Meet Our Magical Team</h2>

  <div class="row g-4">

    <!-- Team Member 1 -->
    <div class="col-md-3 col-6">
      <div class="team-card text-center p-3 shadow-sm rounded">
        <img src="assets/img/icons/icon1.webp"
          class="team-img rounded-circle mb-3"
          alt="Team member">

        <h6 class="fw-bold mb-0">Priya Sharma</h6>
        <small class="text-muted">Founder & CEO</small>

        <p class="mt-2 small">
          Passionate about joyful learning and safe toys for kids.
        </p>
      </div>
    </div>

    <!-- Team Member 2 -->
    <div class="col-md-3 col-6">
      <div class="team-card text-center p-3 shadow-sm rounded">
        <img src="assets/img/icons/icon2.png"
          class="team-img rounded-circle mb-3"
          alt="Team member">

        <h6 class="fw-bold mb-0">Arjun Kumar</h6>
        <small class="text-muted">Product Designer</small>

        <p class="mt-2 small">
          Designing fun and creative toy experiences for children.
        </p>
      </div>
    </div>

    <!-- Team Member 3 -->
    <div class="col-md-3 col-6">
      <div class="team-card text-center p-3 shadow-sm rounded">
        <img src="assets/img/icons/icon3.png"
          class="team-img rounded-circle mb-3"
          alt="Team member">

        <h6 class="fw-bold mb-0">Sneha Reddy</h6>
        <small class="text-muted">Customer Support</small>

        <p class="mt-2 small">
          Helping parents find the perfect toys with a smile 😊
        </p>
      </div>
    </div>

    <!-- Team Member 4 -->
    <div class="col-md-3 col-6">
      <div class="team-card text-center p-3 shadow-sm rounded">
        <img src="assets/img/icons/icon4.webp"
          class="team-img rounded-circle mb-3"
          alt="Team member">

        <h6 class="fw-bold mb-0">Vikram Patel</h6>
        <small class="text-muted">Quality Control</small>

        <p class="mt-2 small">
          Ensuring every toy is safe, durable, and full of fun.
        </p>
      </div>
    </div>

  </div>
</div>

    <!-- Charity & Community -->
    <div class="container my-5" data-aos="fade-up">
      <div class="row bg-white rounded-5 shadow-sm overflow-hidden align-items-center">
        <div class="col-md-7 p-4 p-md-5">
          <i class="bi bi-heart-fill fs-1 text-danger"></i>
          <h2 class="fw-bold mt-2">🎁 Giving Back</h2>
          <p class="lead">We believe every child deserves the joy of play.</p>
          <p>Each year, we donate 1% of our profits to children's hospitals and underprivileged communities. Since 2020, we've provided over 5,000 toys to kids in need and sponsored play therapy programs in 10 hospitals.</p>
          <div class="mt-3">
            <span class="badge bg-warning text-dark p-2 me-2">🏥 10+ Hospitals</span>
            <span class="badge bg-warning text-dark p-2">🎁 5,000+ Toys Donated</span>
          </div>
        </div>
        <div class="col-md-5 p-0">
          <img src="assets/img/giving_back.jpg" class="w-100" style="height: 375px; object-fit: cover; min-height: 280px;">
        </div>
      </div>
    </div>

    <!-- CUSTOMER TESTIMONIALS -->
    <div class="container my-5" data-aos="fade-up">
      <h2 class="text-center mb-4 fw-bold">💬 Happy Little Customers</h2>
      <div class="row">

        <div class="col-md-4">
          <div class="testimonial-card">
            <img src="assets/img/icons/user.png" class="testimonial-img" alt="customer">
            <h6>Priya, mom of Aarav</h6>
            <div class="rating mb-2">
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
            </div>
            <p>"My son absolutely loves the elephant plush toy! The quality is amazing and delivery was super fast."</p>
          </div>
        </div>

        <div class="col-md-4">
          <div class="testimonial-card">
            <img src="assets/img/icons/user.png" class="testimonial-img" alt="customer">
            <h6>Rahul, dad of Anaya</h6>
            <div class="rating mb-2">
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-half"></i>
            </div>
            <p>"The wooden building blocks are fantastic. My daughter enjoys playing and learning with them every day!"
            </p>
          </div>
        </div>

        <div class="col-md-4">
          <div class="testimonial-card">
            <img src="assets/img/icons/user.png" class="testimonial-img" alt="customer">
            <h6>Meera, grandmother</h6>
            <div class="rating mb-2">
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
            </div>
            <p>"The art and craft kit was a huge hit with my grandchildren. So many creative activities in one box!"</p>
          </div>
        </div>

      </div>
    </div>


    <!-- Call to Action -->
    <div class="container my-5" data-aos="zoom-in">
      <div class="bg-warning bg-gradient rounded-5 p-5 text-center" style="background: linear-gradient(135deg, #ffdd99, #ffcc80) !important;">
        <h2 class="fw-bold">Ready to Start the Adventure?</h2>
        <p class="lead">Join thousands of happy families who trust KidsZone for magical playtime.</p>
        <a href="products.php" class="btn btn-kid btn-lg px-5 mt-2"><i class="bi bi-bag-check"></i> Shop Now</a>
      </div>
    </div>
  </main>

  <footer class="text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5><i class="bi bi-balloon-heart-fill"></i> KidsZone</h5>
          <p>Where imagination grows! Safe, fun, educational toys for ages 0-10.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <p><a href="about.php" class="text-decoration-none text-dark">About Us</a> | <a href="products.php" class="text-decoration-none text-dark">Shop</a> | <a href="cart.php" class="text-decoration-none text-dark">Cart</a></p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Follow the Fun</h5>
          <i class="bi bi-instagram fs-3 mx-2"></i>
          <i class="bi bi-facebook fs-3 mx-2"></i>
          <i class="bi bi-youtube fs-3 mx-2"></i>
          <i class="bi bi-tiktok fs-3 mx-2"></i>
        </div>
      </div>
      <hr class="bg-dark">
      <p class="mb-0">🌟 KidsZone — Where imagination grows! 🌟 <br>© 2025 Magical Toy Store — Safe, Fun, Creative</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 800, once: true });
    
    let cart = JSON.parse(localStorage.getItem('kidsCart')) || [];
    function updateCartBadge() { 
      let total = cart.reduce((s, i) => s + i.qty, 0); 
      let badge = document.getElementById('cartCountNav'); 
      if(badge) badge.innerText = total; 
    }
    updateCartBadge();
  </script>
</body>
</html>