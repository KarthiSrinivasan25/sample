<?php
include 'config/db.php';


// INSERT CATEGORY
if (isset($_POST['submit'])) {

	$name = $_POST['name'];

	$icon = time() . '_' . $_FILES['icon']['name'];
	$tmp = $_FILES['icon']['tmp_name'];

	$allowed = ['jpg', 'jpeg', 'png', 'webp'];

	$ext = strtolower(pathinfo($icon, PATHINFO_EXTENSION));

	if (!in_array($ext, $allowed)) {
		die("Invalid File Type");
	}

	move_uploaded_file($tmp, "assets/img/category/" . $icon);

	$stmt = $conn->prepare("INSERT INTO categories(name, icon) VALUES(?, ?)");
	$stmt->bind_param("ss", $name, $icon);
	$stmt->execute();

	header("Location: category.php");
	exit();
}

// UPDATE CATEGORY
if (isset($_POST['update'])) {

	$id = $_POST['id'];
	$name = $_POST['name'];

	// OLD IMAGE
	$old = $_POST['old_icon'];

	// NEW IMAGE CHECK
	if ($_FILES['icon']['name'] != '') {

		$icon = time() . '_' . $_FILES['icon']['name'];
		$tmp = $_FILES['icon']['tmp_name'];

		move_uploaded_file($tmp, "assets/img/category/" . $icon);

		// DELETE OLD IMAGE
		if (file_exists("assets/img/category/" . $old)) {
			unlink("assets/img/category/" . $old);
		}

	} else {

		$icon = $old;
	}

	$stmt = $conn->prepare("UPDATE categories SET name=?, icon=? WHERE id=?");
	$stmt->bind_param("ssi", $name, $icon, $id);
	$stmt->execute();

	header("Location: category.php");
	exit();
}

// DELETE CATEGORY
if (isset($_GET['delete'])) {

	$id = $_GET['delete'];

	// GET IMAGE
	$get = $conn->prepare("SELECT icon FROM categories WHERE id=?");
	$get->bind_param("i", $id);
	$get->execute();

	$result = $get->get_result();
	$row = $result->fetch_assoc();

	// DELETE IMAGE
	if ($row && file_exists("assets/img/category/" . $row['icon'])) {
		unlink("assets/img/category/" . $row['icon']);
	}

	// DELETE DB
	$stmt = $conn->prepare("DELETE FROM categories WHERE id=?");
	$stmt->bind_param("i", $id);
	$stmt->execute();

	header("Location: category.php");
	exit();
}
?>

<!DOCTYPE html>
<html>

<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Kids Toys Shop Category</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
		name='viewport' />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet"
		href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="assets/css/ready.css">
	<link rel="stylesheet" href="assets/css/demo.css">
</head>

<body>
	<div class="wrapper">
		<div class="main-header">
			<div class="logo-header">
				<a href="index.php" class="logo">
					Kids Toys Shop
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse"
					data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<button class="topbar-toggler more"><i class="la la-ellipsis-v"></i></button>
			</div>
			<nav class="navbar navbar-header navbar-expand-lg">
				<div class="container-fluid">

					<form class="navbar-left navbar-form nav-search mr-md-3" action="">
						<div class="input-group">
							<input type="text" placeholder="Search ..." class="form-control">
							<div class="input-group-append">
								<span class="input-group-text">
									<i class="la la-search search-icon"></i>
								</span>
							</div>
						</div>
					</form>
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">


						<li class="nav-item dropdown">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#"
								aria-expanded="false"> <img src="assets/img/user.png" alt="user-img" width="36"
									class="img-circle"><span>Admin</span></span> </a>
							<ul class="dropdown-menu dropdown-user">
								<li>
									<div class="user-box">
										<div class="u-img"><img src="assets/img/user.png" alt="user"></div>
										<div class="u-text">
											<h4>Admin</h4>
											<p class="text-muted">hello@themekita.com</p><a href="#"
												class="btn btn-rounded btn-danger btn-sm">View Profile</a>
										</div>
									</div>
								</li>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="#"><i class="ti-user"></i> My Profile</a>
								<a class="dropdown-item" href="#"></i> My Balance</a>
								<a class="dropdown-item" href="#"><i class="ti-email"></i> Inbox</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="#"><i class="ti-settings"></i> Account Setting</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="#"><i class="fa fa-power-off"></i> Logout</a>
							</ul>
							<!-- /.dropdown-user -->
						</li>
					</ul>
				</div>
			</nav>
		</div>
		<div class="sidebar">
			<div class="scrollbar-inner sidebar-wrapper">
				<div class="user">
					<div class="photo">
						<img src="assets/img/user.png">
					</div>
					<div class="info">
						<a class="" data-toggle="collapse" href="#collapseExample" aria-expanded="true">
							<span>
								Kids Shop
								<span class="user-level">Administrator</span>

							</span>
						</a>
						<div class="clearfix"></div>


					</div>
				</div>
				<ul class="nav">
					<li class="nav-item">
						<a href="index.php">
							<i class="la la-dashboard"></i>
							<p>Dashboard</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="user.php">
							<i class="la la-user"></i>
							<p>User</p>
						</a>
					</li>
					<li class="nav-item active">
						<a href="category.php">
							<i class="la la-list"></i>
							<p>Category</p>
						</a>
					</li>
					<li class="nav-item">
                        <a href="product.php">
                            <i class="la la-cube"></i>
                            <p>Product</p>
                        </a>
                    </li>
				</ul>
			</div>
		</div>

		<div class="main-panel">
			<div class="content">
				<div class="container-fluid">

					<h4 class="page-title">Category</h4>

					<!-- ADD CATEGORY FORM -->
					<div class="card p-4 mb-4">
						<h5>Add New Category</h5>

						<form method="POST" enctype="multipart/form-data">

							<div class="row align-items-end">

								<!-- Category Name -->
								<div class="col-md-5 mb-3">
									<label>Category Name</label>
									<input type="text" name="name" class="form-control" placeholder="Category Name"
										required>
								</div>

								<!-- Icon Upload -->
								<div class="col-md-5 mb-3">
									<label>Icon</label>
									<input type="file" name="icon" class="form-control" required>
								</div>

								<!-- Button -->
								<div class="col-md-2 mb-3">
									<button type="submit" name="submit" class="btn btn-primary w-100">
										Add
									</button>
								</div>

							</div>

						</form>
					</div>

					<!-- CATEGORY LIST -->
					<div class="card p-4">

						<h5>All Categories</h5>

						<table class="table table-bordered mt-3">
							<thead>
								<tr>
									<th>S.No</th>
									<th>Icon</th>
									<th>Name</th>
									<th>Action</th>
								</tr>
							</thead>

							<tbody>

								<?php

								// FETCH CATEGORY
								$result = $conn->query("SELECT * FROM categories");

								$i = 1;

								while ($row = $result->fetch_assoc()) {
									?>

									<tr>
										<td>
											<?= $i++ ?>
										</td>
										<td>
											<img src="assets/img/category/<?= $row['icon'] ?>" width="40">
										</td>
										<td>
											<?= $row['name'] ?>
										</td>
										<td>

											<!-- EDIT BUTTON -->
											<button class="btn btn-primary btn-sm" data-toggle="modal"
												data-target="#editModal<?= $row['id'] ?>">
												Edit
											</button>

											<!-- DELETE BUTTON -->
											<a href="?delete=<?= $row['id'] ?>" class="btn btn-danger btn-sm"
												onclick="return confirm('Are you sure want to delete this category?')">
												Delete
											</a>

										</td>
									</tr>

									<!-- EDIT MODAL -->
									<div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1">

										<div class="modal-dialog">
											<div class="modal-content">

												<form method="POST" enctype="multipart/form-data">

													<div class="modal-header">
														<h5 class="modal-title">Edit Category</h5>

														<button type="button" class="close" data-dismiss="modal">
															&times;
														</button>
													</div>

													<div class="modal-body">

														<input type="hidden" name="id" value="<?= $row['id'] ?>">
														<input type="hidden" name="old_icon" value="<?= $row['icon'] ?>">

														<!-- NAME -->
														<div class="form-group">
															<label>Category Name</label>

															<input type="text" name="name" class="form-control"
																value="<?= $row['name'] ?>" required>
														</div>

														<!-- OLD IMAGE -->
														<div class="form-group">
															<img src="assets/img/category/<?= $row['icon'] ?>" width="70">
														</div>

														<!-- NEW IMAGE -->
														<div class="form-group">
															<label>Change Icon</label>

															<input type="file" name="icon" class="form-control">
														</div>

													</div>

													<div class="modal-footer">

														<button type="button" class="btn btn-secondary"
															data-dismiss="modal">
															Close
														</button>

														<button type="submit" name="update" class="btn btn-primary">
															Update
														</button>

													</div>

												</form>

											</div>
										</div>

									</div>

								<?php } ?>

							</tbody>
						</table>

					</div>

				</div>
			</div>
		</div>
	</div>

</body>
<script src="assets/js/core/jquery.3.2.1.min.js"></script>
<script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/plugin/chartist/chartist.min.js"></script>
<script src="assets/js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
<script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
<script src="assets/js/plugin/chart-circle/circles.min.js"></script>
<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="assets/js/ready.min.js"></script>
<script src="assets/js/demo.js"></script>

</html>