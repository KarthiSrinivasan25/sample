<?php
include 'config/db.php';

// INSERT PRODUCT
if (isset($_POST['submit'])) {

    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $stock = $_POST['stock'];

    // IMAGE
    $image = time() . '_' . $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    $allowed = ['jpg', 'jpeg', 'png', 'webp'];

    $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) {
        die("Invalid File Type");
    }

    // FILE SIZE CHECK (2MB)
    if ($_FILES['image']['size'] > 2000000) {
        die("File too large");
    }

    move_uploaded_file($tmp, "assets/img/product/" . $image);

    $stmt = $conn->prepare("INSERT INTO products(product_name, price, category_id, description, image, stock) VALUES(?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("sdissi", $product_name, $price, $category, $description, $image, $stock);

    $stmt->execute();

    header("Location: product.php");
    exit();
}

// UPDATE PRODUCT
if (isset($_POST['update'])) {

    $id = $_POST['id'];
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $stock = $_POST['stock'];

    $old_image = $_POST['old_image'];

    // NEW IMAGE
    if ($_FILES['image']['name'] != '') {

        $image = time() . '_' . $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];

        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed)) {
            die("Invalid File Type");
        }

        move_uploaded_file($tmp, "assets/img/product/" . $image);

        // DELETE OLD IMAGE
        if (file_exists("assets/img/product/" . $old_image)) {
            unlink("assets/img/product/" . $old_image);
        }

    } else {

        $image = $old_image;
    }

    $stmt = $conn->prepare("UPDATE products SET product_name=?, price=?, category_id=?, description=?, image=?, stock=? WHERE id=?");

    $stmt->bind_param("sdissii", $product_name, $price, $category, $description, $image, $stock, $id);

    $stmt->execute();

    header("Location: product.php");
    exit();
}

// DELETE PRODUCT
if (isset($_GET['delete'])) {

    $id = $_GET['delete'];

    // GET IMAGE
    $get = $conn->prepare("SELECT image FROM products WHERE id=?");
    $get->bind_param("i", $id);
    $get->execute();

    $result = $get->get_result();
    $row = $result->fetch_assoc();

    // DELETE IMAGE
    if ($row && file_exists("assets/img/product/" . $row['image'])) {
        unlink("assets/img/product/" . $row['image']);
    }

    // DELETE PRODUCT
    $stmt = $conn->prepare("DELETE FROM products WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: product.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Kids Toys Shop Product</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="assets/css/ready.css">
    <link rel="stylesheet" href="assets/css/demo.css">
</head>

<body>
    <div class="wrapper">
        <div class="main-header">
            <div class="logo-header">
                <a href="index.php" class="logo">
                    Kids Toys Shop
                </a>
                <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse"
                    data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <button class="topbar-toggler more"><i class="la la-ellipsis-v"></i></button>
            </div>
            <nav class="navbar navbar-header navbar-expand-lg">
                <div class="container-fluid">

                    <form class="navbar-left navbar-form nav-search mr-md-3" action="">
                        <div class="input-group">
                            <input type="text" placeholder="Search ..." class="form-control">
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <i class="la la-search search-icon"></i>
                                </span>
                            </div>
                        </div>
                    </form>
                    <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">


                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#"
                                aria-expanded="false"> <img src="assets/img/user.png" alt="user-img" width="36"
                                    class="img-circle"><span>Admin</span></span> </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li>
                                    <div class="user-box">
                                        <div class="u-img"><img src="assets/img/user.png" alt="user"></div>
                                        <div class="u-text">
                                            <h4>Admin</h4>
                                            <p class="text-muted">kidsshop@gmail.com</p><a href="#"
                                                class="btn btn-rounded btn-danger btn-sm">View Profile</a>
                                        </div>
                                    </div>
                                </li>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#"><i class="ti-user"></i> My Profile</a>
                                <a class="dropdown-item" href="#"></i> My Balance</a>
                                <a class="dropdown-item" href="#"><i class="ti-email"></i> Inbox</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#"><i class="ti-settings"></i> Account Setting</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#"><i class="fa fa-power-off"></i> Logout</a>
                            </ul>
                            <!-- /.dropdown-user -->
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class="sidebar">
            <div class="scrollbar-inner sidebar-wrapper">
                <div class="user">
                    <div class="photo">
                        <img src="assets/img/user.png">
                    </div>
                    <div class="info">
                        <a class="" data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                            <span>
                                Kids Shop
                                <span class="user-level">Administrator</span>

                            </span>
                        </a>
                        <div class="clearfix"></div>


                    </div>
                </div>
                <ul class="nav">
                    <li class="nav-item">
                        <a href="index.php">
                            <i class="la la-dashboard"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="user.php">
                            <i class="la la-user"></i>
                            <p>User</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="category.php">
                            <i class="la la-list"></i>
                            <p>Category</p>
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a href="product.php">
                            <i class="la la-cube"></i>
                            <p>Product</p>
                        </a>
                    </li>

                </ul>
            </div>
        </div>
        <div class="main-panel">

            <div class="content">
                <div class="container-fluid">

                    <h4 class="page-title">Product</h4>

                    <!-- ADD PRODUCT -->
                    <div class="card p-4 mb-4">

                        <h5>Add New Product</h5>

                        <form method="POST" enctype="multipart/form-data">

                            <div class="row">

                                <div class="col-md-4 mb-3">
                                    <label>Product Name</label>
                                    <input type="text" name="product_name" class="form-control" required>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label>Price</label>
                                    <input type="number" step="0.01" name="price" class="form-control" required>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label>Category</label>

                                    <select name="category" class="form-control" required>

                                        <option value="">Select Category</option>

                                        <?php
                                        $cat = $conn->query("SELECT * FROM categories");

                                        while ($c = $cat->fetch_assoc()) {
                                            ?>

                                            <option value="<?= $c['id'] ?>">
                                                <?= $c['name'] ?>
                                            </option>

                                        <?php } ?>

                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label>Product Image</label>
                                    <input type="file" name="image" class="form-control" required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label>Stock Quantity</label>
                                    <input type="number" name="stock" class="form-control" required>
                                </div>

                                <div class="col-md-12 mb-3">
                                    <label>Description</label>

                                    <textarea name="description" class="form-control" rows="4" required></textarea>
                                </div>

                                <div class="col-md-2">
                                    <button type="submit" name="submit" class="btn btn-primary w-100">
                                        Add Product
                                    </button>
                                </div>

                            </div>

                        </form>

                    </div>

                    <!-- PRODUCT TABLE -->
                    <div class="card p-4">

                        <h5>All Products</h5>

                        <table class="table table-bordered mt-3">

                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Image</th>
                                    <th>Product</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php

                                $query = "
                                            SELECT products.*, categories.name AS category_name
                                            FROM products
                                            INNER JOIN categories
                                            ON products.category_id = categories.id
                                            ";

                                $result = $conn->query($query);

                                $i = 1;

                                while ($row = $result->fetch_assoc()) {

                                    ?>

                                    <tr>

                                        <td><?= $i++ ?></td>

                                        <td>
                                            <img src="assets/img/product/<?= $row['image'] ?>" width="60">
                                        </td>

                                        <td><?= htmlspecialchars($row['product_name']) ?></td>

                                        <td><?= htmlspecialchars($row['category_name']) ?></td>

                                        <td>₹<?= $row['price'] ?></td>

                                        <td><?= $row['stock'] ?></td>

                                        <td>

                                            <!-- EDIT -->
                                            <button class="btn btn-primary btn-sm" data-toggle="modal"
                                                data-target="#editModal<?= $row['id'] ?>">
                                                Edit
                                            </button>

                                            <!-- DELETE -->
                                            <a href="?delete=<?= $row['id'] ?>" class="btn btn-danger btn-sm"
                                                onclick="return confirm('Delete this product?')">
                                                Delete
                                            </a>

                                        </td>

                                    </tr>

                                    <!-- EDIT MODAL -->
                                    <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-lg modal-dialog-centered">
                                            <div class="modal-content border-0 shadow-lg rounded-4">

                                                <form method="POST" enctype="multipart/form-data">

                                                    <!-- Header -->
                                                    <div class="modal-header bg-primary text-white rounded-top-4">
                                                        <h4 class="modal-title">
                                                            <i class="la la-edit mr-2"></i> Edit Product
                                                        </h4>

                                                        <button type="button" class="close text-white" data-dismiss="modal">
                                                            <span>&times;</span>
                                                        </button>
                                                    </div>

                                                    <!-- Body -->
                                                    <div class="modal-body p-4">

                                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                        <input type="hidden" name="old_image" value="<?= $row['image'] ?>">

                                                        <div class="row">

                                                            <!-- Left Side -->
                                                            <div class="col-md-8">

                                                                <div class="form-group">
                                                                    <label class="font-weight-bold">Product Name</label>

                                                                    <input type="text" name="product_name"
                                                                        class="form-control rounded-pill"
                                                                        value="<?= $row['product_name'] ?>" required>
                                                                </div>

                                                                <div class="row">

                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label class="font-weight-bold">Price</label>

                                                                            <input type="number" step="0.01" name="price"
                                                                                class="form-control rounded-pill"
                                                                                value="<?= $row['price'] ?>" required>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <label class="font-weight-bold">Stock</label>

                                                                            <input type="number" name="stock"
                                                                                class="form-control rounded-pill"
                                                                                value="<?= $row['stock'] ?>">
                                                                        </div>
                                                                    </div>

                                                                </div>

                                                                <div class="form-group">
                                                                    <label class="font-weight-bold">Category</label>

                                                                    <select name="category"
                                                                        class="form-control rounded-pill">

                                                                        <?php
                                                                        $cats = $conn->query("SELECT * FROM categories");

                                                                        while ($cat = $cats->fetch_assoc()) {
                                                                            ?>

                                                                            <option value="<?= $cat['id'] ?>"
                                                                                <?= ($cat['id'] == $row['category_id']) ? 'selected' : '' ?>>
                                                                                <?= $cat['name'] ?>
                                                                            </option>

                                                                        <?php } ?>

                                                                    </select>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label class="font-weight-bold">Description</label>

                                                                    <textarea name="description"
                                                                        class="form-control rounded-3"
                                                                        rows="5"><?= $row['description'] ?></textarea>
                                                                </div>

                                                            </div>

                                                            <!-- Right Side -->
                                                            <div class="col-md-4 text-center">

                                                                <label class="font-weight-bold d-block mb-3">
                                                                    Product Image
                                                                </label>

                                                                <img src="assets/img/product/<?= $row['image'] ?>"
                                                                    class="img-fluid rounded-4 shadow-sm border mb-3"
                                                                    style="height:220px; object-fit:cover;">

                                                                <div class="form-group">
                                                                    <input type="file" name="image"
                                                                        class="form-control-file">
                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>

                                                    <!-- Footer -->
                                                    <div class="modal-footer bg-light rounded-bottom-4">

                                                        <button type="button"
                                                            class="btn btn-outline-secondary rounded-pill px-4"
                                                            data-dismiss="modal">
                                                            Close
                                                        </button>

                                                        <button type="submit" name="update"
                                                            class="btn btn-primary rounded-pill px-4">
                                                            Update Product
                                                        </button>

                                                    </div>

                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>

                            </tbody>

                        </table>

                    </div>

                </div>
            </div>

        </div>

    </div>

</body>
<script src="assets/js/core/jquery.3.2.1.min.js"></script>
<script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/plugin/chartist/chartist.min.js"></script>
<script src="assets/js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
<script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
<script src="assets/js/plugin/chart-circle/circles.min.js"></script>
<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="assets/js/ready.min.js"></script>
<script src="assets/js/demo.js"></script>

</html>