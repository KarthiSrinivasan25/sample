<?php

session_start();

include '../admin/config/db.php';

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "status" => "error",
        "message" => "Login required"
    ]);

    exit;
}

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$user_id = $_SESSION['user_id'];

$product_id = (int)$data['product_id'];

$qty = (int)$data['qty'];


// =========================
// GET PRODUCT STOCK
// =========================
$productQuery = $conn->prepare("
    SELECT stock
    FROM products
    WHERE id = ?
");

$productQuery->bind_param(
    "i",
    $product_id
);

$productQuery->execute();

$productResult = $productQuery->get_result();

if ($productResult->num_rows === 0) {

    echo json_encode([
        "status" => "error",
        "message" => "Product not found"
    ]);

    exit;
}

$product = $productResult->fetch_assoc();

$stock = (int)$product['stock'];

// =========================
// OUT OF STOCK CHECK
// =========================
if ($stock <= 0) {

    echo json_encode([
        "status" => "error",
        "message" => "Out of stock"
    ]);

    exit;
}


// =========================
// CHECK EXISTING CART
// =========================
$check = $conn->prepare("
    SELECT id, qty
    FROM cart
    WHERE user_id = ?
    AND product_id = ?
");

$check->bind_param(
    "ii",
    $user_id,
    $product_id
);

$check->execute();

$result = $check->get_result();

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();

    $newQty = $row['qty'] + $qty;

    // STOCK VALIDATION
    if ($newQty > $stock) {

        echo json_encode([
            "status" => "error",
            "message" => "Only $stock items available"
        ]);

        exit;
    }

    $update = $conn->prepare("
        UPDATE cart
        SET qty = ?
        WHERE id = ?
    ");

    $update->bind_param(
        "ii",
        $newQty,
        $row['id']
    );

    $update->execute();

} else {

    // STOCK VALIDATION
    if ($qty > $stock) {

        echo json_encode([
            "status" => "error",
            "message" => "Only $stock items available"
        ]);

        exit;
    }

    $insert = $conn->prepare("
        INSERT INTO cart(user_id, product_id, qty)
        VALUES(?,?,?)
    ");

    $insert->bind_param(
        "iii",
        $user_id,
        $product_id,
        $qty
    );

    $insert->execute();
}

echo json_encode([
    "status" => "success"
]);