<?php

session_start();

include '../admin/config/db.php';

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "count" => 0
    ]);

    exit;
}

$user_id = $_SESSION['user_id'];

$sql = $conn->prepare("
    SELECT SUM(qty) as total
    FROM cart
    WHERE user_id = ?
");

$sql->bind_param("i", $user_id);

$sql->execute();

$result = $sql->get_result();

$row = $result->fetch_assoc();

echo json_encode([
    "count" => (int)($row['total'] ?? 0)
]);
?>