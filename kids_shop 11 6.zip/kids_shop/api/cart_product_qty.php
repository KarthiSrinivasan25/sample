<?php

session_start();

include '../admin/config/db.php';

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "qty" => 0
    ]);

    exit;
}

$product_id = (int)$_GET['product_id'];

$user_id = $_SESSION['user_id'];

$query = $conn->prepare("
    SELECT qty
    FROM cart
    WHERE user_id = ?
    AND product_id = ?
");

$query->bind_param(
    "ii",
    $user_id,
    $product_id
);

$query->execute();

$result = $query->get_result();

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();

    echo json_encode([
        "qty" => $row['qty']
    ]);

} else {

    echo json_encode([
        "qty" => 0
    ]);
}