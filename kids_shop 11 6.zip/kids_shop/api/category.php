<?php

// include '../admin/config/db.php';

// header("Content-Type: application/json");

// $result = $conn->query("SELECT * FROM categories");

// $categories = [];

// while ($row = $result->fetch_assoc()) {

//     $categories[] = [
//         "id" => $row['id'],
//         "name" => strtolower($row['name']),
//         "icon" => $row['icon']
//     ];
// }

// echo json_encode($categories);

include '../admin/config/db.php';
header("Content-Type: application/json");

$result = $conn->query("SELECT * FROM categories");

$categories = [];

while ($row = $result->fetch_assoc()) {

    $catId = $row['id'];

    // count products in this category
    $countResult = $conn->query("
        SELECT COUNT(*) as total 
        FROM products 
        WHERE category_id = $catId
    ");

    $countRow = $countResult->fetch_assoc();

    $categories[] = [
        "id" => $catId,
        "name" => $row['name'],
        "slug" => strtolower($row['name']),
        "icon" => $row['icon'],
        "count" => $countRow['total']
    ];
}

echo json_encode($categories);

?>