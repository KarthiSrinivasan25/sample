<?php
session_start();

include '../admin/config/db.php';

header("Content-Type: application/json");

if(!isset($_SESSION['user_id'])){
    echo json_encode([
        "status" => "error"
    ]);
    exit;
}

$user_id = $_SESSION['user_id'];

$query = $conn->prepare("
    DELETE FROM cart
    WHERE user_id = ?
");

$query->bind_param("i", $user_id);

if($query->execute()){

    echo json_encode([
        "status" => "success"
    ]);

}else{

    echo json_encode([
        "status" => "error"
    ]);
}
?>