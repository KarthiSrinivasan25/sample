<?php

session_start();

include '../admin/config/db.php';

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {

    echo json_encode([]);

    exit;
}

$user_id = $_SESSION['user_id'];

$query = $conn->prepare("
    SELECT
        c.product_id AS id,
        c.qty,
        p.product_name,
        p.price,
        p.image,
        p.stock
    FROM cart c
    JOIN products p
    ON p.id = c.product_id
    WHERE c.user_id = ?
");

$query->bind_param(
    "i",
    $user_id
);

$query->execute();

$result = $query->get_result();

$cart = [];

while($row = $result->fetch_assoc()){

    $cart[] = $row;
}

echo json_encode($cart);

?>