<?php
include '../admin/config/db.php';
header("Content-Type: application/json");

$category = $_GET['category'] ?? 'all';

$data = [];

if ($category == "all") {

    $sql = "
        SELECT p.*, c.name AS category_name
        FROM products p
        JOIN categories c ON p.category_id = c.id
    ";

    $result = $conn->query($sql);

} else {

    $stmt = $conn->prepare("
        SELECT p.*, c.name AS category_name
        FROM products p
        JOIN categories c ON p.category_id = c.id
        WHERE p.category_id = ?
    ");

    $stmt->bind_param("i", $category);
    $stmt->execute();
    $result = $stmt->get_result();
}

while ($row = $result->fetch_assoc()) {

    $data[] = [
        "id" => $row['id'],
        "name" => $row['product_name'],
        "description" =>$row['description'],
        "price" => $row['price'],
        "category" => $row['category_id'],
        "image" => "admin/assets/img/product/" . $row['image'],
        "stock" => $row['stock'],
        "rating" => 5
    ];
}

echo json_encode($data);
?>