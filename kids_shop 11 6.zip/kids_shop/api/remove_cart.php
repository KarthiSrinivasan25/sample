<?php

session_start();

include '../admin/config/db.php';

if (!isset($_SESSION['user_id'])) {
    exit;
}

$user_id = $_SESSION['user_id'];

$product_id = $_POST['product_id'];

$query = $conn->prepare("
    DELETE FROM cart
    WHERE user_id = ? AND product_id = ?
");

$query->bind_param(
    "ii",
    $user_id,
    $product_id
);

$query->execute();

echo json_encode([
    "status" => true
]);
?>