<?php

include '../admin/config/db.php';
header("Content-Type: application/json");

$result = $conn->query("
    SELECT COUNT(*) as total 
    FROM products 
    WHERE is_sale = 1
");

$row = $result->fetch_assoc();

echo json_encode([
    "count" => $row['total']
]);