<?php

session_start();

include '../admin/config/db.php';

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "status" => "error"
    ]);

    exit;
}

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$user_id = $_SESSION['user_id'];

foreach ($data as $item) {

    $product_id = $item['id'];

    $qty = $item['qty'];

    // check existing
    $check = $conn->prepare("
        SELECT id, qty
        FROM cart
        WHERE user_id = ?
        AND product_id = ?
    ");

    $check->bind_param(
        "ii",
        $user_id,
        $product_id
    );

    $check->execute();

    $result = $check->get_result();

    if ($result->num_rows > 0) {

        $row = $result->fetch_assoc();

        $newQty = $row['qty'] + $qty;

        $update = $conn->prepare("
            UPDATE cart
            SET qty = ?
            WHERE id = ?
        ");

        $update->bind_param(
            "ii",
            $newQty,
            $row['id']
        );

        $update->execute();

    } else {

        $insert = $conn->prepare("
            INSERT INTO cart(user_id, product_id, qty)
            VALUES(?,?,?)
        ");

        $insert->bind_param(
            "iii",
            $user_id,
            $product_id,
            $qty
        );

        $insert->execute();
    }
}

echo json_encode([
    "status" => "success"
]);
?>