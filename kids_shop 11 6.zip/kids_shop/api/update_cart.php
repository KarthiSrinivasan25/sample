<?php

session_start();

include '../admin/config/db.php';

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "status" => false,
        "message" => "Login required"
    ]);

    exit;
}

$user_id = $_SESSION['user_id'];

$product_id = $_POST['product_id'];

$qty = $_POST['qty'];

$query = $conn->prepare("
    UPDATE cart
    SET qty = ?
    WHERE user_id = ? AND product_id = ?
");

$query->bind_param(
    "iii",
    $qty,
    $user_id,
    $product_id
);

if($query->execute()){

    echo json_encode([
        "status" => true
    ]);

}else{

    echo json_encode([
        "status" => false
    ]);
}
?>