<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KidsZone - Secure Checkout</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
    rel="stylesheet">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link href="assets/css/styles.css" rel="stylesheet">
  <style>
    
    

    
    

    

    


   
  </style>
</head>

<body>

  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><i class="bi bi-balloon-heart-fill"></i> KidsZone</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">
          <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-house-door"></i> Home</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php"><i class="bi bi-heart"></i> About</a></li>
          <li class="nav-item"><a class="nav-link" href="products.php"><i class="bi bi-grid-3x3-gap-fill"></i> Shop</a>
          </li>
          <li class="nav-item"><a class="nav-link position-relative" href="cart.php"><i class="bi bi-cart3"></i> Cart
              <span id="cartCountNav" class="cart-badge">0</span></a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php"><i class="bi bi-telephone"></i> Contact Us</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i>

              <?php if (isset($_SESSION['user_name'])): ?>
                <?= $_SESSION['user_name']; ?>
              <?php else: ?>
                Account
              <?php endif; ?>

            </a>

            <ul class="dropdown-menu dropdown-menu-end">

              <?php if (!isset($_SESSION['user_name'])): ?>

                <li>
                  <a class="dropdown-item" href="login.php">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                  </a>
                </li>

                <li>
                  <a class="dropdown-item" href="signup.php">
                    <i class="bi bi-person-plus"></i> Signup
                  </a>
                </li>

              <?php else: ?>

                <li>
                  <span class="dropdown-item-text">
                    👋 Hello,
                    <?= $_SESSION['user_name']; ?>
                  </span>
                </li>

                <li>
                  <hr class="dropdown-divider">
                </li>

                <li>
                  <a class="dropdown-item text-danger" href="logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                  </a>
                </li>

              <?php endif; ?>

            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <main class="container my-4">
    <!-- Progress Steps - Visual Only, Not Clickable -->
    <div class="progress-steps" data-aos="fade-down">
      <div class="step completed">
        <div class="step-circle"><i class="bi bi-cart3"></i></div>
        <div class="step-label">Cart</div>
      </div>
      <div class="step active">
        <div class="step-circle">2</div>
        <div class="step-label">Checkout</div>
      </div>
      <div class="step">
        <div class="step-circle">3</div>
        <div class="step-label">Payment</div>
      </div>
      <div class="step">
        <div class="step-circle">4</div>
        <div class="step-label">Confirmation</div>
      </div>
    </div>

    <!-- Step 1: Checkout Form -->
    <div id="checkoutStep" class="step-content">
      <div class="row g-4">
        <div class="col-lg-7" data-aos="fade-right">
          <div class="checkout-card">
            <h3 class="fw-bold mb-4"> 🎁 Checkout Details</h3>

            <form id="checkoutFormStep1">
              <h5 class="fw-bold mb-3"><i class="bi bi-envelope"></i> Contact Information</h5>
              <div class="row mb-3">
                <div class="col-md-6">
                  <label class="form-label fw-bold">Full Name *</label>
                  <input type="text" class="form-control" id="fullName" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold">Email Address *</label>
                  <input type="email" class="form-control" id="email" required>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold">Phone Number</label>
                <input type="tel" class="form-control" id="phone">
              </div>

              <h5 class="fw-bold mb-3 mt-4"><i class="bi bi-truck"></i> Shipping Address</h5>
              <div class="mb-3">
                <label class="form-label fw-bold">Street Address *</label>
                <input type="text" class="form-control" id="address" required>
              </div>
              <div class="row mb-3">
                <div class="col-md-4">
                  <label class="form-label fw-bold">City *</label>
                  <input type="text" class="form-control" id="city" required>
                </div>
                <div class="col-md-4">
                  <label class="form-label fw-bold">State</label>
                  <select class="form-select" id="state">
                    <option>Tamil Nadu</option>
                    <option>Karnataka</option>
                    <option>Maharashtra</option>
                    <option>Kerala</option>
                    <option>Delhi</option>
                    <option>West Bengal</option>
                    <option>Gujarat</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="form-label fw-bold">ZIP Code *</label>
                  <input type="text" class="form-control" id="zip"  required>
                </div>
              </div>

              <div class="mb-3">
                <label class="form-label fw-bold">Special Instructions (Optional)</label>
                <textarea class="form-control" rows="2" id="instructions"
                  ></textarea>
              </div>

              <div class="form-check mb-4">
                <input class="form-check-input" type="checkbox" id="giftWrap"
                  style="border-radius: 4px; border-color: #ffaa55;">
                <label class="form-check-label" for="giftWrap">
                  🎀 Add Free Gift Wrapping + Personalized Note
                </label>
              </div>

              <button type="button" class="btn btn-kid w-100 mt-2 py-3" onclick="goToPayment()">
                Continue to Payment <i class="bi bi-arrow-right"></i>
              </button>
            </form>
          </div>
        </div>

        <div class="col-lg-5" data-aos="fade-left">
          <div class="order-summary">
            <h5 class="fw-bold mb-3"><i class="bi bi-receipt"></i> Order Summary</h5>
            <div id="checkoutItemsList" class="mb-3" style="max-height: 300px; overflow-y: auto;"></div>
            <hr>
            <div id="orderTotals"></div>
            <div class="mt-3 text-center">
              <small class="text-muted">
                <i class="bi bi-lock-fill"></i> Secure checkout
              </small>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Step 2: Payment Method (INDIA VERSION) -->
<div id="paymentStep" class="step-content" style="display: none;">
  <div class="row g-4">

    <!-- LEFT SIDE -->
    <div class="col-lg-7" data-aos="fade-right">
      <div class="checkout-card">

        <h3 class="fw-bold mb-4">
          <i class="bi bi-credit-card"></i> 💳 Payment Method
        </h3>

        <!-- UPI -->
        <div class="payment-method selected" onclick="selectPayment('upi')">
          <input type="radio" name="paymentMethod" value="upi" id="upiPay" checked>
          <i class="bi bi-phone"></i> UPI (Google Pay / PhonePe / Paytm)
        </div>

        <div id="upiDetails" class="mt-3">
          <div class="alert alert-success">
            <i class="bi bi-lightning-charge"></i>
            Pay instantly using UPI ID or scan QR code at next step.
          </div>
          <input type="text" class="form-control mb-2" id="upiId"
                 placeholder="yourname@upi">
          <small class="text-muted">Example: name@okaxis / name@ybl</small>
        </div>

        <!-- CARD -->
        <div class="payment-method" onclick="selectPayment('card')">
          <input type="radio" name="paymentMethod" value="card" id="cardPay">
          <i class="bi bi-credit-card"></i> Credit / Debit Card
        </div>

        <div id="cardDetails" class="mt-3" style="display:none;">
          <input type="text" class="form-control mb-2" id="cardNumber" placeholder="Card Number">
          <div class="row">
            <div class="col-md-6">
              <input type="text" class="form-control mb-2" id="expiry" placeholder="MM/YY">
            </div>
            <div class="col-md-6">
              <input type="password" class="form-control mb-2" id="cvv" placeholder="CVV">
            </div>
          </div>
          <input type="text" class="form-control" id="cardName" placeholder="Card Holder Name">
        </div>

        <!-- NET BANKING -->
        <div class="payment-method" onclick="selectPayment('netbanking')">
          <input type="radio" name="paymentMethod" value="netbanking" id="netPay">
          <i class="bi bi-bank"></i> Net Banking
        </div>

        <div id="netBankingDetails" class="mt-3" style="display:none;">
          <select class="form-select">
            <option>HDFC Bank</option>
            <option>ICICI Bank</option>
            <option>SBI</option>
            <option>Axis Bank</option>
            <option>Kotak Bank</option>
          </select>
        </div>

        <!-- COD -->
        <div class="payment-method" onclick="selectPayment('cod')">
          <input type="radio" name="paymentMethod" value="cod" id="codPay">
          <i class="bi bi-cash"></i> Cash on Delivery (COD)
        </div>

        <div id="codDetails" class="mt-3" style="display:none;">
          <div class="alert alert-warning">
            <i class="bi bi-info-circle"></i>
            Pay cash when your order is delivered.
          </div>
        </div>

        <!-- BUTTONS -->
        <div class="d-flex gap-3 mt-4">
          <button type="button" class="btn btn-outline-kid flex-grow-1" onclick="goToCheckout()">
            <i class="bi bi-arrow-left"></i> Back
          </button>

          <button type="button" class="btn btn-kid flex-grow-1" onclick="processPayment()">
            Place Order <i class="bi bi-check-lg"></i>
          </button>
        </div>

      </div>
    </div>

    <!-- RIGHT SIDE -->
    <div class="col-lg-5" data-aos="fade-left">
      <div class="order-summary">
        <h5 class="fw-bold mb-3">
          <i class="bi bi-receipt"></i> Order Summary
        </h5>

        <div id="checkoutItemsList2"
             class="mb-3"
             style="max-height: 300px; overflow-y: auto;"></div>

        <hr>
        <div id="orderTotals2"></div>
      </div>
    </div>

  </div>
</div>
    <!-- Step 3: Confirmation -->
    <div id="confirmationStep" class="step-content" style="display: none;">
      <div class="row justify-content-center">
        <div class="col-lg-8" data-aos="zoom-in">
          <div class="checkout-card text-center">
            <div class="confirmation-icon">
              <i class="bi bi-check-lg"></i>
            </div>
            <h2 class="fw-bold text-success mb-3">Order Confirmed! 🎉</h2>
            <p class="lead">Thank you for shopping at KidsZone!</p>
            <div id="orderDetails" class="mt-4 text-start"></div>
            <div class="mt-4">
              <a href="index.php" class="btn btn-kid btn-lg px-4">
                <i class="bi bi-house-door"></i> Return to Home
              </a>
              <a href="products.php" class="btn btn-outline-kid btn-lg px-4 ms-2">
                <i class="bi bi-grid"></i> Continue Shopping
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <footer class="text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5><i class="bi bi-balloon-heart-fill"></i> KidsZone</h5>
          <p>Where imagination grows! Safe, fun, educational toys for ages 0-10.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <p><a href="about.php" class="text-decoration-none text-dark">About Us</a> | <a href="products.php"
              class="text-decoration-none text-dark">Shop</a> | <a href="cart.php"
              class="text-decoration-none text-dark">Cart</a> | <a href="contact.php"
              class="text-decoration-none text-dark">Contact</a></p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Follow the Fun</h5>
          <i class="bi bi-instagram fs-3 mx-2"></i>
          <i class="bi bi-facebook fs-3 mx-2"></i>
          <i class="bi bi-youtube fs-3 mx-2"></i>
        </div>
      </div>
      <hr class="bg-dark">
      <p class="mb-0">🌟 KidsZone — Where imagination grows! 🌟 <br>© 2025 Magical Toy Store — Safe, Fun, Creative</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
AOS.init({
  duration: 600,
  once: true
});

let cart = [];
let customerData = {};
let taxRate = 0.08;

/* =========================
   INR FORMAT
========================= */
function currency(amount) {

  return "₹" + Number(amount).toLocaleString(
    "en-IN",
    {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }
  );
}

/* =========================
   LOAD CART
========================= */
async function loadCart() {

  try {

    <?php if(isset($_SESSION['user_id'])): ?>

      const res = await fetch(
        'api/get_cart.php'
      );

      const data = await res.json();

      cart = data.map(item => ({

        id: item.id,
        name: item.product_name,
        price: Number(item.price),
        qty: Number(item.qty),
        image: item.image

      }));

    <?php else: ?>

      cart =
        JSON.parse(
          localStorage.getItem('kidsCart')
        ) || [];

    <?php endif; ?>

    renderCheckoutSummary();

    updateCartBadge();

  } catch(err) {

    console.log(err);
  }
}

/* =========================
   CART BADGE
========================= */
function updateCartBadge() {

  const total = cart.reduce(
    (sum, item) =>
      sum + Number(item.qty),
    0
  );

  document.getElementById(
    'cartCountNav'
  ).innerText = total;
}

/* =========================
   SUBTOTAL
========================= */
function getCartSubtotal() {

  return cart.reduce((sum, item) => {

    return sum +
      (
        Number(item.price)
        *
        Number(item.qty)
      );

  }, 0);
}

/* =========================
   SHIPPING
========================= */
function calculateShipping(subtotal) {

  return subtotal >= 999
    ? 0
    : 99;
}

/* =========================
   TAX
========================= */
function calculateTax(subtotal) {

  return subtotal * taxRate;
}

/* =========================
   RENDER SUMMARY
========================= */
function renderCheckoutSummary() {

  const box1 =
    document.getElementById(
      'checkoutItemsList'
    );

  const box2 =
    document.getElementById(
      'checkoutItemsList2'
    );

  if(!cart.length){

    box1.innerHTML = `
      <div class="text-center py-4">

        <h5>Cart Empty</h5>

        <a href="products.php"
          class="btn btn-kid mt-2">

          Shop Now

        </a>

      </div>
    `;

    if(box2){
      box2.innerHTML = box1.innerHTML;
    }

    return;
  }

  let html = '';

  cart.forEach(item => {

    const subtotal =
      item.price * item.qty;

    html += `

      <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">

        <div>

          <div class="fw-bold">
            ${item.name}
          </div>

          <small class="text-muted">
            Qty: ${item.qty}
          </small>

        </div>

        <div class="fw-bold text-success">
          ${currency(subtotal)}
        </div>

      </div>
    `;
  });

  box1.innerHTML = html;

  if(box2){
    box2.innerHTML = html;
  }

  updateTotals();
}

/* =========================
   TOTALS
========================= */
function updateTotals() {

  const subtotal =
    getCartSubtotal();

  const shipping =
    calculateShipping(subtotal);

  const tax =
    calculateTax(subtotal);

  const total =
    subtotal +
    shipping +
    tax;

  const html = `

    <div class="summary-row d-flex justify-content-between mb-2">

      <span>Subtotal</span>

      <span>
        ${currency(subtotal)}
      </span>

    </div>

    <div class="summary-row d-flex justify-content-between mb-2">

      <span>Shipping</span>

      <span>

        ${
          shipping === 0
          ? '<span class="text-success">Free</span>'
          : currency(shipping)
        }

      </span>

    </div>

    <div class="summary-row d-flex justify-content-between mb-2">

      <span>Tax (8%)</span>

      <span>
        ${currency(tax)}
      </span>

    </div>

    <hr>

    <div class="summary-row d-flex justify-content-between fw-bold fs-5">

      <span>Total</span>

      <span>
        ${currency(total)}
      </span>

    </div>
  `;

  document.getElementById(
    'orderTotals'
  ).innerHTML = html;

  document.getElementById(
    'orderTotals2'
  ).innerHTML = html;
}

/* =========================
   UPDATE PROGRESS STEPS
========================= */
/* =========================
   UPDATE PROGRESS STEPS
========================= */
function updateProgressSteps(step) {

  const steps =
    document.querySelectorAll('.step');

  steps.forEach((el, index) => {

    const current = index + 1;

    const circle =
      el.querySelector('.step-circle');

    el.classList.remove(
      'active',
      'completed'
    );

    // RESET NUMBER
    if(current === 1){

      circle.innerHTML =
        '<i class="bi bi-cart3"></i>';

    }else{

      circle.innerHTML = current;
    }

    // COMPLETED
    if(current < step){

      el.classList.add(
        'completed'
      );

      circle.innerHTML =
        '<i class="bi bi-check-lg"></i>';
    }

    // ACTIVE
    else if(current === step){

      el.classList.add(
        'active'
      );

      // STEP 4 SHOULD SHOW NUMBER
      if(current === 4){

        circle.innerHTML = '4';
      }
    }
  });
}
/* =========================
   STEP SWITCH
========================= */
function showCheckoutStep(){

  document.getElementById(
    'checkoutStep'
  ).style.display = 'block';

  document.getElementById(
    'paymentStep'
  ).style.display = 'none';

  document.getElementById(
    'confirmationStep'
  ).style.display = 'none';

  updateProgressSteps(2);
}

function showPaymentStep(){

  document.getElementById(
    'checkoutStep'
  ).style.display = 'none';

  document.getElementById(
    'paymentStep'
  ).style.display = 'block';

  document.getElementById(
    'confirmationStep'
  ).style.display = 'none';

  updateProgressSteps(3);
}

function showConfirmationStep(){

  document.getElementById(
    'checkoutStep'
  ).style.display = 'none';

  document.getElementById(
    'paymentStep'
  ).style.display = 'none';

  document.getElementById(
    'confirmationStep'
  ).style.display = 'block';

  updateProgressSteps(4);
}
/* =========================
   NEXT STEP
========================= */
window.goToPayment = () => {

  customerData = {

    fullName:
      document.getElementById('fullName').value,

    email:
      document.getElementById('email').value,

    address:
      document.getElementById('address').value,

    city:
      document.getElementById('city').value,

    state:
      document.getElementById('state').value,

    zip:
      document.getElementById('zip').value
  };

  if(
    !customerData.fullName ||
    !customerData.email ||
    !customerData.address
  ){

    alert(
      "Please fill required fields"
    );

    return;
  }

  showPaymentStep();
};

/* =========================
   BACK
========================= */
window.goToCheckout = () => {

  showCheckoutStep();
};

/* =========================
   PAYMENT METHOD
========================= */
window.selectPayment = (method) => {

  document
    .querySelectorAll('.payment-method')
    .forEach(el => {

      el.classList.remove(
        'selected'
      );
    });

  event.currentTarget.classList.add(
    'selected'
  );

  document.getElementById(
    'upiDetails'
  ).style.display = 'none';

  document.getElementById(
    'cardDetails'
  ).style.display = 'none';

  document.getElementById(
    'netBankingDetails'
  ).style.display = 'none';

  document.getElementById(
    'codDetails'
  ).style.display = 'none';

  if(method === 'upi'){
    document.getElementById(
      'upiDetails'
    ).style.display = 'block';
  }

  if(method === 'card'){
    document.getElementById(
      'cardDetails'
    ).style.display = 'block';
  }

  if(method === 'netbanking'){
    document.getElementById(
      'netBankingDetails'
    ).style.display = 'block';
  }

  if(method === 'cod'){
    document.getElementById(
      'codDetails'
    ).style.display = 'block';
  }

  document.querySelector(
    `input[value="${method}"]`
  ).checked = true;
};

/* =========================
   PLACE ORDER
========================= */
window.processPayment = async () => {

  const subtotal =
    getCartSubtotal();

  const shipping =
    calculateShipping(subtotal);

  const tax =
    calculateTax(subtotal);

  const total =
    subtotal +
    shipping +
    tax;

  const orderNo =
    'KZ' + Date.now();

  document.getElementById(
    'orderDetails'
  ).innerHTML = `

    <div class="bg-light p-4 rounded-4">

      <h5 class="fw-bold text-success mb-3">
        Order Successful 🎉
      </h5>

      <p>
        <strong>Order No:</strong>
        ${orderNo}
      </p>

      <p>
        <strong>Name:</strong>
        ${customerData.fullName}
      </p>

      <p>
        <strong>Email:</strong>
        ${customerData.email}
      </p>

      <p>
        <strong>Total:</strong>
        ${currency(total)}
      </p>

    </div>
  `;

  <?php if(isset($_SESSION['user_id'])): ?>

    await fetch(
      'api/clear_cart.php'
    );

  <?php else: ?>

    localStorage.removeItem(
      'kidsCart'
    );

  <?php endif; ?>

  cart = [];

  updateCartBadge();

  showConfirmationStep();
};

/* =========================
   INIT
========================= */
loadCart();
</script>
</body>

</html>