<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KidsZone - Contact Us | Get in Touch</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- AOS Animation Library -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link href="assets/css/styles.css" rel="stylesheet">
  <style>
   
    
    .form-control, .form-select {
      border-radius: 60px;
      padding: 12px 20px;
      border: 2px solid #ffe0b5;
      font-family: 'Quicksand', sans-serif;
    }
    .form-control:focus, .form-select:focus {
      border-color: #ffaa55;
      box-shadow: 0 0 0 0.2rem rgba(255,170,85,0.25);
    }
    textarea.form-control {
      border-radius: 24px;
    }
    
    
  
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><i class="bi bi-balloon-heart-fill"></i> KidsZone</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">
          <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-house-door"></i> Home</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php"><i class="bi bi-heart"></i> About</a></li>
          <li class="nav-item"><a class="nav-link" href="products.php"><i class="bi bi-grid-3x3-gap-fill"></i> Shop</a></li>
          <li class="nav-item"><a class="nav-link position-relative" href="cart.php"><i class="bi bi-cart3"></i> Cart <span id="cartCountNav" class="cart-badge">0</span></a></li>
          <li class="nav-item"><a class="nav-link" href="Contact.php"><i class="bi bi-telephone"></i> Contact Us</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i>

              <?php if (isset($_SESSION['user_name'])): ?>
                <?= $_SESSION['user_name']; ?>
              <?php else: ?>
                Account
              <?php endif; ?>

            </a>

            <ul class="dropdown-menu dropdown-menu-end">

              <?php if (!isset($_SESSION['user_name'])): ?>

                <li>
                  <a class="dropdown-item" href="login.php">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                  </a>
                </li>

                <li>
                  <a class="dropdown-item" href="signup.php">
                    <i class="bi bi-person-plus"></i> Signup
                  </a>
                </li>

              <?php else: ?>

                <li>
                  <span class="dropdown-item-text">
                    👋 Hello,
                    <?= $_SESSION['user_name']; ?>
                  </span>
                </li>

                <li>
                  <hr class="dropdown-divider">
                </li>

                <li>
                  <a class="dropdown-item text-danger" href="logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                  </a>
                </li>

              <?php endif; ?>

            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <main>
    <!-- Contact Hero Section -->
    <div class="contact-hero">
      <div class="container text-center" data-aos="fade-up">
        <h1 class="display-4 fw-bold">📬 Let's Connect!</h1>
        <p class="lead mt-3">We'd love to hear from you! Whether you have a question, feedback, or just want to say hello 🎈</p>
      </div>
    </div>

    <!-- Contact Options Cards -->
    <div class="container my-5" data-aos="fade-up">
      <div class="row g-4">
        <div class="col-md-4">
          <div class="contact-card">
            <div class="contact-icon">
              <i class="bi bi-telephone-fill"></i>
            </div>
            <h5 class="fw-bold">Call Us</h5>
            <p class="mb-2">Mon-Fri: 9AM - 6PM</p>
            <h4 class="text-warning">+91 9876543211</h4>
            <small class="text-muted">Toll-free for India</small>
          </div>
        </div>
        <div class="col-md-4">
          <div class="contact-card">
            <div class="contact-icon">
              <i class="bi bi-envelope-fill"></i>
            </div>
            <h5 class="fw-bold">Email Us</h5>
            <p class="mb-2">We reply within 24 hours</p>
            <h5 class="text-warning">hello@kidszone.com</h5>
            <small class="text-muted">support@kidszone.com</small>
          </div>
        </div>
        <div class="col-md-4">
          <div class="contact-card">
            <div class="contact-icon">
              <i class="bi bi-chat-dots-fill"></i>
            </div>
            <h5 class="fw-bold">Live Chat</h5>
            <p class="mb-2">Available 24/7</p>
            <button class="btn btn-kid mt-2" onclick="startChat()">Start Chat 💬</button>
            <small class="text-muted d-block mt-2">Real-time support</small>
          </div>
        </div>
      </div>
    </div>

    <!-- Contact Form & Info Row -->
    <div class="container my-5" data-aos="fade-up">
      <div class="row g-5">
        <!-- Contact Form -->
        <div class="col-lg-7">
          <div class="contact-form">
            <h2 class="fw-bold mb-4">✉️ Send us a Message</h2>
            <form id="contactForm">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label fw-bold">Your Name</label>
                  <input type="text" class="form-control" placeholder="Enter your name" id="contactName" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold">Email Address</label>
                  <input type="email" class="form-control" placeholder="your@email.com" id="contactEmail" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold">Phone (Optional)</label>
                  <input type="tel" class="form-control" placeholder="+91 9876543211">
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold">Subject</label>
                  <select class="form-select" id="contactSubject">
                    <option>General Inquiry</option>
                    <option>Order Question</option>
                    <option>Returns & Refunds</option>
                    <option>Product Suggestion</option>
                    <option>Wholesale Inquiry</option>
                    <option>Other</option>
                  </select>
                </div>
                <div class="col-12">
                  <label class="form-label fw-bold">Message</label>
                  <textarea class="form-control" rows="5" placeholder="Tell us how we can help you..." id="contactMessage" required></textarea>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn btn-kid btn-lg w-100">Send Message <i class="bi bi-send"></i></button>
                </div>
              </div>
            </form>
          </div>
        </div>
        
        <!-- Location & Hours -->
        <div class="col-lg-5">
  <div class="contact-form h-100">
    <h2 class="fw-bold mb-4">📍 Visit Our Store</h2>

    <div class="mb-4">
      <i class="bi bi-geo-alt-fill text-warning fs-3"></i>
      <p class="mt-2">
        <strong>KidsZone Wonderland</strong><br>
        45, Gandhi Road,<br>
        Attur, Salem,<br>
        Tamil Nadu 636102, India
      </p>
    </div>

    <div class="mb-4">
      <i class="bi bi-clock-fill text-warning fs-3"></i>
      <p class="mt-2">
        <strong>Store Hours</strong><br>
        Monday - Friday: 10:00 AM - 8:00 PM<br>
        Saturday: 10:00 AM - 9:00 PM<br>
        Sunday: 11:00 AM - 6:00 PM
      </p>
    </div>

    <!-- Google Map -->
    <div class="map-placeholder mt-3">
      <iframe
        src="https://maps.google.com/maps?q=Attur,Salem,Tamil%20Nadu&t=&z=13&ie=UTF8&iwloc=&output=embed"
        width="100%"
        height="300"
        style="border:0; border-radius:10px;"
        allowfullscreen=""
        loading="lazy">
      </iframe>
    </div>
  </div>
</div>
      </div>
    </div>

    <!-- FAQ Section -->
    <div class="container my-5" data-aos="fade-up">
  <h2 class="text-center fw-bold mb-5">❓ Frequently Asked Questions</h2>

  <div class="row justify-content-center">
    <div class="col-lg-8">

      <div class="accordion" id="faqAccordion">

        <!-- FAQ 1 -->
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button" type="button"
              data-bs-toggle="collapse" data-bs-target="#faq1">
              🚚 What are your shipping times?
            </button>
          </h2>

          <div id="faq1" class="accordion-collapse collapse show"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body">
              We offer free shipping across India on orders above ₹999!
              Standard delivery takes 3-5 business days.
              Express delivery (1-2 days) is available in selected cities
              including Chennai, Bengaluru, and Hyderabad for an additional fee.
            </div>
          </div>
        </div>

        <!-- FAQ 2 -->
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button"
              data-bs-toggle="collapse" data-bs-target="#faq2">
              🔄 What is your return policy?
            </button>
          </h2>

          <div id="faq2" class="accordion-collapse collapse"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body">
              We provide easy 7-day returns for damaged or defective products.
              Items must be unused and returned in original packaging.
              Refunds are processed within 5-7 working days after inspection.
            </div>
          </div>
        </div>

        <!-- FAQ 3 -->
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button"
              data-bs-toggle="collapse" data-bs-target="#faq3">
              🎁 Do you offer gift wrapping?
            </button>
          </h2>

          <div id="faq3" class="accordion-collapse collapse"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body">
              Yes! We offer free birthday gift wrapping and personalized
              message cards for all toy orders. Simply select the
              "Gift Wrap" option during checkout 🎈
            </div>
          </div>
        </div>

        <!-- FAQ 4 -->
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button"
              data-bs-toggle="collapse" data-bs-target="#faq4">
              🔒 Are your toys safe for toddlers?
            </button>
          </h2>

          <div id="faq4" class="accordion-collapse collapse"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body">
              Absolutely! All our toys are made from child-safe,
              non-toxic materials and follow Indian toy safety standards.
              Age recommendations are clearly mentioned on every product.
            </div>
          </div>
        </div>

        <!-- FAQ 5 -->
        <div class="accordion-item">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button"
              data-bs-toggle="collapse" data-bs-target="#faq5">
              🌍 Do you deliver across India?
            </button>
          </h2>

          <div id="faq5" class="accordion-collapse collapse"
            data-bs-parent="#faqAccordion">
            <div class="accordion-body">
              Yes! We deliver toys all over India including Tamil Nadu,
              Kerala, Karnataka, Maharashtra, Delhi, and more.
              Delivery charges may vary depending on your location.
            </div>
          </div>
        </div>

      </div>

    </div>
  </div>
</div>

    <!-- Social Media Connect -->
    <div class="container my-5" data-aos="zoom-in">
      <div class="bg-white rounded-5 p-5 text-center shadow-sm">
        <i class="bi bi-heart-fill fs-1 text-danger"></i>
        <h2 class="fw-bold mt-2">Follow the Magic! ✨</h2>
        <p class="lead">Join our magical community for giveaways, toy tips, and exclusive offers</p>
        <div class="d-flex justify-content-center gap-4 mt-4">
          <a href="#" class="text-decoration-none">
            <div class="bg-primary text-white rounded-circle d-inline-flex p-3" style="width: 60px; height: 60px;">
              <i class="bi bi-instagram fs-2 m-auto"></i>
            </div>
            <p class="mt-2 fw-bold">Instagram</p>
          </a>
          <a href="#" class="text-decoration-none">
            <div class="bg-primary text-white rounded-circle d-inline-flex p-3" style="width: 60px; height: 60px; background: #1877f2 !important;">
              <i class="bi bi-facebook fs-2 m-auto"></i>
            </div>
            <p class="mt-2 fw-bold">Facebook</p>
          </a>
          <a href="#" class="text-decoration-none">
            <div class="bg-dark text-white rounded-circle d-inline-flex p-3" style="width: 60px; height: 60px;">
              <i class="bi bi-tiktok fs-2 m-auto"></i>
            </div>
            <p class="mt-2 fw-bold">TikTok</p>
          </a>
          <a href="#" class="text-decoration-none">
            <div class="bg-danger text-white rounded-circle d-inline-flex p-3" style="width: 60px; height: 60px; background: #ff0000 !important;">
              <i class="bi bi-youtube fs-2 m-auto"></i>
            </div>
            <p class="mt-2 fw-bold">YouTube</p>
          </a>
        </div>
      </div>
    </div>
  </main>

  <footer class="text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5><i class="bi bi-balloon-heart-fill"></i> KidsZone</h5>
          <p>Where imagination grows! Safe, fun, educational toys for ages 0-10.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <p><a href="about.php" class="text-decoration-none text-dark">About Us</a> | <a href="products.php" class="text-decoration-none text-dark">Shop</a> | <a href="cart.php" class="text-decoration-none text-dark">Cart</a> | <a href="contact.php" class="text-decoration-none text-dark">Contact</a></p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Newsletter</h5>
          <div class="input-group">
            <input type="email" class="form-control rounded-pill me-2" placeholder="Your email" id="footerEmail" style="border-radius: 60px;">
            <button class="btn btn-kid rounded-pill" onclick="subscribeFooter()">Subscribe</button>
          </div>
        </div>
      </div>
      <hr class="bg-dark">
      <p class="mb-0">🌟 KidsZone — Where imagination grows! 🌟 <br>© 2025 Magical Toy Store — Safe, Fun, Creative</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 800, once: true });
    
    let cart = JSON.parse(localStorage.getItem('kidsCart')) || [];
    function updateCartBadge() { 
      let total = cart.reduce((s, i) => s + i.qty, 0); 
      let badge = document.getElementById('cartCountNav'); 
      if(badge) badge.innerText = total; 
    }
    updateCartBadge();
    
    // Contact Form Submission
    document.getElementById('contactForm').addEventListener('submit', function(e) {
      e.preventDefault();
      const name = document.getElementById('contactName').value;
      const email = document.getElementById('contactEmail').value;
      const subject = document.getElementById('contactSubject').value;
      const message = document.getElementById('contactMessage').value;
      
      if(name && email && message) {
        alert(`🎉 Thank you ${name}! Your message has been sent. We'll get back to you within 24 hours. 🎈`);
        document.getElementById('contactForm').reset();
      } else {
        alert('Please fill in all required fields! 💌');
      }
    });
    
    window.startChat = function() {
      alert('💬 Our friendly support team is ready to help! (Demo: Live chat would open here)');
    };
    
    window.subscribeFooter = function() {
      const email = document.getElementById('footerEmail').value;
      if(email && email.includes('@')) {
        alert('🎉 Thanks for subscribing! Check your inbox for 10% off!');
        document.getElementById('footerEmail').value = '';
      } else {
        alert('Please enter a valid email address!');
      }
    };
  </script>
</body>
</html>