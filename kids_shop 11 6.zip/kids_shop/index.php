<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KidsZone - Magical Toy Store</title>
  <!-- Bootstrap 5 + Icons + Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
    rel="stylesheet">
  <!-- AOS Animation Library -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
 
  <link href="assets/css/styles.css" rel="stylesheet">
</head>

<body>

  <!-- ======================= NAVBAR ======================= -->
  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><i class="bi bi-balloon-heart-fill"></i> KidsZone</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">

          <li class="nav-item">
            <a class="nav-link active" href="index.php">
              <i class="bi bi-house-door"></i> Home
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="about.php">
              <i class="bi bi-heart"></i> About
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="products.php">
              <i class="bi bi-grid-3x3-gap-fill"></i> Shop
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link position-relative" href="cart.php">
              <i class="bi bi-cart3"></i> Cart
              <span id="cartCountNav" class="cart-badge">0</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="contact.php">
              <i class="bi bi-telephone"></i> Contact Us
            </a>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i>

              <?php if (isset($_SESSION['user_name'])): ?>
                <?= $_SESSION['user_name']; ?>
              <?php else: ?>
                Account
              <?php endif; ?>

            </a>

            <ul class="dropdown-menu dropdown-menu-end">

              <?php if (!isset($_SESSION['user_name'])): ?>

                <li>
                  <a class="dropdown-item" href="login.php">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                  </a>
                </li>

                <li>
                  <a class="dropdown-item" href="signup.php">
                    <i class="bi bi-person-plus"></i> Signup
                  </a>
                </li>

              <?php else: ?>

                <li>
                  <span class="dropdown-item-text">
                    👋 Hello,
                    <?= $_SESSION['user_name']; ?>
                  </span>
                </li>

                <li>
                  <hr class="dropdown-divider">
                </li>

                <li>
                  <a class="dropdown-item text-danger" href="logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                  </a>
                </li>

              <?php endif; ?>

            </ul>
          </li>

        </ul>
      </div>
    </div>
  </nav>

  <!-- ================= MAIN CONTENT ================= -->
  <main>
    <!-- HERO CAROUSEL -->
    <div id="kidsZoneCarousel" class="carousel slide hero-carousel" data-bs-ride="carousel">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#kidsZoneCarousel" data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#kidsZoneCarousel" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#kidsZoneCarousel" data-bs-slide-to="2"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="https://images.unsplash.com/photo-1604881988758-f76ad2f7aac1?auto=format&fit=crop&w=1400&q=80"
            class="d-block w-100 hero-img" alt="kids toys">
          <div class="carousel-caption d-none d-md-block">
            <h1 class="fw-bold">✨ Magical Toys for Little Dreamers</h1>
            <p>Safe, fun & educational toys for every child</p>
            <a href="products.php" class="btn btn-kid btn-lg">Shop Now 🧸</a>
          </div>
        </div>
        <div class="carousel-item">
          <img src="https://images.unsplash.com/photo-1587654780291-39c9404d746b?auto=format&fit=crop&w=1400&q=80"
            class="d-block w-100 hero-img" alt="plush toys">
          <div class="carousel-caption d-none d-md-block">
            <h1 class="fw-bold">🦄 Soft Plush Friends</h1>
            <p>Cuddly companions kids love</p>
            <a href="products.php?category=plush" class="btn btn-kid btn-lg">Explore Plush</a>
          </div>
        </div>
        <div class="carousel-item">
          <img src="https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&w=1400&q=80"
            class="d-block w-100 hero-img" alt="art kit kids">
          <div class="carousel-caption d-none d-md-block">
            <h1 class="fw-bold">🎨 Creative Learning Kits</h1>
            <p>Boost imagination & creativity</p>
            <a href="products.php?category=art" class="btn btn-kid btn-lg">Start Creating</a>
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#kidsZoneCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#kidsZoneCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
      </button>
    </div>

    <!-- BENEFITS / FEATURES BANNER -->
    <div class="container my-5" data-aos="fade-up">
      <div class="row text-center g-4">
        <div class="col-md-3 col-6">
          <div class="p-3 bg-white rounded-4 shadow-sm">
            <i class="bi bi-truck fs-1 text-warning"></i>
            <h6 class="mt-2 fw-bold">Free Shipping</h6>
            <small>On orders $50+</small>
          </div>
        </div>
        <div class="col-md-3 col-6">
          <div class="p-3 bg-white rounded-4 shadow-sm">
            <i class="bi bi-shield-check fs-1 text-success"></i>
            <h6 class="mt-2 fw-bold">Safety Tested</h6>
            <small>Non-toxic toys</small>
          </div>
        </div>
        <div class="col-md-3 col-6">
          <div class="p-3 bg-white rounded-4 shadow-sm">
            <i class="bi bi-arrow-repeat fs-1 text-primary"></i>
            <h6 class="mt-2 fw-bold">30-Day Returns</h6>
            <small>Hassle free</small>
          </div>
        </div>
        <div class="col-md-3 col-6">
          <div class="p-3 bg-white rounded-4 shadow-sm">
            <i class="bi bi-gift fs-1 text-danger"></i>
            <h6 class="mt-2 fw-bold">Gift Wrapping</h6>
            <small>Free surprise note</small>
          </div>
        </div>
      </div>
    </div>

    <!-- BESTSELLING PRODUCTS SECTION with VIEW DETAILS BUTTONS -->
    <div class="container my-5" id="featured">
      <h2 class="text-center mb-4 fw-bold" data-aos="fade-up">🌟 Bestselling Toys 🌟</h2>
      <div class="row g-4" id="homeProducts"></div>
      <div class="text-center mt-4">
        <a href="products.php" class="btn btn-outline-kid btn-lg px-5">View All Toys 🧸</a>
      </div>
    </div>


    <!-- CATEGORY SECTION -->
    <div class="container my-5" data-aos="fade-up">
      <h2 class="text-center mb-4 fw-bold">🎯 Shop by Category</h2>

      <div class="row g-4 text-center" id="categoryList"></div>
    </div>

    <!-- DEAL OF THE DAY -->
    <div class="container my-5" data-aos="flip-left">
      <div class="row bg-white rounded-5 shadow-lg overflow-hidden align-items-center">
        <div class="col-md-6 p-4 text-center">
          <span class="badge bg-danger px-3 py-2 rounded-pill mb-2">🔥 Limited Time Offer</span>
          <h2 class="fw-bold">Deal of the Day!</h2>
          <h3 class="sparkle-text">Dino Robot Builder</h3>
          <p class="fs-2"><del class="text-muted fs-5">₹599</del> <strong class="price">₹549</strong></p>
          <p>50+ pieces, transforms into T-Rex! Hours of creative fun.</p>
          <!-- <button class="btn btn-kid btn-lg"
            onclick="addToCart(5, 'Dino Robot Builder', 34.99, 'https://placehold.co/400x400/ffcc99/cc6633?text=🦖+DinoBot')">Grab
            Now </button> -->

          <button class="btn btn-kid btn-lg">Grab Now </button>
        </div>
        <div class="col-md-6 p-0">
          <img src="assets/img/dino.jpg" class="w-100" style="height: 325px; object-fit: cover; cursor: pointer;"
            onclick="viewDetails(5)">
        </div>
      </div>
    </div>

    <!-- CUSTOMER TESTIMONIALS -->
    <div class="container my-5" data-aos="fade-up">
      <h2 class="text-center mb-4 fw-bold">💬 Happy Little Customers</h2>
      <div class="row">

        <div class="col-md-4">
          <div class="testimonial-card">
            <img src="assets/img/icons/user.png" class="testimonial-img" alt="customer">
            <h6>Priya, mom of Aarav</h6>
            <div class="rating mb-2">
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
            </div>
            <p>"My son absolutely loves the elephant plush toy! The quality is amazing and delivery was super fast."</p>
          </div>
        </div>

        <div class="col-md-4">
          <div class="testimonial-card">
            <img src="assets/img/icons/user.png" class="testimonial-img" alt="customer">
            <h6>Rahul, dad of Anaya</h6>
            <div class="rating mb-2">
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-half"></i>
            </div>
            <p>"The wooden building blocks are fantastic. My daughter enjoys playing and learning with them every day!"
            </p>
          </div>
        </div>

        <div class="col-md-4">
          <div class="testimonial-card">
            <img src="assets/img/icons/user.png" class="testimonial-img" alt="customer">
            <h6>Meera, grandmother</h6>
            <div class="rating mb-2">
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
            </div>
            <p>"The art and craft kit was a huge hit with my grandchildren. So many creative activities in one box!"</p>
          </div>
        </div>

      </div>
    </div>

    <!-- BLOG / TIPS SECTION -->
    <div class="container my-5" data-aos="fade-up">
      <h2 class="text-center mb-4 fw-bold">📖 Parenting & Play Tips</h2>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body">
              <i class="bi bi-stars fs-1 text-warning"></i>
              <h5 class="mt-2">Benefits of Imaginative Play</h5>
              <p>Encourage creativity with blocks and dolls that build problem-solving skills naturally.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body">
              <i class="bi bi-palette fs-1 text-warning"></i>
              <h5 class="mt-2">Art for Emotional Growth</h5>
              <p>Drawing and crafting help children express feelings and build fine motor skills. Our art kits are
                perfect!</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body">
              <i class="bi bi-people fs-1 text-warning"></i>
              <h5 class="mt-2">Family Game Night</h5>
              <p>Puzzles and board games strengthen family bonds. Try our memory match game today!</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- NEWSLETTER SIGNUP SECTION -->
    <div class="container my-5" data-aos="zoom-in">
      <div class="newsletter-section text-center">
        <i class="bi bi-envelope-paper fs-1 text-dark"></i>
        <h3 class="fw-bold mt-2">Join the KidsZone Club!</h3>
        <p>Get 10% off your first order + exclusive deals, coloring pages, and early access to sales.</p>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <div class="input-group">
              <input type="email" class="form-control form-control-lg rounded-pill me-2" placeholder="Enter your email"
                id="newsletterEmail" style="border-radius: 60px;">
              <button class="btn btn-kid btn-lg rounded-pill px-4" onclick="subscribeNewsletter()">Subscribe 🎈</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- BRAND / PARTNER LOGOS -->
    <div class="container my-4 text-center" data-aos="fade-up">
      <p class="text-muted">Trusted by happy families & loved by kids</p>
      <div class="d-flex justify-content-center gap-4 flex-wrap">
        <span class="fw-bold fs-5 text-secondary">🌟 ToySafe Certified</span>
        <span class="fw-bold fs-5 text-secondary">🌈 Eco-Friendly Materials</span>
        <span class="fw-bold fs-5 text-secondary">🏆 Award Winning Toys</span>
      </div>
    </div>
  </main>

  <!-- FOOTER -->
  <footer class="text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5><i class="bi bi-balloon-heart-fill"></i> KidsZone</h5>
          <p>Where imagination grows! Safe, fun, educational toys for ages 0-10.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <p><a href="about.php" class="text-decoration-none text-dark">About Us</a> | <a href="products.php"
              class="text-decoration-none text-dark">Shop</a> | <a href="cart.php"
              class="text-decoration-none text-dark">Cart</a></p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Follow the Fun</h5>
          <i class="bi bi-instagram fs-3 mx-2"></i>
          <i class="bi bi-facebook fs-3 mx-2"></i>
          <i class="bi bi-youtube fs-3 mx-2"></i>
        </div>
      </div>
      <hr class="bg-dark">
      <p class="mb-0">🌟 KidsZone — Where imagination grows! 🌟 <br>© 2025 Magical Toy Store — Safe, Fun, Creative</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 800, once: true });

let cart = <?php echo isset($_SESSION['user_id']) ? '[]' : "JSON.parse(localStorage.getItem('kidsCart')) || []"; ?>;
    /* =========================
       CART BADGE
    ========================= */
    async function updateCartBadge() {

  let badge = document.getElementById('cartCountNav');

  <?php if(isset($_SESSION['user_id'])): ?>

    // LOGGED IN USER
    try {

      let response = await fetch(
        'api/cart_count.php'
      );

      let data = await response.json();

      badge.innerText = data.count;

    } catch(error) {

      console.log(error);

    }

  <?php else: ?>

    // GUEST USER
    let total = cart.reduce(
      (s, i) => s + i.qty,
      0
    );

    badge.innerText = total;

  <?php endif; ?>

}

    /* =========================
       SAVE CART
    ========================= */
    function saveCart() {

  <?php if(!isset($_SESSION['user_id'])): ?>

    localStorage.setItem(
      'kidsCart',
      JSON.stringify(cart)
    );

  <?php endif; ?>

  updateCartBadge();
}

    /* =========================
       SAFE STRING (IMPORTANT FIX)
       prevents breaking onclick with quotes
    ========================= */
    function safeStr(str) {
      return String(str).replace(/'/g, "\\'");
    }

    /* =========================
       ADD TO CART
    ========================= */
    

    window.addToCart = async (
  id,
  name,
  price,
  img,
  stock
) => {

  if(stock <= 0){

    showToast("Out of stock");

    return;
  }

  <?php if(isset($_SESSION['user_id'])): ?>

    // DATABASE CART

    try {

      let response = await fetch(
        'api/add_to_cart.php',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            product_id: id,
            qty: 1
          })
        }
      );

      let data = await response.json();

      if(data.status === 'success'){

        showToast(`✨ ${name} added to cart!`);

        updateCartBadge();

      } else {

        showToast(data.message);

      }

    } catch(error){

      console.log(error);

      showToast("Server error");

    }

  <?php else: ?>

    // LOCAL STORAGE CART

    let existing = cart.find(
      i => i.id === id
    );

    if(existing){

      if(existing.qty >= stock){

        showToast(
          `Only ${stock} items available`
        );

        return;
      }

      existing.qty++;

    } else {

      cart.push({
        id,
        name,
        price,
        img,
        qty: 1
      });

    }

    saveCart();

    showToast(`✨ ${name} added to cart!`);

  <?php endif; ?>

};

    function showToast(message) {

      const msg = document.createElement('div');

      msg.className =
        'position-fixed bottom-0 end-0 p-3 bg-success text-white rounded-4 m-3';

      msg.style.zIndex = '9999';

      msg.innerHTML = message;

      document.body.appendChild(msg);

      setTimeout(() => {

        msg.remove();

      }, 2000);
    }

    /* =========================
       VIEW DETAILS
    ========================= */
    window.viewDetails = (id) => {
      localStorage.setItem('selectedProductId', id);
      window.location.href = `products_details.php?id=${id}`;
    };

    /* =========================
       STAR RATING
    ========================= */
    function renderStars(rating = 5) {
      let stars = '';
      for (let i = 1; i <= 5; i++) {
        stars += i <= rating
          ? '<i class="bi bi-star-fill"></i>'
          : '<i class="bi bi-star"></i>';
      }
      return stars;
    }

    /* =========================
       LOAD HOME PRODUCTS
    ========================= */
    async function loadHomeProducts() {
      try {
        let res = await fetch('api/products.php?category=all');
        let data = await res.json();

        let products = data.slice(0, 4);

        let html = products.map(p => `
      <div class="col-md-6 col-lg-3" data-aos="zoom-in">

        <div class="card card-hover h-100">

          <img src="${p.image}"
               class="product-img"
               style="cursor:pointer"
               onclick="viewDetails(${p.id})">

          <div class="card-body text-center">

            <h5 class="fw-bold"
                style="cursor:pointer"
                onclick="viewDetails(${p.id})">
              ${p.name}
            </h5>

            <div class="rating mb-2">
              ${renderStars(p.rating || 5)}
            </div>

            <div class="d-flex justify-content-between align-items-center mb-3">

  <p class="price mb-0">
    ₹${p.price}
  </p>

  ${Number(p.stock || 0) === 0
            ? `
      <span class="badge bg-danger">
        Out of Stock
      </span>
    `
            : Number(p.stock) <= 5
              ? `
      <span class="badge bg-danger">
        Only ${p.stock} left
      </span>
    `
              : `
      <span class="badge bg-success">
        In Stock
      </span>
    `
          }

</div>

            <div class="d-flex gap-2">

              <button
                    class="btn btn-kid flex-grow-1"
                    ${Number(p.stock || 0) === 0 ? 'disabled' : ''}
                                  onclick="addToCart(
                    ${p.id},
                    '${safeStr(p.name)}',
                    ${p.price},
                    '${p.image}',
                    ${p.stock || 0}
                  )">
                  <i class="bi bi-cart-plus"></i>
                  ${Number(p.stock || 0) === 0 ? 'Sold Out' : 'Add'}
              </button>

              <button class="btn btn-details"
                onclick="viewDetails(${p.id})">
                <i class="bi bi-eye"></i>
              </button>

            </div>

          </div>

        </div>

      </div>
    `).join('');

        document.getElementById("homeProducts").innerHTML = html;

      } catch (err) {
        console.log("Product API Error:", err);
      }
    }

    /* =========================
       LOAD CATEGORIES (NEW)
       FROM api/categories.php
    ========================= */
    async function loadCategories() {
      try {
        let res = await fetch('api/category.php');
        let data = await res.json();

        // ✅ DEFAULT CATEGORY (always shown)
        let defaultCategories = [
          {
            id: "sale",
            name: "On Sale",
            icon: "on_sale.png",
          }
        ];

        // merge API + default
        let allCategories = [...data, ...defaultCategories];

        let html = allCategories.map(c => `
      <div class="col-6 col-md-3 col-lg-2">
        <div class="category-card" onclick="goToCategory('${c.id}')">

          <img src="admin/assets/img/category/${c.icon}" alt="${c.name}">

          <h6 class="mt-2 fw-bold">${c.name}</h6>

          <small>${c.count ? c.count + ' Items' : 'Explore'}</small>

        </div>
      </div>
    `).join('');

        document.getElementById("categoryList").innerHTML = html;

      } catch (err) {
        console.log("Category API Error:", err);
      }
    }

    /* =========================
       CATEGORY CLICK
    ========================= */
    window.goToCategory = (id) => {
      window.location.href = `products.php?category=${id}`;
    };

    /* =========================
       INIT
    ========================= */
    updateCartBadge();
    loadHomeProducts();
    loadCategories();

  </script>
</body>

</html>