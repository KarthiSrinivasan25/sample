<?php
session_start();
include 'admin/config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = $_POST['password'];

  // check user
  $sql = "SELECT * FROM users WHERE email='$email' LIMIT 1";
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) == 1) {

    $user = mysqli_fetch_assoc($result);

    // verify password (because signup uses password_hash)
    if (password_verify($password, $user['password'])) {

      // create session
      $_SESSION['user_id'] = $user['id'];
      $_SESSION['user_name'] = $user['full_name'];
      $_SESSION['user_email'] = $user['email'];

      $redirect =
        isset($_GET['redirect'])
        ? $_GET['redirect']
        : 'index.php';

      echo "

<script>

alert('Login successful! Welcome {$user['full_name']}');

let cart = JSON.parse(
    localStorage.getItem('kidsCart')
) || [];

if(cart.length > 0){

    fetch('api/sync_cart.php', {

        method: 'POST',

        headers: {
            'Content-Type': 'application/json'
        },

        body: JSON.stringify(cart)

    })
    .then(res => res.json())
    .then(data => {

        console.log(data);

        // clear localStorage cart
        localStorage.removeItem('kidsCart');

        // redirect
        window.location.href = '$redirect';

    });

} else {

    window.location.href = '$redirect';

}

</script>

";
exit();

    } else {
      echo "<script>
                    alert('Incorrect password!');
                    window.location.href='login.php';
                  </script>";
      exit();
    }

  } else {
    echo "<script>
                alert('Email not found!');
                window.location.href='login.php';
              </script>";
    exit();
  }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KidsZone - Login | Welcome Back</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
    rel="stylesheet">
  <!-- AOS Animation -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <link href="assets/css/styles.css" rel="stylesheet">
  <style>
    
    /* Animated background elements */
    body::before {
      content: "🧸 🎈 🦄 🎨 🚂 🧩";
      position: fixed;
      bottom: 20px;
      left: 0;
      right: 0;
      font-size: 60px;
      opacity: 0.05;
      text-align: center;
      pointer-events: none;
      z-index: 0;
    }

  </style>
</head>

<body>

  <!-- Floating decorative emojis -->
  <div class="floating-emoji" style="top: 10%; left: 5%; animation-delay: 0s;">🧸</div>
  <div class="floating-emoji" style="top: 70%; right: 3%; animation-delay: 1s; font-size: 2.5rem;">🦄</div>
  <div class="floating-emoji" style="bottom: 15%; left: 8%; animation-delay: 2s;">🎨</div>
  <div class="floating-emoji" style="top: 40%; right: 8%; animation-delay: 0.5s;">🚂</div>

  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><i class="bi bi-balloon-heart-fill"></i> KidsZone</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">
          <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-house-door"></i> Home</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php"><i class="bi bi-heart"></i> About</a></li>
          <li class="nav-item"><a class="nav-link" href="products.php"><i class="bi bi-grid-3x3-gap-fill"></i> Shop</a>
          </li>
          <li class="nav-item"><a class="nav-link position-relative" href="cart.php"><i class="bi bi-cart3"></i> Cart
              <span id="cartCountNav" class="cart-badge">0</span></a></li>
          <li class="nav-item"><a class="nav-link active" href="contact.php"><i class="bi bi-telephone"></i> Contact Us</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i>

              <?php if (isset($_SESSION['user_name'])): ?>
                <?= $_SESSION['user_name']; ?>
              <?php else: ?>
                Account
              <?php endif; ?>

            </a>

            <ul class="dropdown-menu dropdown-menu-end">

              <?php if (!isset($_SESSION['user_name'])): ?>

                <li>
                  <a class="dropdown-item" href="login.php">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                  </a>
                </li>

                <li>
                  <a class="dropdown-item" href="signup.php">
                    <i class="bi bi-person-plus"></i> Signup
                  </a>
                </li>

              <?php else: ?>

                <li>
                  <span class="dropdown-item-text">
                    👋 Hello,
                    <?= $_SESSION['user_name']; ?>
                  </span>
                </li>

                <li>
                  <hr class="dropdown-divider">
                </li>

                <li>
                  <a class="dropdown-item text-danger" href="logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                  </a>
                </li>

              <?php endif; ?>

            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="login-wrapper">
    <div class="login-card" data-aos="zoom-in" data-aos-duration="600">
      <div class="login-header">
        <div class="login-icon">
          <i class="bi bi-emoji-wink"></i>
        </div>
        <h2 class="fw-bold mt-2">Welcome Back! 🎈</h2>
        <p class="text-muted">Sign in to continue your magical journey</p>
      </div>

      <form id="loginForm" action="login.php" method="POST">
        <!-- Email Field with Icon -->
        <div class="mb-3">
          <label class="form-label fw-bold">Email Address</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
            <input type="email" class="form-control" placeholder="hello@kidszone.com" id="loginEmail" name="email"
              required>
          </div>
        </div>

        <!-- Password Field with Icon -->
        <div class="mb-2">
          <label class="form-label fw-bold">Password</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
            <input type="password" class="form-control" placeholder="••••••••" id="loginPassword" name="password"
              required>
          </div>
        </div>

        <!-- Forgot Password -->
        <div class="forgot-password">
          <a href="#" onclick="forgotPassword()">Forgot password?</a>
        </div>



        <!-- Login Button -->
        <button type="submit" class="btn btn-kid">
          <i class="bi bi-box-arrow-in-right"></i> Login
        </button>


        <!-- Register Link -->
        <div class="register-link">
          <p class="mb-0">New to KidsZone? <a href="signup.php">Create an account <i class="bi bi-arrow-right"></i></a>
          </p>
        </div>
      </form>
    </div>
  </div>

  <footer class="text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5><i class="bi bi-balloon-heart-fill"></i> KidsZone</h5>
          <p>Where imagination grows! Safe, fun, educational toys for ages 0-10.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <p><a href="about.php" class="text-decoration-none text-dark">About Us</a> | <a href="products.php"
              class="text-decoration-none text-dark">Shop</a> | <a href="cart.php"
              class="text-decoration-none text-dark">Cart</a> | <a href="contact.php"
              class="text-decoration-none text-dark">Contact</a></p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Follow the Fun</h5>
          <i class="bi bi-instagram fs-3 mx-2"></i>
          <i class="bi bi-facebook fs-3 mx-2"></i>
          <i class="bi bi-youtube fs-3 mx-2"></i>
        </div>
      </div>
      <hr class="bg-dark">
      <p class="mb-0">🌟 KidsZone — Where imagination grows! 🌟 <br>© 2025 Magical Toy Store — Safe, Fun, Creative</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 800, once: true });

    let cart = JSON.parse(localStorage.getItem('kidsCart')) || [];
    function updateCartBadge() {
      let total = cart.reduce((s, i) => s + i.qty, 0);
      let badge = document.getElementById('cartCountNav');
      if (badge) badge.innerText = total;
    }
    updateCartBadge();

  </script>
</body>

</html>