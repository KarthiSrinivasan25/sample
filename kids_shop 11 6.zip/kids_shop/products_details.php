<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KidsZone - Product Details</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap"
    rel="stylesheet">
  <link href="assets/css/styles.css" rel="stylesheet">
</head>

<body>

  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><i class="bi bi-balloon-heart-fill"></i> KidsZone</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">

          <li class="nav-item">
            <a class="nav-link " href="index.php">
              <i class="bi bi-house-door"></i> Home
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="about.php">
              <i class="bi bi-heart"></i> About
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="products.php">
              <i class="bi bi-grid-3x3-gap-fill"></i> Shop
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link position-relative" href="cart.php">
              <i class="bi bi-cart3"></i> Cart
              <span id="cartCountNav" class="cart-badge">0</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="login.php">
              <i class="bi bi-telephone"></i> Contact Us
            </a>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i>

              <?php if (isset($_SESSION['user_name'])): ?>
                <?= $_SESSION['user_name']; ?>
              <?php else: ?>
                Account
              <?php endif; ?>

            </a>

            <ul class="dropdown-menu dropdown-menu-end">

              <?php if (!isset($_SESSION['user_name'])): ?>

                <li>
                  <a class="dropdown-item" href="login.php">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                  </a>
                </li>

                <li>
                  <a class="dropdown-item" href="signup.php">
                    <i class="bi bi-person-plus"></i> Signup
                  </a>
                </li>

              <?php else: ?>

                <li>
                  <span class="dropdown-item-text">
                    👋 Hello,
                    <?= $_SESSION['user_name']; ?>
                  </span>
                </li>

                <li>
                  <hr class="dropdown-divider">
                </li>

                <li>
                  <a class="dropdown-item text-danger" href="logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                  </a>
                </li>

              <?php endif; ?>

            </ul>
          </li>

        </ul>
      </div>
    </div>
  </nav>

  <main class="container my-5">

    <div class="row g-5 align-items-start">

      <!-- Product Image -->
      <div class="col-md-6">
        <img id="productImage" src="" class="img-fluid product-detail-img w-100" alt="Product Image">
      </div>

      <!-- Product Info -->
      <div class="col-md-6">

        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php" class="text-decoration-none text-secondary">Home</a>
            </li>
            <li class="breadcrumb-item">
              <a href="products.php" class="text-decoration-none text-secondary">Shop</a>
            </li>
            <li class="breadcrumb-item active" id="breadcrumbCategory">
              Loading...
            </li>
          </ol>
        </nav>

        <!-- Product Name -->
        <h1 id="productName" class="fw-bold display-5 mb-3">
          Loading product...
        </h1>

        <!-- Rating -->
        <div class="rating mb-3 fs-4" id="productRating"></div>

        <!-- Price -->
        <p id="productPrice" class="price">₹0</p>

        <!-- Description -->
        <p id="productDesc" class="lead mb-4">
          Loading description...
        </p>

        <!-- Quantity -->
        <div class="mb-4">
          <label class="fw-bold mb-2">Quantity:</label>

          <div class="d-flex align-items-center gap-3">

            <div class="d-flex border rounded-pill overflow-hidden" style="border: 2px solid #ffd966 !important;">

              <button class="btn btn-light border-0 px-3 py-2" onclick="decreaseQty()"
                style="background: #fff5e6;">-</button>

              <input type="number" id="quantityInput" value="1" min="1" max="99"
                class="quantity-selector border-0 text-center" style="width: 70px;">

              <button class="btn btn-light border-0 px-3 py-2" onclick="increaseQty()"
                style="background: #fff5e6;">+</button>

            </div>

            <small class="fw-bold px-3 py-2 rounded-pill bg-light border" id="alreadyInCartText">
            </small>

            <span class="fw-bold" id="stockText"></span>

          </div>
        </div>

        <!-- Buttons -->
        <!-- Buttons -->
        <div class="d-flex flex-wrap gap-3 mb-4">

          <button id="addToCartBtn" class="btn btn-kid btn-lg px-5">

            <i class="bi bi-cart-plus"></i> Add to Cart

          </button>

          <button class="btn btn-outline-kid btn-lg" onclick="addToWishlist()">

            <i class="bi bi-heart"></i> Save to Wishlist

          </button>

        </div>

        <!-- Features -->
        <div class="row mt-4 pt-3">

          <div class="col-6">
            <div class="d-flex align-items-center gap-2 mb-3">
              <i class="bi bi-truck fs-4 text-warning"></i>
              <div>
                <strong>Free Shipping</strong><br>
                <small>On orders ₹999+</small>
              </div>
            </div>
          </div>

          <div class="col-6">
            <div class="d-flex align-items-center gap-2 mb-3">
              <i class="bi bi-arrow-repeat fs-4 text-success"></i>
              <div>
                <strong>30-Day Returns</strong><br>
                <small>Hassle free</small>
              </div>
            </div>
          </div>

          <div class="col-6">
            <div class="d-flex align-items-center gap-2 mb-3">
              <i class="bi bi-shield-check fs-4 text-primary"></i>
              <div>
                <strong>Safety Tested</strong><br>
                <small>Non-toxic toys</small>
              </div>
            </div>
          </div>

          <div class="col-6">
            <div class="d-flex align-items-center gap-2 mb-3">
              <i class="bi bi-gift fs-4 text-danger"></i>
              <div>
                <strong>Gift Ready</strong><br>
                <small>Free surprise note</small>
              </div>
            </div>
          </div>

        </div>

        <a href="products.php" class="btn btn-link text-decoration-none mt-2">
          <i class="bi bi-arrow-left"></i> Back to Shop
        </a>

      </div>
    </div>

    <!-- Related Products -->
    <div class="mt-5 pt-4">

      <h3 class="fw-bold mb-4">
        ✨ You May Also Like ✨
      </h3>

      <div class="row g-4" id="relatedProducts">
        <!-- JS loads here -->
      </div>

    </div>

  </main>
 <footer class="text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5><i class="bi bi-balloon-heart-fill"></i> KidsZone</h5>
          <p>Where imagination grows! Safe, fun, educational toys for ages 0-10.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <p><a href="about.php" class="text-decoration-none text-dark">About Us</a> | <a href="products.php"
              class="text-decoration-none text-dark">Shop</a> | <a href="cart.php"
              class="text-decoration-none text-dark">Cart</a></p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Follow the Fun</h5>
          <i class="bi bi-instagram fs-3 mx-2"></i>
          <i class="bi bi-facebook fs-3 mx-2"></i>
          <i class="bi bi-youtube fs-3 mx-2"></i>
        </div>
      </div>
      <hr class="bg-dark">
      <p class="mb-0">🌟 KidsZone — Where imagination grows! 🌟 <br>© 2025 Magical Toy Store — Safe, Fun, Creative</p>
    </div>
  </footer>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    let products = [];
    let product = null;

let cart =
<?php echo isset($_SESSION['user_id'])
? '[]'
: "JSON.parse(localStorage.getItem('kidsCart')) || []";
?>;

    let currentQuantity = 1;

    const productId =
      new URLSearchParams(window.location.search).get('id');

    /* =========================
       LOAD PRODUCT
    ========================= */
    async function loadProduct() {

      try {

        const res = await fetch("api/products.php?category=all");

        products = await res.json();

        product = products.find(
          p => String(p.id) === String(productId)
        );

        if (!product) {

          document.body.innerHTML = `
        <div class="container text-center mt-5">
          <h2>❌ Product Not Found</h2>

          <a href="products.php" class="btn btn-kid mt-3">
            Back to Shop
          </a>
        </div>
      `;

          return;
        }

        renderProduct();

        const stockEl = document.getElementById('stockText');

        const stock = Number(product.stock || 0);

        const addBtn = document.getElementById('addToCartBtn');

        if (stock <= 0) {

          stockEl.className = 'text-danger fw-bold';

          stockEl.innerHTML = 'Out Of Stock ✖';

          // CHANGE BUTTON
          addBtn.disabled = true;

          addBtn.innerHTML = `
    <i class="bi bi-x-circle"></i> Sold Out
  `;

         // addBtn.classList.remove('btn-kid');

          //addBtn.classList.add('btn-secondary');

        } else if (stock < 5) {

          stockEl.className = 'text-danger fw-bold';

          stockEl.innerHTML = `Only ${stock} left in stock!`;

        } else {

          stockEl.className = 'text-success fw-bold';

          stockEl.innerHTML = 'In Stock ✓';
        }

        updateAlreadyInCartUI();

        loadRelatedProducts();

        updateCartBadge();

      } catch (err) {

        console.log(err);

        document.body.innerHTML = `
      <div class="container text-center mt-5">
        <h2>⚠ Failed to load product</h2>
      </div>
    `;
      }
    }

    /* =========================
       RENDER PRODUCT
    ========================= */
    function renderProduct() {

      document.getElementById('productName').innerText =
        product.name;

      document.getElementById('productPrice').innerHTML =
        `₹${product.price}`;

      document.getElementById('productDesc').innerText =
        product.description || 'No description available';

      document.getElementById('productImage').src =
        product.image;

      document.getElementById('productRating').innerHTML =
        renderStars(product.rating || 0);

      document.getElementById('breadcrumbCategory').innerText =
        product.category_name || 'Product';
    }



    /* =========================
       STAR RENDER
    ========================= */
    function renderStars(rating = 0) {

      let stars = '';

      for (let i = 1; i <= 5; i++) {

        if (i <= rating)
          stars += '<i class="bi bi-star-fill"></i>';

        else
          stars += '<i class="bi bi-star"></i>';
      }

      return stars;
    }

    /* =========================
       QUANTITY
    ========================= */
    window.increaseQty = () => {

      const stock = Number(product.stock || 0);

      if (currentQuantity < stock) {

        currentQuantity++;

        document.getElementById('quantityInput').value =
          currentQuantity;
      }
    };

    function decreaseQty() {

      if (currentQuantity > 1) {

        currentQuantity--;

        quantityInput.value = currentQuantity;
      }
    }

    const quantityInput =
      document.getElementById('quantityInput');

    quantityInput.addEventListener('input', e => {

      currentQuantity = parseInt(e.target.value) || 1;

      if (currentQuantity < 1)
        currentQuantity = 1;

      if (currentQuantity > 99)
        currentQuantity = 99;

      e.target.value = currentQuantity;
    });

    /* =========================
       ADD TO CART
    ========================= */
    async function addToCartWithQuantity() {

  if (!product) return;

  const stock = Number(product.stock || 0);

  // CHECK STOCK
  if (currentQuantity > stock) {

    showToast(
      `❌ Only ${stock} items available`,
      'info'
    );

    return;
  }

  <?php if(isset($_SESSION['user_id'])): ?>

    // =========================
    // LOGGED IN → DATABASE CART
    // =========================

    try {

      const response = await fetch(
        'api/add_to_cart.php',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            product_id: product.id,
            qty: currentQuantity
          })
        }
      );

      const data = await response.json();

      if (data.status === 'success') {

  showToast(
    `✨ ${currentQuantity} × ${product.name} added to cart!`
  );

  updateCartBadge();

  // UPDATE CART STATUS UI
  updateAlreadyInCartUI();

} else {

        showToast(data.message, 'info');

      }

    } catch(err) {

      console.log(err);

      showToast('Cart error', 'info');

    }

  <?php else: ?>

    // =========================
    // GUEST → LOCAL STORAGE
    // =========================

    let existing = cart.find(
      i => String(i.id) === String(product.id)
    );

    const alreadyInCart =
      existing ? Number(existing.qty) : 0;

    const totalWanted =
      alreadyInCart + Number(currentQuantity);

    if (totalWanted > stock) {

      showToast(
        `❌ Only ${stock} items available`,
        'info'
      );

      return;
    }

    if (existing) {

      existing.qty += Number(currentQuantity);

    } else {

      cart.push({
        id: product.id,
        name: product.name,
        price: Number(product.price || 0),
        img: product.image,
        qty: Number(currentQuantity)
      });

    }

    saveCart();

    updateAlreadyInCartUI();

    showToast(
      `✨ ${currentQuantity} × ${product.name} added to cart!`
    );

  <?php endif; ?>

  // RESET
  currentQuantity = 1;

  document.getElementById('quantityInput').value = 1;
}


    document.getElementById('addToCartBtn')
      .addEventListener('click', addToCartWithQuantity);

    /* =========================
       CART STORAGE
    ========================= */
    function saveCart() {

  <?php if(!isset($_SESSION['user_id'])): ?>

    localStorage.setItem(
      'kidsCart',
      JSON.stringify(cart)
    );

  <?php endif; ?>

  updateCartBadge();
}

    async function updateCartBadge() {

  const badge =
    document.getElementById('cartCountNav');

  <?php if(isset($_SESSION['user_id'])): ?>

    try {

      let response = await fetch(
        'api/cart_count.php'
      );

      let data = await response.json();

      badge.innerText = data.count;

    } catch(error){

      console.log(error);

    }

  <?php else: ?>

    const total = cart.reduce(
      (sum, item) => sum + item.qty,
      0
    );

    badge.innerText = total;

  <?php endif; ?>

}

    /* =========================
       CART STATUS UI
    ========================= */
    async function updateAlreadyInCartUI() {

  <?php if(isset($_SESSION['user_id'])): ?>

    try {

      let response = await fetch(
        `api/cart_product_qty.php?product_id=${product.id}`
      );

      let data = await response.json();

      document.getElementById('alreadyInCartText').innerText =
        data.qty > 0
          ? `🛒 Already in cart: ${data.qty}`
          : `🛒 Not added yet`;

    } catch(error){

      console.log(error);

    }

  <?php else: ?>

    const existing = cart.find(
      i => String(i.id) === String(product.id)
    );

    document.getElementById('alreadyInCartText').innerText =
      existing
        ? `🛒 Already in cart: ${existing.qty}`
        : `🛒 Not added yet`;

  <?php endif; ?>

}

    /* =========================
       RELATED PRODUCTS
    ========================= */
    function loadRelatedProducts() {

      const related = products
        .filter(p =>

          String(p.category_id) ===
          String(product.category_id)

          &&

          String(p.id) !== String(product.id)
        )
        .slice(0, 4);

      const container =
        document.getElementById('relatedProducts');

      if (!related.length) {

        container.innerHTML = `
      <div class="col-12 text-center text-muted">
        No related products yet 🎈
      </div>
    `;

        return;
      }

      container.innerHTML = related.map(p => `

    <div class="col-md-6 col-lg-3">

      <div class="card h-100 product-card"
        data-id="${p.id}"
        style="
          border-radius:28px;
          overflow:hidden;
          cursor:pointer;
          border:none;
          transition:0.3s;
          box-shadow:0 10px 20px rgba(0,0,0,0.08);
        ">

        <img src="${p.image}"
          style="
            height:200px;
            object-fit:cover;
            padding:15px;
            background:#fff2e2;
          ">

        <div class="card-body text-center">

          <h6 class="fw-bold">${p.name}</h6>

          <div class="small mb-2">
            ${renderStars(p.rating || 0)}
          </div>

          <p class="text-danger fw-bold">
            ₹${p.price}
          </p>

          ${Number(p.stock || 0) <= 0
  ? `
    <button
      class="btn btn-sm btn-kid w-100"
      disabled>
      Sold Out
    </button>
  `
  : `
    <button
      class="btn btn-sm btn-kid w-100 quick-add"
      data-id="${p.id}">
      Quick Add
    </button>
  `
}

        </div>
      </div>
    </div>

  `).join('');
    }

    /* =========================
       QUICK ADD
    ========================= */
    async function quickAdd(id) {

  const item = products.find(
    p => String(p.id) === String(id)
  );

  if (!item) return;

  <?php if(isset($_SESSION['user_id'])): ?>

    try {

      let response = await fetch(
        'api/add_to_cart.php',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            product_id: item.id,
            qty: 1
          })
        }
      );

      let data = await response.json();

      if(data.status === 'success'){

  showToast(`✨ ${item.name} added to cart!`);

  updateCartBadge();

  // UPDATE UI
  updateAlreadyInCartUI();

}

    } catch(error){

      console.log(error);

    }

  <?php else: ?>

    let existing = cart.find(
      i => String(i.id) === String(id)
    );

    if (existing)
      existing.qty++;

    else
      cart.push({
        id: item.id,
        name: item.name,
        price: item.price,
        img: item.image,
        qty: 1
      });

    saveCart();

    showToast(`✨ ${item.name} added to cart!`);

  <?php endif; ?>

}

    /* =========================
       WISHLIST
    ========================= */
    function addToWishlist() {

      showToast(
        `💖 ${product.name} saved to wishlist!`,
        'info'
      );
    }

    /* =========================
       TOAST
    ========================= */
    function showToast(message, type = "success") {

      const toast = document.createElement('div');

      toast.className =
        'position-fixed bottom-0 end-0 p-3 text-white rounded-4 m-3';

      toast.style.zIndex = '9999';

      toast.style.background =
        type === 'info'
          ? '#0dcaf0'
          : '#198754';

      toast.innerHTML = message;

      document.body.appendChild(toast);

      setTimeout(() => toast.remove(), 2000);
    }

    /* =========================
       EVENTS
    ========================= */
    document.addEventListener('click', e => {

      const quickBtn = e.target.closest('.quick-add');

      if (quickBtn) {

        e.stopPropagation();

        quickAdd(quickBtn.dataset.id);

        return;
      }

      const card = e.target.closest('.product-card');

      if (card) {

        window.location.href =
          `products_details.php?id=${card.dataset.id}`;
      }
    });

    /* =========================
       INIT
    ========================= */
    loadProduct();
  </script>
</body>

</html>

<!-- 
const stockEl = document.getElementById('stockText');

const stock = Number(product.stock || 0);

const addBtn = document.getElementById('addToCartBtn');

if (stock <= 0) {

  stockEl.className = 'text-danger fw-bold';

  stockEl.innerHTML = 'Out Of Stock ✖';

  // CHANGE BUTTON
  addBtn.disabled = true;

  addBtn.innerHTML = `
    <i class="bi bi-x-circle"></i> Sold Out
  `;

  addBtn.classList.remove('btn-kid');

  addBtn.classList.add('btn-secondary');

} else if (stock < 5) {

  stockEl.className = 'text-danger fw-bold';

  stockEl.innerHTML = `Only ${stock} left in stock!`;

} else {

  stockEl.className = 'text-success fw-bold';

  stockEl.innerHTML = 'In Stock ✓';
} -->