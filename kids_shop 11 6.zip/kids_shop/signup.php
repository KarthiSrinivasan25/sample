<?php

include 'admin/config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fullName = mysqli_real_escape_string($conn, $_POST['fullName']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Check if email already exists
    $checkEmail = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $checkEmail);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>
                alert('Email already registered!');
                window.location.href='signup.php';
              </script>";
        exit();
    }

    // Insert user
    $sql = "INSERT INTO users(full_name, email, password)
            VALUES('$fullName', '$email', '$hashedPassword')";

    if (mysqli_query($conn, $sql)) {

        echo "<script>
                alert('Account created successfully!');
                window.location.href='login.php';
              </script>";

    } else {

        echo "Error: " . mysqli_error($conn);

    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KidsZone - Sign Up | Join the Magic</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- AOS Animation -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <link href="assets/css/styles.css" rel="stylesheet">
  <style>
    
    
    /* Animated background elements */
    body::before {
      content: "🎈 🎨 🚂 🧸 🦄 🧩";
      position: fixed;
      bottom: 20px;
      left: 0;
      right: 0;
      font-size: 60px;
      opacity: 0.05;
      text-align: center;
      pointer-events: none;
      z-index: 0;
    }
    
  
  </style>
</head>
<body>

  <!-- Floating decorative emojis -->
  <div class="floating-emoji" style="top: 10%; left: 3%; animation-delay: 0s;">🎈</div>
  <div class="floating-emoji" style="top: 75%; right: 5%; animation-delay: 1.2s; font-size: 2.5rem;">🧸</div>
  <div class="floating-emoji" style="bottom: 20%; left: 10%; animation-delay: 2s;">🦄</div>
  <div class="floating-emoji" style="top: 45%; right: 12%; animation-delay: 0.7s;">🎨</div>

  <nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
      <a class="navbar-brand" href="index.php"><i class="bi bi-balloon-heart-fill"></i> KidsZone</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">
          <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-house-door"></i> Home</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php"><i class="bi bi-heart"></i> About</a></li>
          <li class="nav-item"><a class="nav-link" href="products.php"><i class="bi bi-grid-3x3-gap-fill"></i> Shop</a></li>
          <li class="nav-item"><a class="nav-link position-relative" href="cart.php"><i class="bi bi-cart3"></i> Cart <span id="cartCountNav" class="cart-badge">0</span></a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php"><i class="bi bi-telephone"></i> Contact Us</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i>

              <?php if (isset($_SESSION['user_name'])): ?>
                <?= $_SESSION['user_name']; ?>
              <?php else: ?>
                Account
              <?php endif; ?>

            </a>

            <ul class="dropdown-menu dropdown-menu-end">

              <?php if (!isset($_SESSION['user_name'])): ?>

                <li>
                  <a class="dropdown-item" href="login.php">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                  </a>
                </li>

                <li>
                  <a class="dropdown-item" href="signup.php">
                    <i class="bi bi-person-plus"></i> Signup
                  </a>
                </li>

              <?php else: ?>

                <li>
                  <span class="dropdown-item-text">
                    👋 Hello,
                    <?= $_SESSION['user_name']; ?>
                  </span>
                </li>

                <li>
                  <hr class="dropdown-divider">
                </li>

                <li>
                  <a class="dropdown-item text-danger" href="logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                  </a>
                </li>

              <?php endif; ?>

            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="signup-wrapper">
    <div class="signup-card" data-aos="zoom-in" data-aos-duration="600">
      <div class="signup-header">
        <div class="signup-icon">
          <i class="bi bi-balloon-heart-fill"></i>
        </div>
        <h2 class="fw-bold mt-2">Create an Account! 🎈</h2>
        <p class="text-muted">Join our magical community and get 10% off your first order</p>
      </div>
      
      <form id="signupForm" action="signup.php" method="POST">
        <!-- Full Name -->
        <div class="mb-3">
          <label class="form-label fw-bold">Full Name</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
            <input type="text" class="form-control" placeholder="Enter your full name" id="fullName" name="fullName" required>
          </div>
        </div>
        
        <!-- Email Address -->
        <div class="mb-3">
          <label class="form-label fw-bold">Email Address</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
            <input type="email" class="form-control" placeholder="parent@example.com" id="signupEmail" name="email" required>
          </div>
          <div class="invalid-feedback" id="emailError" style="display: none;">Please enter a valid email address</div>
        </div>
        
        <!-- Password -->
        <div class="mb-2">
          <label class="form-label fw-bold">Password</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
            <input type="password" class="form-control" placeholder="Create a strong password" id="signupPassword" name="password" required>
          </div>
          <div class="password-strength">
            <div class="strength-bar" id="strengthBar"></div>
            <small id="strengthText" class="text-muted">Password strength: </small>
          </div>
        </div>
        
        <!-- Confirm Password -->
        <div class="mb-3">
          <label class="form-label fw-bold">Confirm Password</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
            <input type="password" class="form-control" placeholder="Confirm your password" id="confirmPassword" required>
          </div>
          <div class="invalid-feedback" id="passwordMatchError" style="display: none;">Passwords do not match</div>
        </div>
        
        <!-- Sign Up Button -->
        <button type="submit" class="btn btn-kid">
          <i class="bi bi-person-plus"></i> Create Account
        </button>
       
        <!-- Login Link -->
        <div class="login-link">
          <p class="mb-0">Already have an account? <a href="login.php">Log in <i class="bi bi-arrow-right"></i></a></p>
        </div>
      </form>
    </div>
  </div>

  <footer class="text-center">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5><i class="bi bi-balloon-heart-fill"></i> KidsZone</h5>
          <p>Where imagination grows! Safe, fun, educational toys for ages 0-10.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <p><a href="about.php" class="text-decoration-none text-dark">About Us</a> | <a href="products.php" class="text-decoration-none text-dark">Shop</a> | <a href="cart.php" class="text-decoration-none text-dark">Cart</a> | <a href="contact.php" class="text-decoration-none text-dark">Contact</a></p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Follow the Fun</h5>
          <i class="bi bi-instagram fs-3 mx-2"></i>
          <i class="bi bi-facebook fs-3 mx-2"></i>
          <i class="bi bi-youtube fs-3 mx-2"></i>
        </div>
      </div>
      <hr class="bg-dark">
      <p class="mb-0">🌟 KidsZone — Where imagination grows! 🌟 <br>© 2025 Magical Toy Store — Safe, Fun, Creative</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
AOS.init({ duration: 800, once: true });

/* ---------------- CART ---------------- */
let cart = JSON.parse(localStorage.getItem('kidsCart')) || [];

function updateCartBadge() {
  let total = cart.reduce((s, i) => s + i.qty, 0);
  let badge = document.getElementById('cartCountNav');
  if (badge) badge.innerText = total;
}
updateCartBadge();

/* ---------------- ELEMENTS ---------------- */
const form = document.getElementById('signupForm');
const passwordInput = document.getElementById('signupPassword');
const confirmInput = document.getElementById('confirmPassword');
const emailInput = document.getElementById('signupEmail');

const strengthBar = document.getElementById('strengthBar');
const strengthText = document.getElementById('strengthText');

/* ---------------- EMAIL VALIDATION ---------------- */
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

/* ---------------- PASSWORD STRENGTH ---------------- */
function checkPasswordStrength(password) {
  let strength = 0;

  if (password.length >= 8) strength++;
  if (/[a-z]/.test(password)) strength++;
  if (/[A-Z]/.test(password)) strength++;
  if (/[0-9]/.test(password)) strength++;
  if (/[$@#&!]/.test(password)) strength++;

  const colors = ['#dc3545', '#dc3545', '#ffc107', '#ffc107', '#198754', '#198754'];
  const texts = ['Very Weak', 'Weak', 'Weak', 'Medium', 'Strong', 'Very Strong'];
  const widths = ['10%', '20%', '40%', '60%', '80%', '100%'];

  strengthBar.style.backgroundColor = colors[strength] || '#dc3545';
  strengthBar.style.width = widths[strength] || '10%';
  strengthText.innerHTML = `Password strength: <strong>${texts[strength] || 'Very Weak'}</strong>`;

  return strength >= 3;
}

/* ---------------- PASSWORD MATCH ---------------- */
function checkPasswordMatch() {
  const match = passwordInput.value === confirmInput.value;
  const errorDiv = document.getElementById('passwordMatchError');

  if (confirmInput.value.length === 0) return true;

  if (!match) {
    errorDiv.style.display = 'block';
    confirmInput.classList.add('is-invalid');
    confirmInput.classList.remove('is-valid');
  } else {
    errorDiv.style.display = 'none';
    confirmInput.classList.remove('is-invalid');
    confirmInput.classList.add('is-valid');
  }

  return match;
}

/* ---------------- LIVE PASSWORD ---------------- */
passwordInput.addEventListener('input', () => {
  checkPasswordStrength(passwordInput.value);
  checkPasswordMatch();
});

/* ---------------- CONFIRM PASSWORD ---------------- */
confirmInput.addEventListener('input', checkPasswordMatch);

/* ---------------- LIVE EMAIL ---------------- */
emailInput.addEventListener('input', function () {
  if (validateEmail(this.value)) {
    this.classList.add('is-valid');
    this.classList.remove('is-invalid');
    document.getElementById('emailError').style.display = 'none';
  } else {
    this.classList.remove('is-valid');
    if (this.value.length > 0) this.classList.add('is-invalid');
  }
});

/* ---------------- FORM SUBMIT VALIDATION ---------------- */
form.addEventListener('submit', function (e) {
  e.preventDefault();

  const fullName = document.getElementById('fullName');

  let isValid = true;

  // Name check
  if (fullName.value.trim().length < 3) {
    fullName.classList.add('is-invalid');
    isValid = false;
  } else {
    fullName.classList.remove('is-invalid');
    fullName.classList.add('is-valid');
  }

  // Email check
  if (!validateEmail(emailInput.value)) {
    emailInput.classList.add('is-invalid');
    document.getElementById('emailError').style.display = 'block';
    isValid = false;
  }

  // Password strength
  if (!checkPasswordStrength(passwordInput.value)) {
    alert("⚠️ Password too weak. Use uppercase, numbers & symbols.");
    isValid = false;
  }

  // Password match
  if (!checkPasswordMatch()) {
    isValid = false;
  }

  // FINAL SUBMIT
  if (isValid) {
    form.submit(); // sends to PHP backend
  }
});
</script>
</body>
</html>