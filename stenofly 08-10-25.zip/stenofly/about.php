<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'includes/head.php'; ?>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-title centred page-breadcrumb ">
        <div class="container">
            <div class="content-box">
                <h1>About Us</h1>
                <div class="bread-crumb clearfix">
                    <span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage"
                            title="Go to Stenofly." href="index.php" class="home"><span property="name">Stenofly</span></a>

                    </span> &gt; <span property="itemListElement" typeof="ListItem"><span property="name"
                            class="post post-page current-item">About Us</span>

                    </span>
                </div>
            </div>
        </div>
    </section>


    <section class="about-section sec-pad">
        <div class="anim-icon  d-none d-xl-block">
            <div class="icon icon-1 float-bob-x"></div>
            <div class="icon icon-3"></div>
        </div>
        <div class="container">
            <div class="row d-flex justify-content-between align-items-center">
                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <div class="content-box ms-lg-5">
                        <div class="sec-title style-two">
                            <h5>About Us
                            </h5>
                            <h1 class="about_us">Welcome to Stenofly Kindergarten
                            </h1>
                        </div>

                        <div class="bold-text mb-2 text-secondary">
                            <p>
                                At Stenofly Kindergarten, we believe that every
                                child is born with endless potential, and our mission is to nurture that spark through
                                joyful learning, creativity, and care. We provide a warm, safe, and stimulating
                                environment
                                where children aged 2 to 6 can grow socially, emotionally, physically, and
                                intellectually.
                            </p>
                            <p>Our play-based and inquiry-driven curriculum encourages curiosity, imagination, and
                                hands-on exploration. From storytelling and art to science experiments and outdoor play,
                                every day at Stenofly is a new adventure in learning.
                            </p>
                            <p>
                                With passionate, experienced educators and a focus on individual development, we create
                                a foundation for lifelong learning while fostering kindness, independence, and
                                confidence in every child.
                            </p>
                            <h6 class="fst-italic pb-3">Come join the Stenofly family — where little minds take flight!
                            </h6>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-6 d-none d-lg-block image-column">
                    <div class="image-box">
                        <figure class="image image-1 lft-img">
                            <img decoding="async" src="assets/images/about/about-1.jpg" class="img-fluid" alt="">
                        </figure>
                        <figure class="image image-2">
                            <img decoding="async" src="assets/images/about/about-2.jpg" class="img-fluid" alt="">
                        </figure>
                    </div>
                </div>

            </div>
        </div>
    </section>






    <?php include 'includes/footer.php'; ?>