<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'includes/head.php'; ?>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-title centred page-breadcrumb ">
        <div class="container">
            <div class="content-box">
                <h1>Activities</h1>
                <div class="bread-crumb clearfix">
                    <span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage"
                            title="Go to Stenofly." href="index.php" class="home"><span property="name">Stenofly</span></a>

                    </span> &gt; <span property="itemListElement" typeof="ListItem"><span property="name"
                            class="post post-page current-item">Activities</span>

                    </span>
                </div>
            </div>
        </div>
    </section>


    <!-- Activities Section -->
    <section class="gallery-section sec-pad  text-center">
        <div class="container">
            <div class="sec-title">
                <h5>Our Activities</h5>
                <h1 class="event">Indoor Games
                </h1>
            </div>

            <div class="row g-4 ">
                <!-- Activities Item -->
                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/1.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/1.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>

                            <div class="gallery-title">Abagus</div>
                        </div>
                    </a>
                </div>

                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/2.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/2.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>

                            <div class="gallery-title">Drawing</div>
                        </div>
                    </a>
                </div>

                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/3.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/3.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                            <div class="gallery-title">Chess</div>
                        </div>
                    </a>
                </div>

                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/4.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/4.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>

                            <div class="gallery-title">Block Builders</div>
                        </div>
                    </a>
                </div>

                <div class="col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/5.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/5.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>

                            <div class="gallery-title">Yoga</div>
                        </div>
                    </a>
                </div>

                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/6.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/6.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                            <div class="gallery-title">Spin & Score</div>
                        </div>
                    </a>
                </div>

            </div>

            <div class="sec-title">

                <h1 class="event pt-4">Outdoor Games</h1>
            </div>

            <div class="row g-4 ">
                <!-- Activities Item -->
                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/out-1.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/out-1.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                             <div class="gallery-title">Ladder Dash</div>
                        </div>
                  
                    </a>
                </div>

                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/out-2.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/out-2.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                             <div class="gallery-title">Grip & Glide</div>
                        </div>
                    </a>
                </div>

                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/out-3.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/out-3.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                             <div class="gallery-title">Slide Safari</div>
                        </div>
                    </a>
                </div>

                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/out-4.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/out-4.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                             <div class="gallery-title">Rainbow Crawl</div>
                        </div>
                    </a>
                </div>

                <div class="col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/out-5.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/out-5.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                             <div class="gallery-title">Football</div>
                        </div>
                    </a>
                </div>

                <div class=" col-md-4 col-sm-6 col-6">
                    <a href="assets/images/activities/out-6.jpg" class="glightbox" data-gallery="activities">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/activities/out-6.jpg" class="img-fluid w-100" alt="Activity Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                             <div class="gallery-title">Bond Ring</div>
                        </div>
                    </a>
                </div>
            </div>



        </div>

    </section>







    <?php include 'includes/footer.php'; ?>

