 const preloaderDelay = 1000;

    window.addEventListener('load', function () {
      setTimeout(function () {
        const preloader = document.querySelector('.preloader');
        if (preloader) {
          preloader.style.display = 'none';
        }
      }, preloaderDelay);
    });

document.addEventListener("mousemove", function (e) {
    const layers = document.querySelectorAll(".parallax-layer");
    const speedFactor = 10;

    const x = (window.innerWidth / 2 - e.clientX) / speedFactor;
    const y = (window.innerHeight / 2 - e.clientY) / speedFactor;

    layers.forEach(layer => {
        const depth = layer.getAttribute('data-depth');
        const moveX = x * depth;
        const moveY = y * depth;
        layer.style.transform = `translate3d(${moveX}px, ${moveY}px, 0)`;
    });
});

// Scroll Top
const scrollButton = document.querySelector('.scroll-top');

window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        scrollButton.classList.add('open');
    } else {
        scrollButton.classList.remove('open');
    }
});

scrollButton.addEventListener('click', () => {
    document.querySelector('html').scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});


 document.querySelectorAll('#mobileMenu .nav-link[data-bs-toggle="collapse"]').forEach(link => {
    const targetId = link.getAttribute('href');
    const icon = link.querySelector('.dropdown-icon');
    const targetMenu = document.querySelector(targetId);

    // Listen for collapse show/hide events
    if (targetMenu) {
      targetMenu.addEventListener('show.bs.collapse', () => {
        icon.classList.remove('bi-chevron-down');
        icon.classList.add('bi-chevron-up');
      });

      targetMenu.addEventListener('hide.bs.collapse', () => {
        icon.classList.remove('bi-chevron-up');
        icon.classList.add('bi-chevron-down');
      });
    }
  });