<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'includes/head.php'; ?>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-title centred page-breadcrumb ">
        <div class="container">
            <div class="content-box">
                <h1>Classes</h1>
                <div class="bread-crumb clearfix">
                    <span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage"
                            title="Go to Stenofly." href="index.php" class="home"><span property="name">Stenofly</span></a>

                    </span> &gt; <span property="itemListElement" typeof="ListItem"><span property="name"
                            class="post post-page current-item">Classes</span>

                    </span>
                </div>
            </div>
        </div>
    </section>


    <section class="classes-section sec-pad">
        <div class="container ">
            <div class="sec-title centred ">
                <h5>Classes</h5>
                <h1 class="classes_service">Education for Your<br>Children</h1>
            </div>
            <div class="row g-4 ">
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp ">
                        <figure class="image-box position-relative overflow-hidden"><a href="#"><img
                                    src="assets/images/classes/Toddlers_Club_I.jpg" class="img-fluid w-100 d-block"
                                    alt=""></a>
                        </figure>
                        <div class="lower-content">

                            <h3><a href="#">Toddler</a></h3>

                            <div class="text">Encouraging little explorers to learn, play, and grow every day.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>1.5 to 2.5 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp">
                        <figure class="image-box position-relative overflow-hidden"><a class="bg2" href="#"><img
                                    decoding="async" src="assets/images/classes/Play_Group_II.jpg"
                                    class="img-fluid w-100 d-block" alt=""></a></figure>
                        <div class="lower-content">

                            <h3><a href="#">Play Group</a></h3>

                            <div class="text">A fun-filled first step where little ones learn, play, and socialize
                                together.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>2 to 3 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp ">
                        <figure class="image-box position-relative overflow-hidden"><a href="#"><img decoding="async"
                                    src="assets/images/classes/Day_Care_III.jpg" class="img-fluid w-100 d-block"
                                    alt=""></a>
                        </figure>
                        <div class="lower-content">

                            <h3><a href="#">Day Care</a>
                            </h3>

                            <div class="text">A safe, caring space where children learn, play, and grow with love.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>1.5 to 5 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp ">
                        <figure class="image-box position-relative overflow-hidden"><a href="#"><img
                                    src="assets/images/classes/Nursery_IV.jpg" class="img-fluid w-100 d-block"
                                    alt=""></a>
                        </figure>
                        <div class="lower-content">

                            <h3><a href="#">Nursery</a></h3>

                            <div class="text">Nurturing young minds with love, creativity, and joyful learning.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>3 to 4 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp">
                        <figure class="image-box position-relative overflow-hidden"><a class="bg2" href="#"><img
                                    decoding="async" src="assets/images/classes/Junior_KG_V.jpg"
                                    class="img-fluid w-100 d-block" alt=""></a></figure>
                        <div class="lower-content">

                            <h3><a href="#">Junior KG</a></h3>

                            <div class="text">Guiding little learners with fun, curiosity, and early academic skills.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>4 to 5 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp ">
                        <figure class="image-box position-relative overflow-hidden"><a href="#"><img decoding="async"
                                    src="assets/images/classes/Senior_KG_VI.jpg" class="img-fluid w-100 d-block"
                                    alt=""></a>
                        </figure>
                        <div class="lower-content">

                            <h3><a href="#">Senior KG</a>
                            </h3>

                            <div class="text">Preparing confident little achievers through play-based learning and
                                exploration.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>5 to 6 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>






    <?php include 'includes/footer.php'; ?>