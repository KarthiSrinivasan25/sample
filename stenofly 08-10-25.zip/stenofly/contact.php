<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'includes/head.php'; ?>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-title centred page-breadcrumb ">
        <div class="container">
            <div class="content-box">
                <h1>Contact us</h1>
                <div class="bread-crumb clearfix">
                    <span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage"
                            title="Go to Stenofly." href="index.php" class="home"><span property="name">Stenofly</span></a>

                    </span> &gt; <span property="itemListElement" typeof="ListItem"><span property="name"
                            class="post post-page current-item">Contact us</span>

                    </span>
                </div>
            </div>
        </div>
    </section>


    <section class="contact-info-section sec-pad centred">
        <div class="container">
            <div class="sec-title">
                <h5>Contact</h5>
                <h1>Get In Touch
                </h1>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                    <div class="single-info-box wow animate__animated animate__fadeInUp" data-wow-delay="400ms"
                        data-wow-duration="1300ms">


                        <div class="inner-box">
                            <div class="icon-box"><i class="bi bi-geo-alt"></i></div>
                            <h3>Our Location</h3>
                            <div class="text">R.P Pudur, Namakkal-637001,<br> Tamilnadu, India</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                    <div class="single-info-box wow animate__animated animate__fadeInUp" data-wow-delay="400ms"
                        data-wow-duration="1300ms">

                        <div class="inner-box">
                            <div class="icon-box"><i class="bi bi-telephone"></i></div>
                            <h3>Phone Number
                            </h3>
                            <div class="text"> <a href="tel:8489484895">8489484895</a><br>
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                    <div class="single-info-box wow animate__animated animate__fadeInUp" data-wow-delay="400ms"
                        data-wow-duration="1300ms">

                        <div class="inner-box">
                            <div class="icon-box"><i class="bi bi-envelope-at"></i></div>
                            <h3>Email Address
                            </h3>
                            <div class="text"> <a href="mailto:stenofly@gmail.com">stenofly@gmail.com</a><br>
                                <a href="mailto:stenofly@gmail.com">stenofly@gmail.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="contact-form-section sec-pad" style="background-color: #f0eee7">
        <div class="container">
            <div class="row align-items-stretch">

                <div class="col-lg-6 mb-4 mb-lg-0">
                    <div class="map-responsive h-100 shadow-sm rounded overflow-hidden">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3910.630522055355!2d78.17333931481664!3d11.223943991671956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3babf5aa0a25dbbb%3A0x1a2f6d6eb2a2a7f2!2sR.P%20Pudur%2C%20Namakkal%2C%20Tamil%20Nadu%20637001%2C%20India!5e0!3m2!1sen!2sus!4v1693410067845!5m2!1sen!2sus"
                            width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="card shadow-lg border-0 p-4 h-100">
                        <div class="sec-title centred">
                            <h5>Inquiry</h5>
                            <h1>Leave a Message</h1>
                        </div>
                        <form action="" method="POST" onsubmit="return validateForm();" class="contact-validation">
                            <div class="row">

                                <div class="col-md-6 mb-3">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="name" name="name"
                                            pattern="^[A-Za-z\s]+$" onkeypress="return isTextKey(event)"
                                            placeholder="Your Name" required>
                                        <label for="name">Name</label>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="email" name="email"
                                            pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.com$" placeholder="Your Email"
                                            required>
                                        <label for="email">Email</label>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <div class="form-floating">
                                        <input type="tel" class="form-control" id="phone" name="phone"
                                            pattern="[0-9]{10}" onKeyPress="return isNumberKey(event)"
                                            placeholder="Phone Number" required>
                                        <label for="phone">Phone Number</label>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="subject" name="subject"
                                            placeholder="Subject" required>
                                        <label for="subject">Subject</label>
                                    </div>
                                </div>

                                <div class="col-12 mb-3">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Your Message" id="message"
                                            name="message" style="height: 100px;" required></textarea>
                                        <label for="message">Message</label>
                                    </div>
                                </div>

                                <div class="col-md-8 mb-3">
                                    <div class="d-flex align-items-center" style="width:100%;">
                                        <div class="me-3">
                                            <img src="captcha.php?rand=2006490048" id="captchaimg" alt="CAPTCHA">
                                        </div>

                                        <div class="flex-grow-1">
                                            <div class="form-floating">
                                                <input id="captcha_code" name="captcha_code" type="text"
                                                    class="form-control" placeholder="Captcha" required>
                                                <label for="captcha_code">Captcha</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div style="font-size: 0.9em; margin-top: 5px;">
                                        Can't read the image? Click
                                        <a href="javascript:refreshCaptcha();"
                                            style="color: #141436; text-decoration: underline;">here</a> to refresh.
                                    </div>

                                </div>

                            </div>
                            <div class="btn-box">
                                <button type="submit" class="theme-btn border-0">Send Message</button>
                            </div>
                            <script>

                                function isNumberKey(evt) {
                                    var charCode = (evt.which) ? evt.which : event.keyCode
                                    if (charCode > 31 && (charCode < 48 || charCode > 57))
                                        return false;

                                    return true;
                                }

                                function isTextKey(evt) {
                                    var charCode = (evt.which) ? evt.which : evt.keyCode;
                                    if ((charCode >= 65 && charCode <= 90) ||
                                        (charCode >= 97 && charCode <= 122) ||
                                        charCode === 32) {
                                        return true;
                                    }
                                    return false;
                                }


                                function refreshCaptcha() {
                                    var img = document.images['captchaimg'];
                                    img.src = img.src.substring(0, img.src.lastIndexOf("?")) + "?rand=" + Math.random() * 1000;
                                }
                            </script>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>



<?php

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
     if (
        isset($_POST['captcha_code']) &&
        $_POST['captcha_code'] !== '' &&
        isset($_SESSION['captcha_code']) &&
        $_POST['captcha_code'] === $_SESSION['captcha_code']
    ) {
      $pop_cname = htmlspecialchars(trim($_POST['name']));
      $pop_cmob = htmlspecialchars(trim($_POST['phone']));
      $pop_cemail = htmlspecialchars(trim($_POST['email']));
      $mess = htmlspecialchars(trim($_POST['message']));
      $sub = htmlspecialchars(trim($_POST['subject']));

      $to = '#';
      $subject = "Stenofly - Enquiry";

      $message_for = "
        <b>Name:</b> $pop_cname<br /><br />
        <b>Contact Number:</b> $pop_cmob<br /><br />
        <b>Email:</b> $pop_cemail<br /><br />
        <b>Subject:</b> $sub<br /><br />
        <b>Message:</b> $mess";

      $headers1 = "Content-type: text/html; charset=UTF-8\r\n";
      $headers1 .= "From:#\r\n";

      if (mail($to, $subject, $message_for, $headers1)) {
        echo '<script>alert("* Your enquiry has been successfully sent...");</script>';
      } else {
        $error = error_get_last();
        echo '<script>alert("Failed to send your enquiry. Error: ' . ($error['message'] ?? 'Unknown error') . '");</script>';
      }
    } else {
      echo '<script>alert("Incorrect CAPTCHA. Please try again.");</script>';
    }
  }
  ?>



    <?php include 'includes/footer.php'; ?>