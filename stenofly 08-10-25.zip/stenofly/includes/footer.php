<!-- Footer -->
    <footer class="main-footer ">
        <div class="footer-top sec-pad">
            <div class="parallax-scene parallax-scene-3 parallax-icon d-none d-xl-block">
                <span data-depth="0.40" class="parallax-layer icon icon-1"></span>
                <span data-depth="0.50" class="parallax-layer icon icon-2"></span>
                <span data-depth="0.30" class="parallax-layer icon icon-3"></span>
                <span data-depth="0.40" class="parallax-layer icon icon-4"></span>
                <span data-depth="0.50" class="parallax-layer icon icon-5"></span>
                <span data-depth="0.30" class="parallax-layer icon icon-6"></span>
                <span data-depth="0.40" class="parallax-layer icon icon-7"></span>
            </div>
            <div class="container">
                <div class="widget-section">
                    <div class="row ">
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="about-widget footer-widget">
                                <h3 class="widget-title text-white fs-5 mb-3">About Stenofly
                                </h3>
                                <div class="widget-content">
                                    <div class="text">
                                        <p>At Stenofly Kindergarten, we believe childhood is where the future begins.
                                            Our nurturing environment, designed for ages 2 to 6, blends joyful learning
                                            with creativity, play, and discovery. With passionate educators and a
                                            child-first approach, we inspire curiosity, build confidence, and lay the
                                            foundation for lifelong success — where every little mind is given the space
                                            to dream, grow, and take flight.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="link-widget footer-widget">
                                <h3 class="widget-title text-white fs-5 mb-3">Useful Link</h3>
                                <div class="widget-content">
                                    <ul class="d-flex flex-wrap d-md-block">
                                        <li class="w-50 d-md-block"><a href="about.php"><i
                                                    class="fas fa-chevron-right me-2"></i>About</a></li>
                                        <li class="w-50 d-md-block"><a href="classes.php"><i
                                                    class="fas fa-chevron-right me-2"></i>Classes</a></li>
                                        <li class="w-50 d-md-block"><a href="service.php"><i
                                                    class="fas fa-chevron-right me-2"></i>Service</a></li>
                                        <li class="w-50 d-md-block"><a href="activities.php"><i
                                                    class="fas fa-chevron-right me-2"></i>Activity</a></li>
                                        <li class="w-50 d-md-block"><a href="gallery.php"><i
                                                    class="fas fa-chevron-right me-2"></i>Gallery</a></li>
                                        <li class="w-50 d-md-block"><a href="contact.php"><i
                                                    class="fas fa-chevron-right me-2"></i>Contact Us</a></li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="contact-widget footer-widget">
                                <h3 class="widget-title text-white fs-5 mb-3">Get in Touch
                                </h3>
                                <div class="widget-content">

                                    <ul class="info-list">

                                        <li><i class="fas fa-home"></i>R.P Pudur, Namakkal-637001, Tamilnadu, India</li>
                                        <li><i class="fas fa-phone"></i><a href="tel:8489484895">+91 84894 84895</a>
                                        </li>
                                        <li><i class="fas fa-envelope"></i><a
                                                href="mailto:info@example.com">stenofly@gmail.com</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="location-widget footer-widget">
                                <h3 class="widget-title text-white fs-5 mb-3">Our Location</h3>
                                <div class="widget-content">

                                    <div class="location-inner map-container">
                                        <iframe
                                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3910.630522055355!2d78.17333931481664!3d11.223943991671956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3babf5aa0a25dbbb%3A0x1a2f6d6eb2a2a7f2!2sR.P%20Pudur%2C%20Namakkal%2C%20Tamil%20Nadu%20637001%2C%20India!5e0!3m2!1sen!2sus!4v1693410067845!5m2!1sen!2sus"
                                            width="100%" height="250" style="border:0;" allowfullscreen=""
                                            loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    
        <div class="footer-bottom position-relative">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-4 text-center text-md-start footer-content">
                        <div class="copyright">
                            © 2025 Stenofly. All rights reserved.
                        </div>
                    </div>

                    <div class="col-md-4 text-center footer-content">
                        <figure class="footer-logo d-inline-block">
                            <a href="index.php">
                                <img src="assets/images/logo/logo.png" style="width: 216px;" alt="Footer Logo"
                                    class="img-fluid">
                            </a>
                        </figure>
                    </div>

                    <div class="col-md-4 text-center text-md-end footer-content">
                        <p class="mb-0">Website Developed by Best Webmasterz</p>
                    </div>

                </div>

            </div>
        </div>
    </footer>

    <button class="scroll-top scroll-to-target" data-target="html">
        <i class="fa fa-arrow-up"></i>
    </button>

    <script src="assets/js/script.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
        crossorigin="anonymous"></script>

    <script src="slider/owl.carousel.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $("#hometestslider").owlCarousel({
                navigation: false,
                autoHeight: false,
                autoPlay: 3000,
                pagination: true,
                items: 1,
                itemsDesktop: [1199, 1],
                itemsDesktopSmall: [979, 1],
                itemsTablet: [768, 1],
                itemsTabletSmall: false,
                itemsMobile: [480, 1]
            });
        });


        $(document).ready(function () {
            $("#servicesCarousel").owlCarousel({
                navigation: false,
                autoHeight: false,
                autoPlay: 3000,
                dots: true,
                items: 2,
                itemsDesktop: [1199, 2],
                itemsDesktopSmall: [979, 2],
                itemsTablet: [768, 1],
                itemsTabletSmall: false,
                itemsMobile: [480, 1]
            });
        });

        $(document).ready(function () {
            $("#testimonialCarousel").owlCarousel({
                navigation: false,
                autoHeight: false,
                autoPlay: 3000,
                pagination: true,
                items: 2,
                itemsDesktop: [1199, 2],
                itemsDesktopSmall: [979, 2],
                itemsTablet: [768, 1],
                itemsTabletSmall: false,
                itemsMobile: [480, 1]
            });
        });

        $(document).ready(function () {
            $('.brand-active').owlCarousel({
                navigation: false,
                autoHeight: false,
                autoPlay: 3000,
                pagination: false,
                items: 5,
                itemsDesktop: [1199, 4],
                itemsDesktopSmall: [979, 3],
                itemsTablet: [768, 2],
                itemsTabletSmall: false,
                itemsMobile: [480, 2]
            });
        });

          new WOW().init();
    </script>

     <!-- GLightbox JS -->
<script src="https://cdn.jsdelivr.net/npm/glightbox/dist/js/glightbox.min.js"></script>

<!-- Initialize GLightbox -->
<script>
  const lightbox = GLightbox({
    selector: '.glightbox'
  });
  </script>