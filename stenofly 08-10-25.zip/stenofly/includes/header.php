<div class="preloader"></div>


<header class="main-header">


    <div class="header-top">
        <div class="container">
            <div
                class="d-flex flex-column flex-md-row justify-content-between align-items-center text-center text-md-start mx-lg-5">

                <!-- Social Links -->
                <div class="social-links ms-auto ms-md-0">
                    <ul class="social-list list-inline mb-0">
                        <li class="list-inline-item me-3">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                        </li>
                        <li class="list-inline-item me-3">
                            <a href="#"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li class="list-inline-item me-3">
                            <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        </li>
                    </ul>
                </div>


                <!-- Header Info -->
                <div class="header-info order-1 order-md-2 d-none d-md-block">
                    <ul class="info-list list-inline mb-0">
                        <li class="list-inline-item position-relative me-4 pe-3 info-item">
                            <i class="fas fa-phone"></i>
                            <a href="tel:8489484895">+91 84894 84895</a>
                        </li>
                        <li class="list-inline-item position-relative me-4 pe-3 info-item">
                            <i class="fas fa-envelope"></i>
                            <a href="mailto:info@example.com">stenofly@gmail.com</a>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </div>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mx-lg-5">
            <!-- Logo -->
            <div class="logo-box mx-lg-5">
                <figure class="logo">
                    <a href="index.php">
                        <img src="assets/images/logo/logo.png" alt="Logo">
                    </a>
                </figure>
            </div>

            <nav class="navbar navbar-expand-lg mx-lg-5">
                <div class="me-2 d-lg-none">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mobileMenu"
                        aria-controls="mobileMenu" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>

                <div class="collapse py-3 navbar-collapse" id="mainNavbar">
                    <?php
                    $currentPage = basename($_SERVER['PHP_SELF']);
                    ?>

                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($currentPage == 'index.php') ? 'active' : ''; ?>"
                                href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($currentPage == 'about.php') ? 'active' : ''; ?>"
                                href="about.php">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($currentPage == 'classes.php') ? 'active' : ''; ?>"
                                href="classes.php">Classes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($currentPage == 'service.php') ? 'active' : ''; ?>"
                                href="service.php">Service</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($currentPage == 'activities.php') ? 'active' : ''; ?>"
                                href="activities.php">Activity</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($currentPage == 'gallery.php') ? 'active' : ''; ?>"
                                href="gallery.php">Gallery</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($currentPage == 'contact.php') ? 'active' : ''; ?>"
                                href="contact.php">Contact Us</a>
                        </li>
                    </ul>

                </div>
            </nav>
        </div>
    </div>

    <!-- Mobile Vertical Menu -->
    <div id="mobileMenu" class="collapse d-lg-none bg-dark mx-5">
        <ul class="navbar-nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="about.php">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="classes.php">Classes</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="service.php">Service</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="activities.php">Activity</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="gallery.php">Gallery</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
        </ul>
    </div>

</header>