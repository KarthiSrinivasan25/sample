<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'includes/head.php'; ?>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <!-- Home section -->
    <div id="hometestslider" class="owl-carousel">
        <div class="item_new">
            <img src="assets/images/hero_bg/1.jpg" />
            <img src="assets/images/hero_bg/mb-1.jpg" />
        </div>
        <div class="item_new">
            <img src="assets/images/hero_bg/2.jpg" />
            <img src="assets/images/hero_bg/mb-2.jpg" />
        </div>
        <div class="item_new">
            <img src="assets/images/hero_bg/3.jpg" />
            <img src="assets/images/hero_bg/mb-3.jpg" />
        </div>
        <div class="item_new">
            <img src="assets/images/hero_bg/4.jpg" />
            <img src="assets/images/hero_bg/mb-4.jpg" />
        </div>
    </div>



    <!-- About -->
    <section class="about-section sec-pad">
        <div class="anim-icon  d-none d-xl-block">
            <div class="icon icon-1 float-bob-x"></div>
            <div class="icon icon-2"></div>
            <div class="icon icon-3"></div>
        </div>
        <div class="container ">
            <div class="row d-flex justify-content-between align-items-center">

                <div class="col-lg-6 d-none d-lg-block image-column">
                    <div class="image-box">
                        <figure class="image image-1">
                            <img decoding="async" src="assets/images/about/about-1.jpg" alt="">
                        </figure>
                        <figure class="image image-2">
                            <img decoding="async" src="assets/images/about/about-2.jpg" alt="">
                        </figure>
                    </div>
                </div>



                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                    <div class="content-box me-lg-5">
                        <div class="sec-title style-two">
                            <h5>About Us
                            </h5>
                            <h1 class="about_us">Welcome to Stenofly Kindergarten
                            </h1>
                        </div>

                        <div class="bold-text mb-2 text-secondary">
                            <p>
                                At Stenofly Kindergarten, we believe that every
                                child is born with endless potential, and our mission is to nurture that spark through
                                joyful learning, creativity, and care. We provide a warm, safe, and stimulating
                                environment
                                where children aged 2 to 6 can grow socially, emotionally, physically, and
                                intellectually.
                            </p>
                            <p>Our play-based and inquiry-driven curriculum encourages curiosity, imagination, and
                                hands-on exploration. From storytelling and art to science experiments and outdoor play,
                                every day at Stenofly is a new adventure in learning.
                            </p>
                            <p>
                                With passionate, experienced educators and a focus on individual development, we create
                                a foundation for lifelong learning while fostering kindness, independence, and
                                confidence in every child.
                            </p>
                            <h6 class="fst-italic pb-3">Come join the Stenofly family — where little minds take flight!
                            </h6>
                        </div>
                        <div class="btn-box"><a href="about.php" class="theme-btn">View More</a></div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service -->
    <section class="service-section sec-pad">
        <div class="container">
            <div class="row align-items-center">
                <!-- Left Column -->
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div class="inner-content  pe-lg-4 mb-5 mb-lg-0">
                        <div class="sec-title style-two">
                            <h5>Services</h5>
                            <h1 class="service_one">Best Services for Kids</h1>
                        </div>
                        <div class="text">
                            At Stenofly Kindergarten, we nurture young minds not only through quality early education
                            but
                            also by inspiring creativity, rhythm, and teamwork with specialized programs in sports,
                            music,
                            and art — where every child discovers their unique potential.
                        </div>
                    </div>
                </div>

                <!-- Right Column -->
                <div class="col-lg-8 col-md-12 col-sm-12">
                    <div id="servicesCarousel" class="owl-carousel owl-theme">
                        <!-- Carousel Item 1 -->
                        <div class="item_new">
                            <div class="service-card mx-auto">
                                <div class="service-icon bg-icon-2 d-flex justify-content-center align-items-center">
                                    <i class="fa-solid fa-basketball text-info"></i>
                                </div>
                                <div class="service-title">Sports Training</div>
                                <div class="service-desc">Strong bodies, confident minds — sports training starts here!
                                </div>
                            </div>
                        </div>

                        <!-- Carousel Item 2 -->
                        <div class="item_new">
                            <div class="service-card mx-auto">
                                <div class="service-icon bg-icon-3 d-flex justify-content-center align-items-center">
                                    <i class="fa-solid fa-drum text-danger"></i>
                                </div>
                                <div class="service-title">Music Training</div>
                                <div class="service-desc">Tiny voices, magical sounds — discovering the pure joy of music!
                                </div>
                            </div>
                        </div>

                        <!-- Carousel Item 3 -->
                        <div class="item_new">
                            <div class="service-card mx-auto">
                                <div class="service-icon bg-icon-5 d-flex justify-content-center align-items-center">
                                    <i class="fa-solid fa-palette text-success"></i>
                                </div>
                                <div class="service-title">Drawing Class</div>
                                <div class="service-desc">Little artists, big imaginations — every colorful stroke tells a story!
                                </div>
                            </div>
                        </div>

                        <!-- Carousel Item 4 -->
                        <div class="item_new">
                            <div class="service-card mx-auto">
                                <div class="service-icon bg-icon-6 d-flex justify-content-center align-items-center">
                                    <i class="fa fa-music text-voilet"></i>
                                </div>
                                <div class="service-title">Dance Class</div>
                                <div class="service-desc">Rhythms in motion, hearts in sync — every beat sparks magic!
                                </div>
                            </div>
                        </div>

                        <!-- Carousel Item 5 -->
                        <div class="item_new">
                            <div class="service-card mx-auto">
                                <div class="service-icon bg-icon-7 d-flex justify-content-center align-items-center">
                                    <i class="fa-solid fa-person-praying text-orange"></i>
                                </div>
                                <div class="service-title">Yoga</div>
                                <div class="service-desc">Quiet minds, strong bodies — every breath is a new beginning!
                                </div>
                            </div>
                        </div>

                        <!-- Carousel Item 6 -->
                        <div class="item_new">
                            <div class="service-card mx-auto">
                                <div class="service-icon bg-icon-8 d-flex justify-content-center align-items-center">
                                    <i class="fa-solid fa-utensils text-pink"></i>

                                </div>
                                <div class="service-title">Children cooking</div>
                                <div class="service-desc">Tiny chefs, imagination — cooking smiles one dish at a time!
                                </div>
                            </div>
                        </div>

                        <!-- Carousel Item 7 -->
                        <div class="item_new">
                            <div class="service-card mx-auto">
                                <div class="service-icon bg-icon-9 d-flex justify-content-center align-items-center">
                                    <i class="fa-solid fa-seedling text-green"></i>

                                </div>
                                <div class="service-title">Gardening</div>
                                <div class="service-desc">Little hands, blooming dreams — gently growing joy, leaf by leaf!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- classes -->
    <section class="classes-section sec-pad">
        <div class="anim-icon  d-none d-xl-block">
            <div class="icon icon-1 float-bob-x"></div>
        </div>
        <div class="container ">
            <div class="sec-title centred ">
                <h5>Classes</h5>
                <h1 class="classes_service">Education for Your<br>Children</h1>
            </div>
            <div class="row g-4 ">
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp ">
                        <figure class="image-box position-relative overflow-hidden"><a href="#"><img
                                    src="assets/images/classes/Toddlers_Club_I.jpg" class="img-fluid w-100 d-block"
                                    alt=""></a>
                        </figure>
                        <div class="lower-content">

                            <h3><a href="#">Toddler</a></h3>

                            <div class="text">Encouraging little explorers to learn, play, and grow every day.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>1.5 to 2.5 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp">
                        <figure class="image-box position-relative overflow-hidden"><a class="bg2" href="#"><img
                                    decoding="async" src="assets/images/classes/Play_Group_II.jpg"
                                    class="img-fluid w-100 d-block" alt=""></a></figure>
                        <div class="lower-content">

                            <h3><a href="#">Play Group</a></h3>

                            <div class="text">A fun-filled first step where little ones learn, play, and socialize
                                together.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>2 to 3 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp ">
                        <figure class="image-box position-relative overflow-hidden"><a href="#"><img decoding="async"
                                    src="assets/images/classes/Day_Care_III.jpg" class="img-fluid w-100 d-block"
                                    alt=""></a>
                        </figure>
                        <div class="lower-content">

                            <h3><a href="#">Day Care</a>
                            </h3>

                            <div class="text">A safe, caring space where children learn, play, and grow with love.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>1.5 to 5 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp ">
                        <figure class="image-box position-relative overflow-hidden"><a href="#"><img
                                    src="assets/images/classes/Nursery_IV.jpg" class="img-fluid w-100 d-block"
                                    alt=""></a>
                        </figure>
                        <div class="lower-content">

                            <h3><a href="#">Nursery</a></h3>

                            <div class="text">Nurturing young minds with love, creativity, and joyful learning.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>3 to 4 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp">
                        <figure class="image-box position-relative overflow-hidden"><a class="bg2" href="#"><img
                                    decoding="async" src="assets/images/classes/Junior_KG_V.jpg"
                                    class="img-fluid w-100 d-block" alt=""></a></figure>
                        <div class="lower-content">

                            <h3><a href="#">Junior KG</a></h3>

                            <div class="text">Guiding little learners with fun, curiosity, and early academic skills.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>4 to 5 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="inner-block fadeInUp ">
                        <figure class="image-box position-relative overflow-hidden"><a href="#"><img decoding="async"
                                    src="assets/images/classes/Senior_KG_VI.jpg" class="img-fluid w-100 d-block"
                                    alt=""></a>
                        </figure>
                        <div class="lower-content">

                            <h3><a href="#">Senior KG</a>
                            </h3>

                            <div class="text">Preparing confident little achievers through play-based learning and
                                exploration.
                            </div>
                            <ul class="info-box">
                                <li>Age: <span>5 to 6 Years</span></li>
                                <li>Size: <span>12 Seats</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Featured Section -->
    <section class="feature-section position-relative d-block sec-pad">
        <div class="anim-icon">
            <div class="icon icon-1 d-none d-xl-block"></div>
            <div class="icon icon-2 d-none d-xl-block"></div>
        </div>
        <div class="image-column d-none d-xl-block"
            style="background-image: url(assets/images/facilities/Best_Facilities_for_Kids.jpg);">
        </div>

        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-12 col-md-12 offset-xl-7 inner-column">
                    <div class="inner-content">
                        <div class="sec-title style-two">
                            <h5 class="">Facilities</h5>
                            <h1 class="facilities">Best Facilities<br> for Kids</h1>
                        </div>
                        <div class="inner-box">
                            <div class="single-item wow fadeInUp">
                                <div class="icon-box"><i aria-hidden="true" class=" fa-solid fa-bus"></i></div>
                                <h3><a href="#">Transportation</a></h3>
                                <div class="text">Driven by Trust, Powered by Care – Ensuring Every Child’s Journey is
                                    Safe, Smooth, and On Time.
                                </div>
                            </div>
                            <div class="single-item wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms"
                                style="visibility: visible;">
                                <div class="icon-box"><i aria-hidden="true" class=" bi bi-controller"></i></div>
                                <h3><a href="#_">Outdoor Games</a></h3>
                                <div class="text">Where Champions Begin – Inspiring Teamwork, Strength, and
                                    Sportsmanship in Every Game.
                                </div>
                            </div>
                            <div class="single-item wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms"
                                style="visibility: visible;">
                                <div class="icon-box"><i aria-hidden="true" class=" fa-solid fa-bowl-food"></i></div>
                                <h3><a href="#_">Nutritious Food</a></h3>
                                <div class="text">Healthy Plates, Happy Students – Serving Nutrition That Inspires
                                    Growth and Learning.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section class="gallery-section sec-pad  text-center">
        <div class="container">
            <div class="sec-title">
                <h5>Gallery</h5>
                <h1 class="event">Photo Gallery
                </h1>
            </div>

            <div class="row g-4 ">
                <!-- Gallery Item -->
                <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                    <a href="assets/images/gallery/1.jpg" class="glightbox" data-gallery="gallery">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/gallery/1.jpg" class="img-fluid w-100" alt="Gallery Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                    <a href="assets/images/gallery/2.jpg" class="glightbox" data-gallery="gallery">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/gallery/2.jpg" class="img-fluid w-100" alt="Gallery Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                    <a href="assets/images/gallery/3.jpg" class="glightbox" data-gallery="gallery">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/gallery/3.jpg" class="img-fluid w-100" alt="Gallery Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                    <a href="assets/images/gallery/4.jpg" class="glightbox" data-gallery="gallery">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/gallery/4.jpg" class="img-fluid w-100" alt="Gallery Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                    <a href="assets/images/gallery/2.jpg" class="glightbox" data-gallery="gallery">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/gallery/5.jpg" class="img-fluid w-100" alt="Gallery Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                    <a href="assets/images/gallery/4.jpg" class="glightbox" data-gallery="gallery">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/gallery/4.jpg" class="img-fluid w-100" alt="Gallery Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                    <a href="assets/images/gallery/1.jpg" class="glightbox" data-gallery="gallery">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/gallery/1.jpg" class="img-fluid w-100" alt="Gallery Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                    <a href="assets/images/gallery/2.jpg" class="glightbox" data-gallery="gallery">
                        <div class="gallery-item position-relative overflow-hidden rounded-4">
                            <img src="assets/images/gallery/2.jpg" class="img-fluid w-100" alt="Gallery Image">
                            <div class="overlay d-flex align-items-center justify-content-center">
                                <i class="fa-solid fa-plus" style="color: white; font-size: 2rem;"></i>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Event Section -->
    <section class="event-section sec-pad">
        <div class="anim-icon  d-none d-xl-block">
            <div class="icon icon-1 float-bob-x"></div>
        </div>
        <div class="container">
            <div class="sec-title centred">
                <h5>Events</h5>
                <h1 class="event text-white">Our Events</h1>
            </div>
            <div class="row ">
                <div class="col-xl-6 col-lg-12 col-md-12 event-block">
                    <div class="event-block-one fadeInLeft">
                        <div class="inner-box">
                            <figure class="image-box"><a href="#"><img decoding="async"
                                        src="assets/images/events/event-1.jpg" alt=""></a></figure>
                            <div class="content-box">
                                <div class="px-3">
                                    <div class="date">2021-02-20</div>
                                    <h3><a href="#">Children’s Day</a></h3>
                                    <div class="text">Celebrating childhood with joy, color, and endless imagination!
                                    </div>
                                    <div class="location"><i class="fa-solid fa-location-dot"></i>Location:
                                        <span>NAMAKKAL</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-12 col-md-12 event-block">
                    <div class="event-block-one fadeInLeft">
                        <div class="inner-box">

                            <figure class="image-box"><a href="#"><img decoding="async"
                                        src="assets/images/events/event-2.jpg" alt=""></a></figure>
                            <div class="content-box">
                                <div class="px-3">
                                    <div class="date">2020-11-14</div>
                                    <h3><a href="#">Pongal Festival</a>
                                    </h3>
                                    <div class="text">Celebrating the harvest, happiness, and the warmth of tradition!
                                    </div>
                                    <div class="location"><i class="fa-solid fa-location-dot"></i>Location:
                                        <span>NAMAKKAL</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-12 col-md-12 event-block">
                    <div class="event-block-one wow fadeInLef">
                        <div class="inner-box">
                            <figure class="image-box"><a href="#"><img decoding="async"
                                        src="assets/images/events/event-3.jpg" alt=""></a></figure>
                            <div class="content-box">
                                <div class="px-3">
                                    <div class="date">2020-11-14</div>
                                    <h3><a href="#">Puppet Show</a></h3>
                                    <div class="text">Puppets dance, stories sparkle, and smiles shine bright!
                                    </div>
                                    <div class="location"><i class="fa-solid fa-location-dot"></i>Location:
                                        <span>NAMAKKAL</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-12 col-md-12 event-block">
                    <div class="event-block-one fadeInLef;">
                        <div class="inner-box">
                            <figure class="image-box"><a href="#"><img decoding="async"
                                        src="assets/images/events/event-4.jpg" alt=""></a></figure>
                            <div class="content-box">
                                <div class="px-3">
                                    <div class="date">2020-11-14</div>
                                    <h3><a href="">Independence Day</a></h3>
                                    <div class="text">Saluting the past, celebrating the present, and shaping the
                                        future!
                                    </div>
                                    <div class="location"><i class="fa-solid fa-location-dot"></i>Location:
                                        <span>NAMAKKAL</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
    </section>


    <!-- Testimonials Section -->
    <section class="testimonial-faq py-5 bg-white sec-pad">
        <div class="anim-icon position-absolute d-none d-xl-block">
            <div class="icon icon-1"></div>
        </div>

        <div class="container position-relative">
            <div class="testimonial-content text-center "> <!-- mx-lg-5 -->
                <div class="sec-title style-two">
                    <h5>Testimonials</h5>
                    <h1>What Happy Parents Say</h1>
                </div>

                <div class="owl-carousel owl-theme" id="testimonialCarousel">
                    <div class="item_new">
                        <div class="testimonial-box text-white position-relative">
                            <div class="mb-2">
                                <strong class="text-warning">Mithran</strong>
                                <span class="text-white-50"> / Kids Mother</span>
                            </div>
                            <h5><span class="text-warning">★★★★★</span></h5>
                            <p class="quote ">
                               Stenofly Kids provides a warm, encouraging space where my child thrives every day. The teachers truly care about each student’s growth and happiness.
                            </p>
                            <div class="arrow-down"></div>
                        </div>
                        <div class="avatars-wrapper d-flex justify-content-center mt-3 mb-4">
                            <img src="assets/images/icons/user.png" class="avatar mx-2" alt="Hattie Bradly">
                        </div>
                    </div>

                    <div class="item_new">
                        <div class="testimonial-box text-white position-relative">
                            <div class="mb-2">
                                <strong class="text-warning">Meera</strong>
                                <span class="text-white-50"> / Kids Mother</span>
                            </div>
                            <h5><span class="text-warning">★★★★★</span></h5>
                            <p class="quote">
                                The learning activities here are both fun and educational — my daughter looks forward to
                                school!
                                It’s a perfect blend of creativity and discipline.
                            </p>
                            <div class="arrow-down"></div>
                        </div>
                        <div class="avatars-wrapper d-flex justify-content-center mt-3 mb-4">
                            <img src="assets/images/icons/user.png" class="avatar mx-2" alt="Nosah Temsal">
                        </div>
                    </div>

                    <div class="item_new">
                        <div class="testimonial-box text-white position-relative">
                            <div class="mb-2">
                                <strong class="text-warning">Rahul</strong>
                                <span class="text-white-50"> / Kids Father</span>
                            </div>
                            <h5><span class="text-warning">★★★★☆</span></h5>
                            <p class="quote ">
                                Since joining Stenofly Kids, my son’s confidence and skills have blossomed beautifully.
                                The caring and supportive staff make all the difference in his growth.
                            </p>
                            <div class="arrow-down"></div>
                        </div>
                        <div class="avatars-wrapper d-flex justify-content-center mt-3 mb-4">
                            <img src="assets/images/icons/user.png" class="avatar mx-2" alt="Tmilos">
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>


    <!-- CTA Section -->
    <section class="cta-section centred sec-pad">
        <div class="anim-icon d-none d-xl-block">
            <div class="icon icon-1 float-bob-x"></div>
            <div class="icon icon-2 rotate-me"></div>
        </div>

        <div class="parallax-scene parallax-scene-3 parallax-icon d-none d-xl-block">
            <span data-depth="0.40" class="parallax-layer icon icon-1"></span>
            <span data-depth="0.50" class="parallax-layer icon icon-2"></span>
            <span data-depth="0.30" class="parallax-layer icon icon-3"></span>
            <span data-depth="0.40" class="parallax-layer icon icon-4"></span>
            <span data-depth="0.50" class="parallax-layer icon icon-5"></span>
            <span data-depth="0.30" class="parallax-layer icon icon-6"></span>
            <span data-depth="0.40" class="parallax-layer icon icon-7"></span>
        </div>

        <div class="container">
            <div class="content-box text-white">
                <h3 class="fs-4 mb-3">Join with Stenofly</h3>
                <h1 class="cta_section mb-4">Enrol Your Child<br>in Stenofly</h1>
                <div class="text">
                    Smart Learning, Healthy Eating, Safe Travels <br> With Complete Care for Kids, All in One Place.
                </div>
                <div class="btn-box">
                    <a href="contact.php" class="theme-btn">Contact Us</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Brand Section -->
    <section class="brand-area">
        <div class="container">
            <div class="row">
                <div class="brand-active owl-carousel py-4">
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-01.jpg" alt="Brand 1">
                    </div>
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-02.jpg" alt="Brand 2">
                    </div>
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-03.jpg" alt="Brand 3">
                    </div>
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-04.jpg" alt="Brand 4">
                    </div>
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-05.jpg" alt="Brand 5">
                    </div>

                    <div class="single-brand">
                        <img src="assets/images/brand/brand-01.jpg" alt="Brand 1">
                    </div>
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-02.jpg" alt="Brand 2">
                    </div>
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-03.jpg" alt="Brand 3">
                    </div>
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-04.jpg" alt="Brand 4">
                    </div>
                    <div class="single-brand">
                        <img src="assets/images/brand/brand-05.jpg" alt="Brand 5">
                    </div>
                </div>
            </div>

        </div>
    </section>


    <?php include 'includes/footer.php'; ?>

</body>

</html>