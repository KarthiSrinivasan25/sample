<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'includes/head.php'; ?>
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-title centred page-breadcrumb ">
        <div class="container">
            <div class="content-box">
                <h1>Service</h1>
                <div class="bread-crumb clearfix">
                    <span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage"
                            title="Go to Stenofly." href="index.php" class="home"><span property="name">Stenofly</span></a>

                    </span> &gt; <span property="itemListElement" typeof="ListItem"><span property="name"
                            class="post post-page current-item">Service</span>

                    </span>
                </div>
            </div>
        </div>
    </section>

    <section class="classes-section sec-pad">
        <div class="container ">
            <div class="sec-title centred ">
                <h5>Services</h5>
                <h1 class="classes_service">Best Services for Kids</h1>
            </div>
            <div class="row g-4 ">
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="service-card mx-auto">
                        <div class="service-icon bg-icon-2 d-flex justify-content-center align-items-center">
                            <i class="fa-solid fa-basketball text-info"></i>
                        </div>
                        <div class="service-title">Sports Training</div>
                        <div class="service-desc">Strong bodies, confident minds — sports training starts here!
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="service-card mx-auto">
                        <div class="service-icon bg-icon-3 d-flex justify-content-center align-items-center">
                            <i class="fa-solid fa-drum text-danger"></i>
                        </div>
                        <div class="service-title">Music Training</div>
                        <div class="service-desc">Tiny voices, magical sounds — discovering the pure joy of music!
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="service-card mx-auto">
                        <div class="service-icon bg-icon-5 d-flex justify-content-center align-items-center">
                            <i class="fa-solid fa-palette text-success"></i>
                        </div>
                        <div class="service-title">Drawing Class</div>
                        <div class="service-desc">Little artists, big imaginations — every colorful stroke tells a
                            story!
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="service-card mx-auto">
                        <div class="service-icon bg-icon-6 d-flex justify-content-center align-items-center">
                            <i class="fa fa-music text-voilet"></i>
                        </div>
                        <div class="service-title">Dance Class</div>
                        <div class="service-desc">Rhythms in motion, hearts in sync — every beat sparks magic!
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="service-card mx-auto">
                        <div class="service-icon bg-icon-7 d-flex justify-content-center align-items-center">
                            <i class="fa-solid fa-person-praying text-orange"></i>
                        </div>
                        <div class="service-title">Yoga</div>
                        <div class="service-desc">Quiet minds, strong bodies — every breath is a new beginning!
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="service-card mx-auto">
                        <div class="service-icon bg-icon-8 d-flex justify-content-center align-items-center">
                            <i class="fa-solid fa-utensils text-pink"></i>

                        </div>
                        <div class="service-title">Children cooking</div>
                        <div class="service-desc">Tiny chefs, imagination — cooking smiles one dish at a time!
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12 block-column">
                    <div class="service-card mx-auto">
                        <div class="service-icon bg-icon-9 d-flex justify-content-center align-items-center">
                            <i class="fa-solid fa-seedling text-green"></i>

                        </div>
                        <div class="service-title">Gardening</div>
                        <div class="service-desc">Little hands, blooming dreams — gently growing joy, leaf by leaf!
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>







    <?php include 'includes/footer.php'; ?>